<?php
// Capturamos posibles errores enviados por la url, ej: login.php?error=credenciales
$error = isset($_GET['error']) ? $_GET['error'] : null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión | Educ </title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        :root {
            --primary-color: #6366f1; /* Índigo más brillante para destacar en negro */
            --primary-hover: #4f46e5;
            --bg-dark: #000000; /* Fondo negro puro */
            --card-bg: #0f172a; /* Slate oscuro para la tarjeta */
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --border-color: #1e293b;
            --input-bg: #020617; /* Fondo de input casi negro */
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-dark);
            background-image: radial-gradient(circle at top right, rgba(99, 102, 241, 0.1), transparent 40%),
                              radial-gradient(circle at bottom left, rgba(99, 102, 241, 0.05), transparent 40%);
            color: var(--text-main);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }

        .login-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 1.5rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            width: 100%;
            max-width: 420px;
            padding: 2.5rem;
            position: relative;
            z-index: 10;
        }

        .brand-icon {
            background: var(--primary-color);
            color: white;
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem auto;
            box-shadow: 0 0 15px rgba(99, 102, 241, 0.4);
        }

        .form-control-pro {
            background-color: var(--input-bg);
            border: 1px solid var(--border-color);
            color: var(--text-main);
            padding: 0.75rem 1rem;
            padding-left: 2.5rem; /* Espacio para el icono */
            border-radius: 0.75rem;
            transition: all 0.2s;
        }

        /* Cambiar el color del placeholder en modo oscuro */
        .form-control-pro::placeholder {
            color: #475569;
        }

        .form-control-pro:focus {
            background-color: var(--input-bg);
            color: var(--text-main);
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.15);
        }

        .input-icon-wrapper {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            width: 18px;
            height: 18px;
        }

        .btn-primary-pro {
            background-color: var(--primary-color);
            border: none;
            padding: 0.75rem;
            border-radius: 0.75rem;
            font-weight: 600;
            width: 100%;
            color: white;
            transition: all 0.2s;
        }

        .btn-primary-pro:hover {
            background-color: var(--primary-hover);
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        }

        .form-label {
            font-weight: 500;
            font-size: 0.9rem;
            color: var(--text-main);
        }

        /* Ajustes de alertas para modo oscuro */
        .alert-danger { background-color: rgba(255, 255, 255, 0.1); border-color: rgba(239, 68, 68, 0.2); color: #fca5a5; }
        .alert-warning { background-color: rgba(255, 255, 255, 0.1); border-color: rgba(245, 158, 11, 0.2); color: #fcd34d; }
    </style>
</head>
<body>

<div class="login-card">
    <div class="brand-icon">
        <i data-lucide="graduation-cap" size="28"></i>
    </div>
    <div class="text-center mb-4">
        <h4 class="fw-bold mb-1">Bienvenido de nuevo</h4>
       
    </div>

    <?php if ($error === 'credenciales'): ?>
        <div class="alert alert-danger d-flex align-items-center py-2 text-sm rounded-3" role="alert">
            <i data-lucide="alert-circle" class="me-2" size="18"></i>
            <div>Email o contraseña incorrectos.</div>
        </div>
    <?php elseif ($error === 'acceso_denegado'): ?>
        <div class="alert alert-warning d-flex align-items-center py-2 text-sm rounded-3" role="alert">
            <i data-lucide="lock" class="me-2" size="18"></i>
            <div>Debes iniciar sesión para continuar.</div>
        </div>
    <?php endif; ?>

    <form action="login_process.php" method="POST">
        
        <div class="mb-3">
            <label class="form-label">Correo Electrónico</label>
            <div class="input-icon-wrapper">
                <i data-lucide="mail" class="input-icon"></i>
                <input type="email" name="email" class="form-control form-control-pro" required placeholder="tu@correo.com">
            </div>
        </div>

        <div class="mb-4">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <label class="form-label mb-0">Contraseña</label>
               
            </div>
            <div class="input-icon-wrapper">
                <i data-lucide="key" class="input-icon"></i>
                <input type="password" name="password" class="form-control form-control-pro" required placeholder="••••••••">
            </div>
        </div>

        <button type="submit" class="btn btn-primary-pro mb-3">
            Iniciar Sesión
        </button>

    </form>
</div>

<script>
    lucide.createIcons();
</script>
</body>
</html>