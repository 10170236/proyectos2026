<?php
session_start();
require_once 'conexion.php'; 

// --- SEGURIDAD ---
if (!isset($_SESSION['user_id']) || $_SESSION['rol'] !== 'docente') {
    header('Location: index.php?error=3');
    exit;
}

// Conexión
$host = 'localhost'; $db = 'gestion_academica'; $user = 'root'; $pass = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Error: " . $e->getMessage()); }

$docente_id = $_SESSION['user_id'];
$mensaje = "";

// --- LÓGICA DE ACCIONES (POST) EN PROYECTOS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Crear Proyecto
    if (isset($_POST['crear_proyecto'])) {
        $stmt = $pdo->prepare("INSERT INTO proyectos (nombre_proyecto, grupo_id, fecha_limite) VALUES (?, ?, ?)");
        $stmt->execute([trim($_POST['nombre_proyecto']), (int)$_POST['grupo_id'], $_POST['fecha_limite']]);
        $mensaje = "Proyecto publicado correctamente.";
    }

    // Editar Proyecto
    if (isset($_POST['editar_proyecto'])) {
        $stmt = $pdo->prepare("UPDATE proyectos SET nombre_proyecto = ?, fecha_limite = ? WHERE id = ?");
        $stmt->execute([trim($_POST['nombre_proyecto']), $_POST['fecha_limite'], (int)$_POST['proyecto_id']]);
        $mensaje = "Proyecto actualizado correctamente.";
    }

    // Agregar Tarea
    if (isset($_POST['agregar_tarea'])) {
        $stmt = $pdo->prepare("INSERT INTO tareas (titulo, proyecto_id, estado) VALUES (?, ?, 'Pendiente')");
        $stmt->execute([trim($_POST['titulo']), (int)$_POST['proyecto_id']]);
        $mensaje = "Tarea añadida al proyecto.";
    }
}

// --- CONSULTAS PARA LA VISTA ---
// 1. Grupos del docente (Solo para el selector al crear proyecto)
$grupos = $pdo->prepare("SELECT id, nombre_grupo FROM grupos WHERE docente_id = ?");
$grupos->execute([$docente_id]);
$grupos = $grupos->fetchAll(PDO::FETCH_ASSOC);

// 2. Proyectos con conteo de tareas, progreso real y fecha límite
$proyectos_stmt = $pdo->prepare("
    SELECT p.*, g.nombre_grupo,
    (SELECT COUNT(*) FROM tareas t WHERE t.proyecto_id = p.id) as total,
    (SELECT COUNT(*) FROM tareas t WHERE t.proyecto_id = p.id AND t.estado = 'Terminada') as completadas,
    (SELECT COUNT(*) FROM tareas t WHERE t.proyecto_id = p.id AND t.estado = 'En Proceso') as en_proceso
    FROM proyectos p
    JOIN grupos g ON p.grupo_id = g.id
    WHERE g.docente_id = ?
    ORDER BY p.fecha_limite ASC
");
$proyectos_stmt->execute([$docente_id]);
$proyectos = $proyectos_stmt->fetchAll(PDO::FETCH_ASSOC);

// 3. Detalle de tareas (si se selecciona un proyecto para ver)
$tareas_detalle = [];
$nombre_proyecto_visto = "";
if (isset($_GET['ver_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM tareas WHERE proyecto_id = ?");
    $stmt->execute([(int)$_GET['ver_id']]);
    $tareas_detalle = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener nombre del proyecto para el título
    $stmt_nombre = $pdo->prepare("SELECT nombre_proyecto FROM proyectos WHERE id = ?");
    $stmt_nombre->execute([(int)$_GET['ver_id']]);
    $nombre_proyecto_visto = $stmt_nombre->fetchColumn();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyectos </title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        :root { --primary-color: #4f46e5; --bg-body: #f8fafc; --sidebar-bg: #1e293b; }
        body { font-family: 'Inter', sans-serif; background-color: var(--bg-body); color: #334155; }
        .sidebar { background-color: var(--sidebar-bg); min-height: 100vh; color: white; padding-top: 2rem; position: fixed; width: inherit; }
        .nav-link { color: #94a3b8; margin-bottom: 0.5rem; transition: 0.3s; border-radius: 8px; padding: 0.8rem 1rem; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .card-pro { border: none; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); background: white; transition: transform 0.2s; }
        .card-pro:hover { transform: translateY(-5px); }
        .form-control, .form-select { border-radius: 10px; padding: 0.6rem 1rem; border: 1px solid #e2e8f0; }
        .btn-primary-pro { background-color: var(--primary-color); border: none; border-radius: 10px; padding: 0.6rem 1.5rem; font-weight: 600; color: white; }
        .btn-primary-pro:hover { background-color: #4338ca; color: white;}
        .progress { height: 8px; border-radius: 10px; background-color: #e2e8f0; }
        .progress-bar { background-color: var(--primary-color); }
        .badge-status { border-radius: 20px; padding: 0.4rem 0.8rem; font-size: 0.75rem; }
        .st-pendiente { background: #fee2e2; color: #991b1b; }
        .st-proceso { background: #fef3c7; color: #92400e; }
        .st-terminada { background: #dcfce7; color: #166534; }
        input[type="date"]::-webkit-calendar-picker-indicator { filter: invert(1); }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block sidebar shadow">
            <div class="px-4 mb-4">
                <h4 class="fw-bold text-white"><i class="fas fa-graduation-cap me-2"></i>Educ</h4>
            </div>
            <div class="nav flex-column px-3">
                <a class="nav-link" href="dashboard_docente.php"><i class="fas fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link" href="#"><i class="fas fa-users me-2"></i> Mis Grupos</a>
                <a class="nav-link active" href="proyectos.php"><i class="fas fa-folder-open me-2"></i> Proyectos</a>
                <a class="nav-link" href="avance_tareas.php"><i class="fas fa-tasks me-2"></i> Avance</a>
                <hr class="text-secondary">
                <a class="nav-link text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Cerrar Sesión</a>
            </div>
        </nav>

        <main class="col-md-10 ms-sm-auto px-md-4 py-4">
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-0">Gestión de Proyectos</h2>
                    <p class="text-muted">Crea, edita y supervisa los proyectos de tus grupos.</p>
                </div>
                <div class="dropdown">
                    <button class="btn btn-white shadow-sm border rounded-pill px-4 py-2">
                        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['nombre'] ?? 'Docente') ?>&background=4f46e5&color=fff" class="rounded-circle me-2" width="25">
                        <?= htmlspecialchars($_SESSION['nombre'] ?? 'Docente') ?>
                    </button>
                </div>
            </div>

            <?php if ($mensaje): ?>
                <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($mensaje) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row g-4">
                
                <div class="col-lg-4">
                    
                    <div class="card-pro p-4 mb-4 bg-dark text-white shadow-lg">
                        <h5 class="fw-bold mb-3"><i class="fas fa-rocket text-warning me-2"></i>Lanzar Proyecto</h5>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="small text-muted mb-1">Nombre del Proyecto</label>
                                <input type="text" name="nombre_proyecto" class="form-control bg-secondary text-white border-0" placeholder="Ej: Feria de Ciencias" required>
                            </div>
                            <div class="mb-3">
                                <label class="small text-muted mb-1">Asignar a Grupo</label>
                                <select name="grupo_id" class="form-select bg-secondary text-white border-0" required>
                                    <option value="" hidden>Seleccionar...</option>
                                    <?php foreach ($grupos as $g): ?>
                                        <option value="<?= $g['id'] ?>"><?= htmlspecialchars($g['nombre_grupo']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label class="small text-muted mb-1">Fecha Límite</label>
                                <input type="date" name="fecha_limite" class="form-control bg-secondary text-white border-0" required>
                            </div>
                            <button name="crear_proyecto" class="btn btn-light w-100 fw-bold text-dark">Crear Proyecto</button>
                        </form>
                    </div>

                    <?php if (isset($_GET['ver_id'])): ?>
                    <div class="card-pro p-4 bg-white border-top border-primary border-4 shadow-lg">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="fw-bold mb-0 text-primary">Tareas: <?= htmlspecialchars($nombre_proyecto_visto) ?></h6>
                            <a href="proyectos.php" class="btn-close small" title="Cerrar panel"></a>
                        </div>
                        <div class="list-group list-group-flush">
                            <?php foreach ($tareas_detalle as $td): 
                                $status_class = ($td['estado'] == 'Terminada') ? 'st-terminada' : (($td['estado'] == 'En Proceso') ? 'st-proceso' : 'st-pendiente');
                            ?>
                            <div class="list-group-item px-0 border-0 d-flex justify-content-between align-items-center">
                                <span class="small fw-medium text-dark text-truncate pe-2" style="max-width: 65%;"><?= htmlspecialchars($td['titulo']) ?></span>
                                <span class="badge badge-status <?= $status_class ?>"><?= $td['estado'] ?></span>
                            </div>
                            <?php endforeach; if(empty($tareas_detalle)) echo "<small class='text-muted'>No hay tareas registradas en este proyecto.</small>"; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>

                <div class="col-lg-8">
                    <h5 class="fw-bold mb-3"><i class="fas fa-folder-open text-secondary me-2"></i>Mis Proyectos Activos</h5>
                    
                    <div class="row g-3">
                        <?php foreach ($proyectos as $p): 
                            $porcentaje = ($p['total'] > 0) ? round(($p['completadas'] / $p['total']) * 100) : 0;
                            $fecha_texto = !empty($p['fecha_limite']) ? date("d/m/Y", strtotime($p['fecha_limite'])) : 'Sin fecha';
                            
                            // Validar si la fecha está vencida
                            $hoy = date("Y-m-d");
                            $es_vencido = (!empty($p['fecha_limite']) && $p['fecha_limite'] < $hoy) ? 'text-danger fw-bold' : 'text-muted';
                        ?>
                        <div class="col-md-6">
                            <div class="card-pro p-4 h-100 d-flex flex-column">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h6 class="fw-bold text-dark mb-0 pe-2"><?= htmlspecialchars($p['nombre_proyecto']) ?></h6>
                                    <button class="btn btn-sm text-muted p-0" onclick="prepararEditarProyecto(<?= $p['id'] ?>, '<?= addslashes($p['nombre_proyecto']) ?>', '<?= $p['fecha_limite'] ?>')" data-bs-toggle="modal" data-bs-target="#modalEditarProyecto" title="Editar Proyecto">
                                        <i class="fas fa-pen"></i>
                                    </button>
                                </div>
                                
                                <p class="text-muted small mb-3"><i class="fas fa-users me-1"></i> <?= htmlspecialchars($p['nombre_grupo']) ?></p>
                                
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between small text-muted mb-1">
                                        <span>Avance global</span>
                                        <span class="fw-bold text-dark"><?= $porcentaje ?>%</span>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" style="width: <?= $porcentaje ?>%;"></div>
                                    </div>
                                    <div class="small text-muted mt-1">
                                        <?= $p['completadas'] ?> de <?= $p['total'] ?> tareas listas
                                    </div>
                                </div>

                                <div class="mt-auto border-top pt-3 d-flex justify-content-between align-items-center">
                                    <span class="small <?= $es_vencido ?>"><i class="far fa-calendar-alt me-1"></i> <?= $fecha_texto ?></span>
                                    
                                    <div>
                                        <a href="?ver_id=<?= $p['id'] ?>" class="btn btn-sm btn-light border rounded-circle me-1" title="Ver lista de tareas">
                                            <i class="fas fa-eye text-primary"></i>
                                        </a>
                                        <button class="btn btn-sm btn-primary-pro rounded-circle px-2 py-1" onclick="prepararTarea(<?= $p['id'] ?>, '<?= addslashes($p['nombre_proyecto']) ?>')" data-bs-toggle="modal" data-bs-target="#modalTarea" title="Añadir nueva tarea">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; if(empty($proyectos)) echo "<div class='col-12'><div class='alert alert-light border'>No tienes proyectos activos. Comienza creando uno en el panel izquierdo.</div></div>"; ?>
                    </div>
                </div>

            </div>
        </main>
    </div>
</div>

<div class="modal fade" id="modalTarea" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content border-0 shadow" method="POST" style="border-radius: 20px;">
            <div class="modal-header border-0">
                <h5 class="fw-bold">Nueva Tarea para: <span id="proyecto_nombre_modal" class="text-primary"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="proyecto_id" id="proyecto_id_modal">
                <div class="mb-3">
                    <label class="small fw-bold text-muted">Descripción de la Tarea</label>
                    <input type="text" name="titulo" class="form-control" placeholder="Ej: Recopilar fuentes bibliográficas" required>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="submit" name="agregar_tarea" class="btn btn-primary-pro w-100 py-2">Guardar Tarea</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="modalEditarProyecto" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content border-0 shadow" method="POST" style="border-radius: 20px;">
            <div class="modal-header border-0">
                <h5 class="fw-bold">Editar Proyecto</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="proyecto_id" id="edit_proyecto_id">
                <div class="mb-3">
                    <label class="small fw-bold text-muted">Nombre del Proyecto</label>
                    <input type="text" name="nombre_proyecto" id="edit_proyecto_nombre" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold text-muted">Fecha Límite</label>
                    <input type="date" name="fecha_limite" id="edit_proyecto_fecha" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="submit" name="editar_proyecto" class="btn btn-primary-pro w-100 py-2">Actualizar Proyecto</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function prepararTarea(id, nombre) {
        document.getElementById('proyecto_id_modal').value = id;
        document.getElementById('proyecto_nombre_modal').innerText = nombre;
    }

    function prepararEditarProyecto(id, nombre, fecha) {
        document.getElementById('edit_proyecto_id').value = id;
        document.getElementById('edit_proyecto_nombre').value = nombre;
        document.getElementById('edit_proyecto_fecha').value = fecha;
    }
</script>
</body>
</html>