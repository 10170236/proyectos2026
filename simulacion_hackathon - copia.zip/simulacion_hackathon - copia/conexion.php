<?php
// Configuración de las credenciales (ajusta según tu entorno)
$host     = "localhost";
$usuario  = "root";
$password = ""; // Por defecto en XAMPP suele estar vacío
$db_name  = "gestion_academica";

// Crear la conexión
$conexion = new mysqli($host, $usuario, $password, $db_name);

// Verificar si hay errores de conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Configurar el conjunto de caracteres a UTF-8 para evitar problemas con tildes y eñes
$conexion->set_charset("utf8");

// Mensaje opcional para pruebas (puedes borrarlo después)
// echo "Conexión exitosa al sistema de gestión de proyectos.";
?><?php
// Configuración de las credenciales (ajusta según tu entorno)
$host     = "localhost";
$usuario  = "root";
$password = ""; // Por defecto en XAMPP suele estar vacío
$db_name  = "gestion_academica";

// Crear la conexión
$conexion = new mysqli($host, $usuario, $password, $db_name);

// Verificar si hay errores de conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Configurar el conjunto de caracteres a UTF-8 para evitar problemas con tildes y eñes
$conexion->set_charset("utf8");

// Mensaje opcional para pruebas (puedes borrarlo después)
 //echo "Conexión exitosa al sistema de gestión de proyectos.";
?>