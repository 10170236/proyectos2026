<?php
session_start();
require_once 'conexion.php'; 

if (!isset($_SESSION['user_id']) || $_SESSION['rol'] !== 'docente') {
    header('Location: index.php?error=3');
    exit;
}

$host = 'localhost'; $db = 'gestion_academica'; $user = 'root'; $pass = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Error: " . $e->getMessage()); }

$docente_id = $_SESSION['user_id'];
$mensaje = "";

// --- LÓGICA: ACTUALIZAR ESTADO DE TAREA ---
if (isset($_GET['cambiar_estado']) && isset($_GET['tarea_id'])) {
    $nuevo_estado = $_GET['cambiar_estado'];
    $t_id = (int)$_GET['tarea_id'];
    $stmt = $pdo->prepare("UPDATE tareas SET estado = ? WHERE id = ?");
    $stmt->execute([$nuevo_estado, $t_id]);
    header("Location: dashboard_docente.php?ver_id=" . $_GET['ver_id']); 
    exit;
}

// --- LÓGICA: AGREGAR TAREA ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar_tarea'])) {
    $stmt = $pdo->prepare("INSERT INTO tareas (titulo, proyecto_id, estado) VALUES (?, ?, 'Pendiente')");
    $stmt->execute([trim($_POST['titulo']), (int)$_POST['proyecto_id']]);
    $mensaje = "Tarea asignada correctamente.";
}

// --- CONSULTA DE AVANCE ---
$proyectos_stmt = $pdo->prepare("
    SELECT p.*, g.nombre_grupo,
    (SELECT COUNT(*) FROM tareas t WHERE t.proyecto_id = p.id) as total,
    (SELECT COUNT(*) FROM tareas t WHERE t.proyecto_id = p.id AND t.estado = 'Terminada') as listas,
    (SELECT COUNT(*) FROM tareas t WHERE t.proyecto_id = p.id AND t.estado = 'En Proceso') as proceso,
    (SELECT COUNT(*) FROM tareas t WHERE t.proyecto_id = p.id AND t.estado = 'Pendiente') as pendientes
    FROM proyectos p
    JOIN grupos g ON p.grupo_id = g.id
    WHERE g.docente_id = ?
    ORDER BY p.id DESC
");
$proyectos_stmt->execute([$docente_id]);
$proyectos = $proyectos_stmt->fetchAll(PDO::FETCH_ASSOC);

// Detalle de tareas optimizado
$tareas_detalle = ['Pendiente' => [], 'En Proceso' => [], 'Terminada' => []];
if (isset($_GET['ver_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM tareas WHERE proyecto_id = ?");
    $stmt->execute([(int)$_GET['ver_id']]);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $tareas_detalle[$row['estado']][] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docente Pro | Control Total</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root { --primary: #4f46e5; --bg: #f8fafc; --sidebar-bg: #1e293b; }
        body { font-family: 'Inter', sans-serif; background: var(--bg); color: #334155; }
        
        /* Sidebar Estilo Unificado */
        .sidebar { background-color: var(--sidebar-bg); min-height: 100vh; color: white; padding-top: 2rem; position: fixed; width: inherit; z-index: 1000; }
        .nav-link { color: #94a3b8; margin-bottom: 0.5rem; transition: 0.3s; border-radius: 8px; padding: 0.8rem 1rem; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .nav-link.active { background: var(--primary) !important; }

        /* Contenedor Principal */
        main { transition: all 0.3s; }

        /* Tarjetas Pro */
        .card-pro { border: none; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); background: white; margin-bottom: 1.5rem; transition: 0.3s; }
        .card-pro:hover { transform: translateY(-3px); }
        
        /* Elementos de Tarea */
        .progress-stacked { height: 10px; border-radius: 10px; overflow: hidden; background: #e2e8f0; }
        .task-item { border-left: 4px solid #cbd5e1; padding: 12px; margin-bottom: 10px; background: #fdfdfd; border-radius: 8px; }
        .task-item.pendiente { border-left-color: #ef4444; }
        .task-item.enproceso { border-left-color: #f59e0b; }
        .task-item.terminada { border-left-color: #10b981; }
        
        .border-dashed { border: 2px dashed #e2e8f0 !important; }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block sidebar shadow">
            <div class="px-4 mb-4">
                <h4 class="fw-bold text-white"><i class="fas fa-graduation-cap me-2"></i>EduManager</h4>
            </div>
            <div class="nav flex-column px-3">
                <a class="nav-link active" href="dashboard_docente.php"><i class="fas fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link" href="grupos.php"><i class="fas fa-users me-2"></i> Mis Grupos</a>
                <a class="nav-link" href="proyectos.php"><i class="fas fa-folder-open me-2"></i> Proyectos</a>
                <a class="nav-link" href="avance_tareas.php"><i class="fas fa-tasks me-2"></i> Avance</a>
                <hr class="text-secondary">
                <a class="nav-link text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Cerrar Sesión</a>
            </div>
        </nav>

        <main class="col-md-10 ms-sm-auto px-md-4 py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold m-0 text-dark">Panel de Seguimiento</h2>
                    <p class="text-muted mb-0">Gestión de proyectos y flujo de actividades.</p>
                </div>
                <div class="dropdown">
                    <button class="btn btn-white shadow-sm border rounded-pill px-4 py-2">
                        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['nombre'] ?? 'Docente') ?>&background=4f46e5&color=fff" class="rounded-circle me-2" width="25">
                        <?= htmlspecialchars($_SESSION['nombre'] ?? 'Docente') ?>
                    </button>
                </div>
            </div>

            <?php if ($mensaje): ?>
                <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($mensaje) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row g-4">
                <div class="col-lg-7">
                    <h5 class="fw-bold mb-3"><i class="fas fa-list-check text-primary me-2"></i>Proyectos Activos</h5>
                    <?php foreach ($proyectos as $p): 
                        $pct_l = ($p['total'] > 0) ? ($p['listas'] / $p['total']) * 100 : 0;
                        $pct_p = ($p['total'] > 0) ? ($p['proceso'] / $p['total']) * 100 : 0;
                    ?>
                    <div class="card-pro p-4 <?= (isset($_GET['ver_id']) && $_GET['ver_id'] == $p['id']) ? 'border-start border-primary border-4' : '' ?>">
                        <div class="row align-items-center">
                            <div class="col-md-7">
                                <h5 class="fw-bold mb-1 text-dark"><?= htmlspecialchars($p['nombre_proyecto']) ?></h5>
                                <p class="text-muted small mb-3"><i class="fas fa-users me-1"></i> <?= htmlspecialchars($p['nombre_grupo']) ?></p>
                                
                                <div class="progress-stacked mb-2">
                                    <div class="progress-bar bg-success" style="width: <?= $pct_l ?>%"></div>
                                    <div class="progress-bar bg-warning" style="width: <?= $pct_p ?>%"></div>
                                </div>
                                <div class="d-flex gap-3">
                                    <small class="text-muted"><b><?= $p['listas'] ?></b>/<?= $p['total'] ?> tareas listas</small>
                                </div>
                            </div>
                            <div class="col-md-5 text-end">
                                <div class="btn-group shadow-sm">
                                    <a href="?ver_id=<?= $p['id'] ?>" class="btn btn-sm btn-white border px-3">Inspeccionar</a>
                                    <button onclick="openModal(<?= $p['id'] ?>, '<?= addslashes($p['nombre_proyecto']) ?>')" class="btn btn-sm btn-primary px-3" data-bs-toggle="modal" data-bs-target="#addTask"><i class="fas fa-plus"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="col-lg-5">
                    <?php if (isset($_GET['ver_id'])): ?>
                    <div class="card-pro p-4 sticky-top" style="top: 20px;">
                        <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2">
                            <h5 class="fw-bold m-0 text-primary">Flujo de Trabajo</h5>
                            <a href="dashboard_docente.php" class="btn btn-light btn-sm rounded-circle"><i class="fas fa-times"></i></a>
                        </div>

                        <?php 
                        $estados_visual = [
                            'Pendiente' => ['bg' => 'text-danger', 'icon' => 'fa-clock'],
                            'En Proceso' => ['bg' => 'text-warning', 'icon' => 'fa-spinner'],
                            'Terminada' => ['bg' => 'text-success', 'icon' => 'fa-check-circle']
                        ];
                        
                        foreach ($estados_visual as $estado_nombre => $estilo): 
                            $slug = strtolower(str_replace(' ', '', $estado_nombre));
                        ?>
                            <h6 class="small fw-bold <?= $estilo['bg'] ?> mb-3">
                                <i class="fas <?= $estilo['icon'] ?> me-1"></i> <?= $estado_nombre ?> 
                                (<?= count($tareas_detalle[$estado_nombre]) ?>)
                            </h6>
                            
                            <?php foreach ($tareas_detalle[$estado_nombre] as $t): ?>
                            <div class="task-item <?= $slug ?> d-flex justify-content-between align-items-center shadow-sm">
                                <span class="small fw-medium"><?= htmlspecialchars($t['titulo']) ?></span>
                                <div class="dropdown">
                                    <button class="btn btn-link btn-sm p-0 text-muted" data-bs-toggle="dropdown"><i class="fas fa-ellipsis-v"></i></button>
                                    <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                        <?php foreach (['Pendiente', 'En Proceso', 'Terminada'] as $e): if($e != $estado_nombre): ?>
                                            <li><a class="dropdown-item small" href="?ver_id=<?= $_GET['ver_id'] ?>&tarea_id=<?= $t['id'] ?>&cambiar_estado=<?= $e ?>"><?= $e ?></a></li>
                                        <?php endif; endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <?php if (empty($tareas_detalle[$estado_nombre])): ?>
                                <p class="text-muted smaller ms-2 mb-4">No hay tareas.</p>
                            <?php else: echo '<div class="mb-4"></div>'; endif; ?>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <div class="card-pro p-5 text-center text-muted border-dashed">
                        <i class="fas fa-diagram-project fa-3x mb-3 opacity-25"></i>
                        <p>Selecciona un proyecto para gestionar sus actividades.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<div class="modal fade" id="addTask" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content border-0 shadow-lg" method="POST" style="border-radius: 20px;">
            <div class="modal-header bg-primary text-white border-0" style="border-radius: 20px 20px 0 0;">
                <h5 class="modal-title fw-bold">Nueva Tarea</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <p class="small text-muted mb-3">Proyecto: <span id="p_name" class="fw-bold text-dark"></span></p>
                <input type="hidden" name="proyecto_id" id="p_id">
                <label class="form-label small fw-bold text-uppercase">Descripción</label>
                <input type="text" name="titulo" class="form-control form-control-lg border-2" placeholder="Ej: Revisión de fase 1" required>
            </div>
            <div class="modal-footer border-0 p-4 pt-0">
                <button type="submit" name="agregar_tarea" class="btn btn-primary w-100 py-3 rounded-3 fw-bold shadow">Asignar Tarea</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function openModal(id, nombre) {
        document.getElementById('p_id').value = id;
        document.getElementById('p_name').innerText = nombre;
    }
</script>
</body>
</html>