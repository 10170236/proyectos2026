<?php
session_start();
require_once 'conexion.php'; 

// SEGURIDAD
if (!isset($_SESSION['user_id']) || $_SESSION['rol'] !== 'docente') {
    header('Location: index.php?error=3');
    exit;
}

// Configuración PDO
$host = 'localhost'; $db = 'gestion_academica'; $user = 'root'; $pass = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Error: " . $e->getMessage()); }

$docente_id = $_SESSION['user_id'];

// PROCESAR RETROALIMENTACIÓN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviar_retro'])) {
    $tarea_id = filter_input(INPUT_POST, 'tarea_id', FILTER_VALIDATE_INT);
    $comentario = htmlspecialchars($_POST['retro_texto']);
    
    if ($tarea_id && !empty($comentario)) {
        $ins = $pdo->prepare("INSERT INTO comentarios_tareas (tarea_id, usuario_id, comentario, tipo) VALUES (?, ?, ?, 'retroalimentacion')");
        $ins->execute([$tarea_id, $docente_id, $comentario]);
        header("Location: dashboard_docente.php?feedback=success");
        exit;
    }
}

// CONSULTAS PARA CARDS
$grupos = $pdo->prepare("SELECT * FROM grupos WHERE docente_id = ?");
$grupos->execute([$docente_id]);
$grupos_data = $grupos->fetchAll(PDO::FETCH_ASSOC);

$proyectos_stmt = $pdo->prepare("SELECT p.*, (SELECT COUNT(*) FROM tareas t WHERE t.proyecto_id = p.id) as total FROM proyectos p JOIN grupos g ON p.grupo_id = g.id WHERE g.docente_id = ?");
$proyectos_stmt->execute([$docente_id]);
$proyectos_data = $proyectos_stmt->fetchAll(PDO::FETCH_ASSOC);

// OBTENER AVANCES DE ALUMNOS (Solo avances, para responder)
$avances = $pdo->prepare("
    SELECT c.id as comentario_id, c.comentario, c.fecha_creacion, c.tarea_id, t.titulo as tarea, u.nombre as alumno 
    FROM comentarios_tareas c
    JOIN tareas t ON c.tarea_id = t.id
    JOIN usuarios u ON c.usuario_id = u.id
    WHERE c.tipo = 'avance' AND t.proyecto_id IN (
        SELECT p.id FROM proyectos p JOIN grupos g ON p.grupo_id = g.id WHERE g.docente_id = ?
    )
    ORDER BY c.fecha_creacion DESC
");
$avances->execute([$docente_id]);
$lista_avances = $avances->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docente  </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root { --sidebar-bg: #1e293b; --primary: #4f46e5; }
        body { background-color: #f8fafc; font-family: 'Inter', sans-serif; overflow-x: hidden; }
        .sidebar { background: var(--sidebar-bg); min-height: 100vh; color: white; position: fixed; width: 250px; z-index: 100; }
        .nav-link { color: #94a3b8; padding: 0.8rem 1.5rem; border-radius: 8px; margin: 0 10px 5px 10px; transition: 0.3s; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .main-content { margin-left: 250px; padding: 2.5rem; width: calc(100% - 250px); }
        .card-pro { border: none; border-radius: 16px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); background: white; }
        .modal-backdrop { z-index: 1040 !important; }
        .modal { z-index: 1050 !important; }
    </style>
</head>
<body>

<div class="sidebar shadow">
    <div class="p-4 mb-3"><h4 class="fw-bold"><i class="fas fa-graduation-cap me-2"></i>Educ</h4></div>
    <div class="nav flex-column">
        <a class="nav-link active" href="dashboard_docente.php"><i class="fas fa-chart-line me-2"></i> Dashboard</a>
        <a class="nav-link" href="grupos.php"><i class="fas fa-users me-2"></i> Mis Grupos</a>
        <a class="nav-link" href="proyectos.php"><i class="fas fa-folder-open me-2"></i> Proyectos</a>
        <a class="nav-link" href="avance_tareas.php"><i class="fas fa-tasks me-2"></i> Avance</a>
        <hr class="mx-3 text-secondary">
        <a class="nav-link text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Cerrar Sesión</a>
    </div>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-5">
        <div>
            <h2 class="fw-bold mb-1">Panel General</h2>
            <p class="text-muted">Gestión de proyectos y retroalimentación académica.</p>
        </div>
        <div class="d-flex align-items-center bg-white p-2 rounded-pill shadow-sm px-3 border">
            <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['nombre'] ?? 'Docente') ?>&background=4f46e5&color=fff" class="rounded-circle me-2" width="32">
            <span class="fw-bold small"><?= htmlspecialchars($_SESSION['nombre'] ?? 'Docente') ?></span>
        </div>
    </div>

    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card-pro p-4 border-start border-primary border-5">
                <small class="text-muted fw-bold">PROYECTOS</small>
                <h2 class="fw-bold mt-1"><?= count($proyectos_data) ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-pro p-4 border-start border-success border-5">
                <small class="text-muted fw-bold">GRUPOS</small>
                <h2 class="fw-bold mt-1"><?= count($grupos_data) ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-pro p-4 border-start border-warning border-5">
                <small class="text-muted fw-bold">TAREAS TOTALES</small>
                <h2 class="fw-bold mt-1"><?= array_sum(array_column($proyectos_data, 'total')) ?></h2>
            </div>
        </div>
    </div>

    <div class="card-pro p-4">
        <h5 class="fw-bold mb-4"><i class="fas fa-comments text-primary me-2"></i> Revisión de Avances Estudiantiles</h5>
        <div class="table-responsive">
            <table class="table align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Estudiante</th>
                        <th>Tarea</th>
                        <th>Avance Reportado</th>
                        <th>Fecha</th>
                        <th class="text-end">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($lista_avances)): foreach($lista_avances as $av): ?>
                        <tr>
                            <td><span class="fw-bold"><?= htmlspecialchars($av['alumno']) ?></span></td>
                            <td><span class="badge bg-light text-dark border px-2"><?= htmlspecialchars($av['tarea']) ?></span></td>
                            <td class="small text-muted text-truncate" style="max-width: 250px;"><?= htmlspecialchars($av['comentario']) ?></td>
                            <td class="small"><?= date('d/m/y H:i', strtotime($av['fecha_creacion'])) ?></td>
                            <td class="text-end">
                                <button type="button" class="btn btn-sm btn-primary px-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#modalRetro<?= $av['comentario_id'] ?>">
                                    <i class="fas fa-reply me-1"></i> Responder
                                </button>
                            </td>
                        </tr>

                        <div class="modal fade" id="modalRetro<?= $av['comentario_id'] ?>" tabindex="-1" aria-labelledby="label<?= $av['comentario_id'] ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content border-0 shadow">
                                    <form action="dashboard_docente.php" method="POST">
                                        <div class="modal-header bg-light">
                                            <h5 class="modal-title fw-bold" id="label<?= $av['comentario_id'] ?>">Responder a <?= $av['alumno'] ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <input type="hidden" name="tarea_id" value="<?= $av['tarea_id'] ?>">
                                            <div class="mb-3">
                                                <label class="form-label small fw-bold text-muted">Comentario del alumno:</label>
                                                <div class="p-3 rounded bg-light border small italic text-secondary">
                                                    "<?= htmlspecialchars($av['comentario']) ?>"
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="retro_texto<?= $av['comentario_id'] ?>" class="form-label small fw-bold">Tu Retroalimentación:</label>
                                                <textarea id="retro_texto<?= $av['comentario_id'] ?>" name="retro_texto" class="form-control" rows="4" placeholder="Escribe consejos o correcciones..." required></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer bg-light">
                                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                                            <button type="submit" name="enviar_retro" class="btn btn-primary btn-sm px-4 fw-bold">Enviar Feedback</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; else: ?>
                        <tr><td colspan="5" class="text-center py-4 text-muted">No hay nuevos avances para revisar.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>