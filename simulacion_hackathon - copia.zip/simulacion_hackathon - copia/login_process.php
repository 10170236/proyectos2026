<?php
session_start();
require_once 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $email = trim($_POST['email']);
    $password = $_POST['password'];

 
    $stmt = $conexion->prepare("SELECT id, nombre, password, rol FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if (password_verify($password, $user['password'])) {
            
       
            session_regenerate_id(true);

     
            $_SESSION['user_id'] = $user['id']; 
            $_SESSION['nombre']  = $user['nombre'];
            $_SESSION['rol']     = $user['rol'];

       
            if ($user['rol'] == 'docente') {
                header("Location: dashboard_docente.php");
            } else if ($user['rol'] == 'estudiante') {
                header("Location: dashboard_estudiante.php");
            } else {
             
                header("Location: index.php");
            }
            exit();

        } else {
           
            header("Location: index.php?error=1");
            exit();
        }
    } else {
       
        header("Location: index.php?error=2");
        exit();
    }
}
?>