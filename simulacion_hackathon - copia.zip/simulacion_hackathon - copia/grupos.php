<?php
session_start();
require_once 'conexion.php'; 

// --- SEGURIDAD ---
if (!isset($_SESSION['user_id']) || $_SESSION['rol'] !== 'docente') {
    header('Location: index.php?error=3');
    exit;
}

// Conexión
$host = 'localhost'; $db = 'gestion_academica'; $user = 'root'; $pass = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("Error: " . $e->getMessage()); }

$docente_id = $_SESSION['user_id'];
$mensaje = "";

// --- LÓGICA DE ACCIONES (POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Crear Grupo
    if (isset($_POST['crear_grupo'])) {
        $stmt = $pdo->prepare("INSERT INTO grupos (nombre_grupo, docente_id) VALUES (?, ?)");
        $stmt->execute([trim($_POST['nombre_grupo']), $docente_id]);
        $mensaje = "Grupo creado con éxito.";
    }

    // Editar Grupo
    if (isset($_POST['editar_grupo'])) {
        $stmt = $pdo->prepare("UPDATE grupos SET nombre_grupo = ? WHERE id = ? AND docente_id = ?");
        $stmt->execute([trim($_POST['nombre_grupo']), (int)$_POST['grupo_id'], $docente_id]);
        $mensaje = "Nombre del grupo actualizado.";
    }

    // Eliminar Grupo (Libera a los estudiantes primero)
    if (isset($_POST['eliminar_grupo'])) {
        $grupo_id = (int)$_POST['grupo_id'];
        // 1. Quitar el grupo a los estudiantes asignados
        $pdo->prepare("UPDATE usuarios SET grupo_id = NULL WHERE grupo_id = ?")->execute([$grupo_id]);
        // 2. Eliminar el grupo
        $stmt = $pdo->prepare("DELETE FROM grupos WHERE id = ? AND docente_id = ?");
        $stmt->execute([$grupo_id, $docente_id]);
        $mensaje = "Grupo eliminado. Los estudiantes han sido desasignados.";
    }

    // Asignar Estudiante al Grupo
    if (isset($_POST['asignar_estudiante'])) {
        $stmt = $pdo->prepare("UPDATE usuarios SET grupo_id = ? WHERE id = ? AND rol = 'estudiante'");
        $stmt->execute([(int)$_POST['grupo_id'], (int)$_POST['estudiante_id']]);
        $mensaje = "Estudiante agregado al grupo.";
    }

    // Quitar Estudiante del Grupo
    if (isset($_POST['quitar_estudiante'])) {
        $stmt = $pdo->prepare("UPDATE usuarios SET grupo_id = NULL WHERE id = ? AND rol = 'estudiante'");
        $stmt->execute([(int)$_POST['estudiante_id']]);
        $mensaje = "Estudiante removido del grupo.";
    }
}

// --- CONSULTAS PARA LA VISTA ---
// 1. Obtener los grupos del docente con conteo de estudiantes
$stmt_grupos = $pdo->prepare("
    SELECT g.*, 
    (SELECT COUNT(*) FROM usuarios u WHERE u.grupo_id = g.id AND u.rol = 'estudiante') as total_alumnos 
    FROM grupos g WHERE g.docente_id = ? ORDER BY g.id DESC
");
$stmt_grupos->execute([$docente_id]);
$grupos = $stmt_grupos->fetchAll(PDO::FETCH_ASSOC);

// 2. Obtener estudiantes SIN grupo (para el selector de asignación)
$estudiantes_libres = $pdo->query("SELECT id, nombre FROM usuarios WHERE rol = 'estudiante' AND (grupo_id IS NULL OR grupo_id = 0)")->fetchAll(PDO::FETCH_ASSOC);

// 3. Detalle de estudiantes (si se selecciona un grupo para ver)
$alumnos_grupo = [];
$nombre_grupo_visto = "";
if (isset($_GET['ver_grupo'])) {
    $ver_id = (int)$_GET['ver_grupo'];
    $stmt = $pdo->prepare("SELECT id, nombre FROM usuarios WHERE grupo_id = ? AND rol = 'estudiante' ORDER BY nombre ASC");
    $stmt->execute([$ver_id]);
    $alumnos_grupo = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener nombre del grupo para el título
    $stmt_nombre = $pdo->prepare("SELECT nombre_grupo FROM grupos WHERE id = ?");
    $stmt_nombre->execute([$ver_id]);
    $nombre_grupo_visto = $stmt_nombre->fetchColumn();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grupos | Educ</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        :root { --primary-color: #4f46e5; --bg-body: #f8fafc; --sidebar-bg: #1e293b; }
        body { font-family: 'Inter', sans-serif; background-color: var(--bg-body); color: #334155; }
        .sidebar { background-color: var(--sidebar-bg); min-height: 100vh; color: white; padding-top: 2rem; position: fixed; width: inherit; }
        .nav-link { color: #94a3b8; margin-bottom: 0.5rem; transition: 0.3s; border-radius: 8px; padding: 0.8rem 1rem; }
        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .card-pro { border: none; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); background: white; transition: transform 0.2s; }
        .card-pro:hover { transform: translateY(-5px); }
        .form-control, .form-select { border-radius: 10px; padding: 0.6rem 1rem; border: 1px solid #e2e8f0; }
        .btn-primary-pro { background-color: var(--primary-color); border: none; border-radius: 10px; padding: 0.6rem 1.5rem; font-weight: 600; color: white; }
        .btn-primary-pro:hover { background-color: #4338ca; color: white;}
        .avatar-circle { width: 40px; height: 40px; border-radius: 50%; background-color: #e0e7ff; color: var(--primary-color); display: flex; align-items: center; justify-content: center; font-weight: bold; }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block sidebar shadow">
            <div class="px-4 mb-4">
                <h4 class="fw-bold text-white"><i class="fas fa-graduation-cap me-2"></i>Educ</h4>
            </div>
            <div class="nav flex-column px-3">
                <a class="nav-link" href="dashboard_docente.php"><i class="fas fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link active" href="grupos.php"><i class="fas fa-users me-2"></i> Mis Grupos</a>
                <a class="nav-link" href="proyectos.php"><i class="fas fa-folder-open me-2"></i> Proyectos</a>
                <a class="nav-link" href="avance_tareas.php"><i class="fas fa-tasks me-2"></i> Avance</a>
                <hr class="text-secondary">
                <a class="nav-link text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Cerrar Sesión</a>
            </div>
        </nav>
        

        <main class="col-md-10 ms-sm-auto px-md-4 py-4">
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-0">Gestión de Grupos</h2>
                    <p class="text-muted">Organiza a tus estudiantes y administra tus clases.</p>
                </div>
                <div class="dropdown">
                    <button class="btn btn-white shadow-sm border rounded-pill px-4 py-2">
                        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['nombre'] ?? 'Docente') ?>&background=4f46e5&color=fff" class="rounded-circle me-2" width="25">
                        <?= htmlspecialchars($_SESSION['nombre'] ?? 'Docente') ?>
                    </button>
                </div>
            </div>

            <?php if ($mensaje): ?>
                <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($mensaje) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row g-4">
                
                <div class="col-lg-4">
                    
                    <div class="card-pro p-4 mb-4">
                        <ul class="nav nav-pills nav-fill bg-light p-1 rounded-pill mb-4" id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <button class="nav-link active rounded-pill py-1 small fw-bold" data-bs-toggle="pill" data-bs-target="#tab-nuevo">Nuevo Grupo</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link rounded-pill py-1 small fw-bold" data-bs-toggle="pill" data-bs-target="#tab-asignar">Agregar Alumno</button>
                            </li>
                        </ul>

                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="tab-nuevo">
                                <form method="POST">
                                    <label class="small text-muted mb-1 fw-bold">Nombre del Grupo</label>
                                    <input type="text" name="nombre_grupo" class="form-control mb-3" placeholder="Ej: Programación 101" required>
                                    <button name="crear_grupo" class="btn btn-primary-pro w-100 shadow-sm"><i class="fas fa-plus me-2"></i>Crear Grupo</button>
                                </form>
                            </div>
                            <div class="tab-pane fade" id="tab-asignar">
                                <form method="POST">
                                    <label class="small text-muted mb-1 fw-bold">Estudiante sin grupo</label>
                                    <select name="estudiante_id" class="form-select mb-2" required>
                                        <option value="" hidden>Seleccionar Estudiante...</option>
                                        <?php foreach ($estudiantes_libres as $est): ?>
                                            <option value="<?= $est['id'] ?>"><?= htmlspecialchars($est['nombre']) ?></option>
                                        <?php endforeach; ?>
                                        <?php if(empty($estudiantes_libres)) echo "<option disabled>Todos tienen grupo asignado</option>"; ?>
                                    </select>
                                    
                                    <label class="small text-muted mb-1 mt-2 fw-bold">Asignar al Grupo</label>
                                    <select name="grupo_id" class="form-select mb-3" required>
                                        <option value="" hidden>Seleccionar Grupo...</option>
                                        <?php foreach ($grupos as $g): ?>
                                            <option value="<?= $g['id'] ?>"><?= htmlspecialchars($g['nombre_grupo']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button name="asignar_estudiante" class="btn btn-dark w-100 shadow-sm"><i class="fas fa-user-plus me-2"></i>Asignar Estudiante</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <?php if (isset($_GET['ver_grupo'])): ?>
                    <div class="card-pro p-4 bg-white border-top border-success border-4 shadow-lg">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="fw-bold mb-0 text-success"><i class="fas fa-users me-2"></i><?= htmlspecialchars($nombre_grupo_visto) ?></h6>
                            <a href="grupos.php" class="btn-close small" title="Cerrar panel"></a>
                        </div>
                        <div class="list-group list-group-flush">
                            <?php foreach ($alumnos_grupo as $alumno): ?>
                            <div class="list-group-item px-0 border-0 d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center">
                                    <div class="avatar-circle me-3" style="width: 30px; height: 30px; font-size: 0.8rem;">
                                        <?= strtoupper(substr($alumno['nombre'], 0, 1)) ?>
                                    </div>
                                    <span class="small fw-medium text-dark"><?= htmlspecialchars($alumno['nombre']) ?></span>
                                </div>
                                <form method="POST" class="m-0" onsubmit="return confirm('¿Seguro que deseas remover a este estudiante del grupo?');">
                                    <input type="hidden" name="estudiante_id" value="<?= $alumno['id'] ?>">
                                    <button type="submit" name="quitar_estudiante" class="btn btn-sm btn-outline-danger border-0 rounded-circle" title="Remover del grupo">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </form>
                            </div>
                            <?php endforeach; if(empty($alumnos_grupo)) echo "<small class='text-muted'>No hay estudiantes en este grupo.</small>"; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>

                <div class="col-lg-8">
                    <h5 class="fw-bold mb-3"><i class="fas fa-layer-group text-primary me-2"></i>Mis Grupos Activos</h5>
                    
                    <div class="row g-3">
                        <?php foreach ($grupos as $g): ?>
                        <div class="col-md-6">
                            <div class="card-pro p-4 h-100 d-flex flex-column border-start border-primary border-4">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <h5 class="fw-bold text-dark mb-0"><?= htmlspecialchars($g['nombre_grupo']) ?></h5>
                                    <div class="dropdown">
                                        <button class="btn btn-sm text-muted" type="button" data-bs-toggle="dropdown">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end shadow border-0" style="border-radius: 12px;">
                                            <li><a class="dropdown-item small" href="#" onclick="prepararEditarGrupo(<?= $g['id'] ?>, '<?= addslashes($g['nombre_grupo']) ?>')" data-bs-toggle="modal" data-bs-target="#modalEditarGrupo"><i class="fas fa-pen me-2 text-primary"></i> Editar Nombre</a></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item small text-danger" href="#" onclick="prepararEliminarGrupo(<?= $g['id'] ?>, '<?= addslashes($g['nombre_grupo']) ?>')" data-bs-toggle="modal" data-bs-target="#modalEliminarGrupo"><i class="fas fa-trash me-2"></i> Eliminar Grupo</a></li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <div class="d-flex align-items-center mb-4 mt-2">
                                    <div class="avatar-circle me-3 bg-light text-secondary">
                                        <i class="fas fa-user-graduate"></i>
                                    </div>
                                    <div>
                                        <h4 class="fw-bold mb-0 text-dark"><?= $g['total_alumnos'] ?></h4>
                                        <small class="text-muted">Estudiantes inscritos</small>
                                    </div>
                                </div>

                                <div class="mt-auto pt-3 d-flex justify-content-between align-items-center">
                                    <a href="?ver_grupo=<?= $g['id'] ?>" class="btn btn-sm btn-light border rounded-pill px-3 fw-bold text-primary">
                                        <i class="fas fa-eye me-1"></i> Ver Alumnos
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; if(empty($grupos)) echo "<div class='col-12'><div class='alert alert-light border'>No tienes grupos creados. Usa el panel izquierdo para crear uno.</div></div>"; ?>
                    </div>
                </div>

            </div>
        </main>
    </div>
</div>

<div class="modal fade" id="modalEditarGrupo" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <form class="modal-content border-0 shadow" method="POST" style="border-radius: 20px;">
            <div class="modal-header border-0 pb-0">
                <h6 class="fw-bold mb-0">Renombrar Grupo</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="grupo_id" id="edit_grupo_id">
                <input type="text" name="nombre_grupo" id="edit_grupo_nombre" class="form-control" required>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="submit" name="editar_grupo" class="btn btn-primary-pro w-100 py-2">Guardar Cambios</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="modalEliminarGrupo" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <form class="modal-content border-0 shadow" method="POST" style="border-radius: 20px;">
            <div class="modal-header border-0 bg-danger text-white" style="border-radius: 20px 20px 0 0;">
                <h6 class="fw-bold mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Eliminar Grupo</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center py-4">
                <input type="hidden" name="grupo_id" id="delete_grupo_id">
                <p class="mb-0">¿Estás seguro de que deseas eliminar el grupo <strong id="delete_grupo_nombre" class="text-danger"></strong>?</p>
                <small class="text-muted">Los estudiantes no se borrarán, solo quedarán sin grupo asignado.</small>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" name="eliminar_grupo" class="btn btn-danger px-4">Sí, eliminar</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function prepararEditarGrupo(id, nombre) {
        document.getElementById('edit_grupo_id').value = id;
        document.getElementById('edit_grupo_nombre').value = nombre;
    }

    function prepararEliminarGrupo(id, nombre) {
        document.getElementById('delete_grupo_id').value = id;
        document.getElementById('delete_grupo_nombre').innerText = nombre;
    }
</script>
</body>
</html>