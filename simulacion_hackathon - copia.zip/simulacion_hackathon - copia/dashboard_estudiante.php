<?php
session_start();
require_once 'conexion.php'; 

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'estudiante') {
    header("Location: index.php");
    exit();
}

$estudiante_id = $_SESSION['user_id']; 
$nombre_estudiante = $_SESSION['nombre'] ?? 'Estudiante';
$mensaje_sistema = '';

// ... (Mantenemos tu lógica de procesamiento POST intacta) ...
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_estado'])) {
    $tarea_id = filter_input(INPUT_POST, 'tarea_id', FILTER_VALIDATE_INT);
    $nuevo_estado = htmlspecialchars($_POST['nuevo_estado']);
    if ($tarea_id && $nuevo_estado) {
        $stmt_update = $conexion->prepare("UPDATE tareas SET estado = ? WHERE id = ?");
        $stmt_update->bind_param("si", $nuevo_estado, $tarea_id);
        if ($stmt_update->execute()) {
            $mensaje_sistema = 'success|Estado actualizado correctamente.';
        }
        $stmt_update->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviar_comentario'])) {
    $tarea_id = filter_input(INPUT_POST, 'tarea_id_comentario', FILTER_VALIDATE_INT);
    $comentario = htmlspecialchars($_POST['comentario']);
    if ($tarea_id && !empty($comentario)) {
        $stmt_com = $conexion->prepare("INSERT INTO comentarios_tareas (tarea_id, usuario_id, comentario, tipo) VALUES (?, ?, ?, 'avance')");
        $stmt_com->bind_param("iis", $tarea_id, $estudiante_id, $comentario);
        if ($stmt_com->execute()) {
            $mensaje_sistema = 'primary|Avance registrado con éxito.';
        }
        $stmt_com->close();
    }
}

// Obtener datos
$query = "SELECT p.nombre_proyecto AS proyecto_nombre, t.id AS tarea_id, t.titulo AS tarea_titulo, t.estado
          FROM estudiantes_grupos AS eg
          JOIN grupos AS g ON eg.grupo_id = g.id
          JOIN proyectos AS p ON g.id = p.grupo_id
          JOIN tareas AS t ON p.id = t.proyecto_id
          WHERE eg.usuario_id = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $estudiante_id);
$stmt->execute();
$resultado = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Estudiante | EduManager Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #6366f1 0%, #4338ca 100%);
            --glass-bg: rgba(255, 255, 255, 0.95);
            --body-bg: #f3f4f6;
            --text-main: #1f2937;
        }

        body { 
            background-color: var(--body-bg); 
            font-family: 'Inter', sans-serif; 
            color: var(--text-main);
            letter-spacing: -0.01em;
        }

        /* Modern Navbar */
        .navbar-custom {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 1rem 0;
        }

        /* Card Styling */
        .card-pro {
            border: none;
            border-radius: 16px;
            background: #ffffff;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.04), 0 8px 10px -6px rgba(0,0,0,0.04);
            transition: transform 0.2s ease;
        }

        .card-header-pro {
            background: transparent;
            border-bottom: 1px solid #f1f5f9;
            padding: 1.25rem;
            font-weight: 700;
            color: #111827;
        }

        /* Status Badges */
        .badge-pro {
            padding: 0.5em 1em;
            font-weight: 600;
            border-radius: 8px;
            text-transform: uppercase;
            font-size: 0.7rem;
        }

        /* Custom Table */
        .table thead th {
            background-color: #f8fafc;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.05em;
            color: #64748b;
            border: none;
            padding: 1rem;
        }

        .table tbody td {
            padding: 1.2rem 1rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }

        /* Profile Section */
        .profile-chip {
            background: #f1f5f9;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Input styling */
        .form-control, .form-select {
            border-radius: 10px;
            border: 1px solid #e2e8f0;
            padding: 0.6rem 1rem;
        }

        .form-control:focus {
            box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
            border-color: #6366f1;
        }

        .btn-primary-pro {
            background: var(--primary-gradient);
            border: none;
            color: white;
            padding: 0.6rem 1.2rem;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary-pro:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }
    </style>
</head>
<body>

<nav class="navbar navbar-custom sticky-top mb-5">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center text-dark fw-bold" href="#">
            <div class="bg-primary text-white rounded-3 p-2 me-2 d-flex">
                <i class="bi bi-grid-1x2-fill"></i>
            </div>
            EduManager <span class="text-primary ms-1">PRO</span>
        </a>
        
        <div class="d-flex align-items-center gap-3">
            <div class="profile-chip d-none d-md-flex">
                <img src="https://ui-avatars.com/api/?name=<?= urlencode($nombre_estudiante) ?>&background=6366f1&color=fff" class="rounded-circle" width="32" alt="">
                <span class="small fw-semibold"><?= htmlspecialchars($nombre_estudiante); ?></span>
            </div>
            <a href="logout.php" class="btn btn-outline-danger btn-sm rounded-3">
                <i class="bi bi-box-arrow-right me-1"></i> Salir
            </a>
        </div>
    </div>
</nav>

<div class="container pb-5">
    <?php if($mensaje_sistema): 
        list($tipo, $txt) = explode('|', $mensaje_sistema); ?>
        <div class="alert alert-<?= $tipo ?> alert-dismissible fade show border-0 shadow-sm rounded-4 mb-4" role="alert">
            <div class="d-flex align-items-center">
                <i class="bi bi-info-circle-fill me-2 fs-5"></i>
                <div><?= $txt ?></div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <div class="col-xl-8">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold m-0 text-dark">Mis Asignaciones</h3>
                <span class="badge bg-white text-dark shadow-sm py-2 px-3 rounded-3">
                    <i class="bi bi-calendar3 me-2 text-primary"></i> <?= date('d M, Y') ?>
                </span>
            </div>

            <div class="card card-pro overflow-hidden">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Proyecto / Tarea</th>
                                <th class="text-center">Progreso</th>
                                <th class="text-end">Gestión</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($resultado->num_rows > 0): 
                                while ($row = $resultado->fetch_assoc()): 
                                    $clase_badge = match($row['estado']) {
                                        'Pendiente' => 'bg-danger-subtle text-danger',
                                        'En proceso' => 'bg-warning-subtle text-warning-emphasis',
                                        'Terminada' => 'bg-success-subtle text-success',
                                        default => 'bg-secondary-subtle text-secondary'
                                    };
                            ?>
                                <tr>
                                    <td>
                                        <div class="fw-bold mb-0"><?= htmlspecialchars($row['tarea_titulo']); ?></div>
                                        <div class="text-muted small"><i class="bi bi-folder2-open me-1"></i><?= htmlspecialchars($row['proyecto_nombre']); ?></div>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge-pro <?= $clase_badge; ?> d-inline-block">
                                            <?= $row['estado']; ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <form method="POST" class="d-flex justify-content-end gap-2">
                                            <input type="hidden" name="tarea_id" value="<?= $row['tarea_id']; ?>">
                                            <select name="nuevo_estado" class="form-select form-select-sm w-auto shadow-sm">
                                                <option value="Pendiente" <?= ($row['estado'] == 'Pendiente') ? 'selected' : ''; ?>>Pendiente</option>
                                                <option value="En proceso" <?= ($row['estado'] == 'En proceso') ? 'selected' : ''; ?>>En proceso</option>
                                                <option value="Terminada" <?= ($row['estado'] == 'Terminada') ? 'selected' : ''; ?>>Terminada</option>
                                            </select>
                                            <button type="submit" name="actualizar_estado" class="btn btn-primary btn-sm rounded-3">
                                                <i class="bi bi-send-fill"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; else: ?>
                                <tr><td colspan="3" class="text-center py-5">
                                    <i class="bi bi-clipboard-x fs-1 text-muted d-block mb-2"></i>
                                    <span class="text-muted">No tienes tareas asignadas actualmente.</span>
                                </td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            <div class="card card-pro mb-4 border-top border-primary border-4">
                <div class="card-header-pro d-flex align-items-center">
                    <i class="bi bi-chat-left-dots me-2 text-primary"></i> Reportar Avance
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Seleccionar Tarea</label>
                            <select name="tarea_id_comentario" class="form-select shadow-sm" required>
                                <?php $resultado->data_seek(0); while($t = $resultado->fetch_assoc()): ?>
                                    <option value="<?= $t['tarea_id'] ?>"><?= htmlspecialchars($t['tarea_titulo']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Comentario o Duda</label>
                            <textarea name="comentario" class="form-control shadow-sm" rows="4" placeholder="¿Qué has logrado hoy?" required></textarea>
                        </div>
                        <button type="submit" name="enviar_comentario" class="btn btn-primary-pro w-100">
                            <i class="bi bi-cloud-upload me-2"></i>Enviar Reporte
                        </button>
                    </form>
                </div>
            </div>

            <div class="card card-pro border-top border-success border-4">
                <div class="card-header-pro d-flex align-items-center">
                    <i class="bi bi-lightning-charge me-2 text-success"></i> Feedback Reciente
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php
                        $q_retro = "SELECT c.*, t.titulo as t_nombre FROM comentarios_tareas c 
                                    JOIN tareas t ON c.tarea_id = t.id 
                                    WHERE c.tipo = 'retroalimentacion' AND t.proyecto_id IN (SELECT id FROM proyectos WHERE grupo_id IN (SELECT grupo_id FROM estudiantes_grupos WHERE usuario_id = ?))
                                    ORDER BY c.fecha_creacion DESC LIMIT 3";
                        $st_retro = $conexion->prepare($q_retro);
                        $st_retro->bind_param("i", $estudiante_id);
                        $st_retro->execute();
                        $retros = $st_retro->get_result();
                        
                        if($retros->num_rows > 0):
                            while($r = $retros->fetch_assoc()): ?>
                            <div class="list-group-item p-3 border-0 border-bottom">
                                <div class="d-flex justify-content-between mb-1">
                                    <span class="badge bg-success-subtle text-success small"><?= htmlspecialchars($r['t_nombre']) ?></span>
                                    <span class="text-muted" style="font-size: 0.7rem;"><i class="bi bi-clock"></i> <?= date('d/m', strtotime($r['fecha_creacion'])) ?></span>
                                </div>
                                <p class="mb-0 small text-dark opacity-75">"<?= htmlspecialchars($r['comentario']) ?>"</p>
                            </div>
                        <?php endwhile; else: ?>
                            <div class="p-4 text-center text-muted small fst-italic">Sin retroalimentaciones aún.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>