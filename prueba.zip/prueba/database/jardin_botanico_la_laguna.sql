-- ============================================================
--  SISTEMA DE INVENTARIO · JARDÍN BOTÁNICO LA LAGUNA
--  Antiguo Cuscatlán, La Libertad, El Salvador
-- ------------------------------------------------------------
--  Autor    : 3er Año · Especialidad Desarrollo de Software
--  Visita   : Investigación de Campo en Jardín Botánico
--  Motor    : SQL Server (T-SQL)
--  Tablas   : 6 entidades (DER)
-- ============================================================

-- ── Crear base de datos ─────────────────────────────────────
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'jardin_botanico_la_laguna')
    DROP DATABASE jardin_botanico_la_laguna;
GO

CREATE DATABASE jardin_botanico_la_laguna;
GO

USE jardin_botanico_la_laguna;
GO

-- ============================================================
--  TABLA 1: ESTADO_CONSERVACION
-- ============================================================
CREATE TABLE Estado_Conservacion (
    id_estado       INT             NOT NULL IDENTITY(1,1),
    codigo_estado   VARCHAR(10)     NOT NULL,
    nombre_estado   VARCHAR(80)     NOT NULL,
    descripcion     VARCHAR(MAX),
    nivel_riesgo    VARCHAR(20)     NOT NULL DEFAULT 'Bajo'
        CONSTRAINT chk_nivel_riesgo
            CHECK (nivel_riesgo IN ('Bajo','Moderado','Alto','Crítico')),
    organismo       VARCHAR(50)     NOT NULL DEFAULT 'UICN',

    CONSTRAINT pk_estado        PRIMARY KEY (id_estado),
    CONSTRAINT uq_codigo_estado UNIQUE      (codigo_estado)
);
GO

-- ============================================================
--  TABLA 2: ORIGENES
-- ============================================================
CREATE TABLE Origenes (
    id_origen           INT             NOT NULL IDENTITY(1,1),
    pais_region         VARCHAR(200)    NOT NULL,
    continente          VARCHAR(50)     NOT NULL,
    descripcion_region  VARCHAR(MAX),
    es_mesoamerica      BIT             NOT NULL DEFAULT 0,

    CONSTRAINT pk_origen PRIMARY KEY (id_origen)
);
GO

-- ============================================================
--  TABLA 3: FAMILIAS
-- ============================================================
CREATE TABLE Familias (
    id_familia          INT             NOT NULL IDENTITY(1,1),
    nombre_familia      VARCHAR(100)    NOT NULL,
    orden_botanico      VARCHAR(100),
    clase_botanica      VARCHAR(100),
    division_botanica   VARCHAR(100),
    descripcion         VARCHAR(MAX),
    fecha_registro      DATETIME        NOT NULL DEFAULT GETDATE(),

    CONSTRAINT pk_familia       PRIMARY KEY (id_familia),
    CONSTRAINT uq_nombre_familia UNIQUE     (nombre_familia)
);
GO

-- ============================================================
--  TABLA 4: ZONAS_PARQUE
-- ============================================================
CREATE TABLE Zonas_Parque (
    id_zona             INT             NOT NULL IDENTITY(1,1),
    nombre_zona         VARCHAR(150)    NOT NULL,
    descripcion         VARCHAR(MAX),
    area_m2             DECIMAL(10,2),
    tipo_ecosistema     VARCHAR(100),
    latitud_centro      DECIMAL(10,6),
    longitud_centro     DECIMAL(10,6),
    accesible_publico   BIT             NOT NULL DEFAULT 1,
    total_especies      INT             DEFAULT 0,
    encargado_zona      VARCHAR(100),

    CONSTRAINT pk_zona       PRIMARY KEY (id_zona),
    CONSTRAINT uq_nombre_zona UNIQUE     (nombre_zona)
);
GO

-- ============================================================
--  TABLA 5: GENEROS
-- ============================================================
CREATE TABLE Generos (
    id_genero           INT             NOT NULL IDENTITY(1,1),
    id_familia          INT             NOT NULL,
    nombre_genero       VARCHAR(100)    NOT NULL,
    descripcion         VARCHAR(MAX),
    num_especies_aprox  INT             DEFAULT 0,

    CONSTRAINT pk_genero PRIMARY KEY (id_genero),
    CONSTRAINT fk_genero_familia
        FOREIGN KEY (id_familia) REFERENCES Familias (id_familia)
        ON UPDATE CASCADE
        ON DELETE NO ACTION
);
GO

-- ============================================================
--  TABLA 6: PLANTAS  ⭐ TABLA CENTRAL
-- ============================================================
CREATE TABLE Plantas (
    id_planta                   INT             NOT NULL IDENTITY(1,1),
    id_genero                   INT             NOT NULL,
    id_familia                  INT             NOT NULL,
    id_zona                     INT             NOT NULL,
    id_origen                   INT             NOT NULL,
    id_estado_conservacion      INT             NOT NULL,
    
    nombre_comun                VARCHAR(150)    NOT NULL,
    nombre_especie              VARCHAR(150)    NOT NULL,
    nombre_cientifico_completo  VARCHAR(250)    NOT NULL,
    descripcion                 VARCHAR(MAX),
    habito                      VARCHAR(20)     NOT NULL DEFAULT 'Terrestre'
        CONSTRAINT chk_habito
            CHECK (habito IN ('Terrestre','Epífita','Acuática','Parásita','Trepadora')),
    es_endemica                 BIT             NOT NULL DEFAULT 0,
    es_nativa                   BIT             NOT NULL DEFAULT 0,
    es_flor_nacional            BIT             NOT NULL DEFAULT 0,
    altura_max_metros           DECIMAL(5,2),
    epoca_floracion             VARCHAR(100),
    foto_url                    VARCHAR(300),
    codigo_qr                   VARCHAR(100),
    fecha_ingreso               DATE            NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    activo                      BIT             NOT NULL DEFAULT 1,

    CONSTRAINT pk_planta PRIMARY KEY (id_planta),
    CONSTRAINT fk_planta_genero FOREIGN KEY (id_genero) REFERENCES Generos (id_genero) ON UPDATE CASCADE ON DELETE NO ACTION,
    CONSTRAINT fk_planta_familia FOREIGN KEY (id_familia) REFERENCES Familias (id_familia) ON UPDATE CASCADE ON DELETE NO ACTION,
    CONSTRAINT fk_planta_zona FOREIGN KEY (id_zona) REFERENCES Zonas_Parque (id_zona) ON UPDATE CASCADE ON DELETE NO ACTION,
    CONSTRAINT fk_planta_origen FOREIGN KEY (id_origen) REFERENCES Origenes (id_origen) ON UPDATE CASCADE ON DELETE NO ACTION,
    CONSTRAINT fk_planta_estado FOREIGN KEY (id_estado_conservacion) REFERENCES Estado_Conservacion (id_estado) ON UPDATE CASCADE ON DELETE NO ACTION
);
GO

-- ── 1. Estados de Conservación ──────────────────────────────
INSERT INTO Estado_Conservacion (codigo_estado, nombre_estado, descripcion, nivel_riesgo, organismo)
VALUES
    ('LC', 'Preocupación Menor', 'La especie existe en abundancia y no enfrenta amenazas significativas.', 'Bajo', 'UICN'),
    ('NE', 'No Evaluado', 'Especie cultivada de valor ornamental sin evaluación de riesgo en estado silvestre.', 'Bajo', 'UICN');
GO

-- ── 2. Orígenes ──────────────────────────────────────────────
INSERT INTO Origenes (pais_region, continente, descripcion_region, es_mesoamerica)
VALUES
    ('México y Sudamérica', 'América', 'Nativa de México y gran parte de Sudamérica. Cultivada en El Salvador.', 1),
    ('Indonesia, Malasia y Filipinas', 'Asia', 'Asia tropical insular.', 0),
    ('Colombia y Ecuador', 'América', 'Bosques tropicales húmedos de Sudamérica.', 0),
    ('Asia Tropical', 'Asia', 'Regiones cálidas y húmedas del sudeste asiático.', 0),
    ('El Salvador y Mesoamérica', 'América', 'Bosque tropical seco y húmedo de Centroamérica.', 1);
GO

-- ── 3. Familias Botánicas ────────────────────────────────────
INSERT INTO Familias (nombre_familia, orden_botanico, clase_botanica, division_botanica, descripcion)
VALUES
    ('Asteraceae', 'Asterales', 'Magnoliopsida', 'Magnoliophyta', 'Familia de las margaritas, girasoles y crisantemos. Flores compuestas.'),
    ('Zingiberaceae', 'Zingiberales', 'Liliopsida', 'Magnoliophyta', 'Familia del jengibre. Plantas aromáticas con rizomas subterráneos.'),
    ('Araceae', 'Alismatales', 'Liliopsida', 'Magnoliophyta', 'Familia del anturio y las calas, caracterizadas por su espata e inflorescencia espádice.'),
    ('Asparagaceae', 'Asparagales', 'Liliopsida', 'Magnoliophyta', 'Familia de agaves, yucas y plantas monocotiledóneas.');
GO

-- ── 4. Zonas del Parque (Jardín Botánico La Laguna) ─────────
INSERT INTO Zonas_Parque (nombre_zona, descripcion, area_m2, tipo_ecosistema, latitud_centro, longitud_centro, accesible_publico, total_especies, encargado_zona)
VALUES
    ('Zona de Vegetación Ornamental y Estanque', 'Borde junto al estanque de agua, sector con alta iluminación solar y flores coloridas.', 2500.00, 'Jardín acuático y ornamental', 13.6738, -89.2482, 1, 80, 'Biol. Ana García'),
    ('Sector de Vegetación Densa y Sombra', 'Bosque sombreado con suelo rico en hojarasca y alta humedad relativa.', 3200.00, 'Sotobosque denso', 13.6740, -89.2493, 1, 110, 'Ing. Carlos Mendoza'),
    ('Zona de Hierbas y Medicinales', 'Colección temática de hierbas perennes, ornamentales y de uso tradicional.', 2800.00, 'Jardín temático de hierbas', 13.6744, -89.2489, 1, 150, 'Biol. Rosa Martínez');
GO

-- ── 5. Géneros ───────────────────────────────────────────────
INSERT INTO Generos (id_familia, nombre_genero, descripcion, num_especies_aprox)
VALUES
    (1, 'Zinnia', 'Plantas anuales y perennes con flores de vivos colores.', 20),
    (2, 'Nicolaia', 'Plantas rizomatosas de gran tamaño con inflorescencias cónicas vistosas.', 15),
    (3, 'Anthurium', 'Género neotropical con hojas brillantes y espatas coloridas.', 1000),
    (2, 'Kaempferia', 'Hierbas rizomatosas pequeñas de flores delicadas cerca del suelo.', 50),
    (4, 'Yucca', 'Plantas leñosas de hojas en roseta rígidas.', 49);
GO

-- ── 6. LAS 5 PLANTAS INVESTIGADAS EN EL JARDÍN BOTÁNICO 🌟 ──────
INSERT INTO Plantas (
    id_genero, id_familia, id_zona, id_origen, id_estado_conservacion,
    nombre_comun, nombre_especie, nombre_cientifico_completo,
    descripcion, habito, es_endemica, es_nativa, es_flor_nacional,
    altura_max_metros, epoca_floracion, foto_url, codigo_qr
)
VALUES
-- Planta 1: Cambray / Zinnia elegante
(1, 1, 1, 1, 1,
 'Cambray (Zinia)', 'elegans', 'Zinnia elegans L.',
 'Planta anual de crecimiento rápido que florece abundantemente en colores variados durante la mayor parte del año. Resiste bien el sol directo y los climas cálidos de El Salvador; es altamente visitada por mariposas y polinizadores. Ubicada en la zona de vegetación ornamental junto al estanque.',
 'Terrestre', 0, 0, 0,
 0.80, 'Todo el año',
 'https://images.unsplash.com/photo-1597848212624-a19eb35e2651?auto=format&fit=crop&w=800&q=80', 'JBL-PLANT-001'),

-- Planta 2: Bastón del emperador
(2, 2, 2, 2, 2,
 'Bastón del Emperador', 'elatior', 'Nicolaia elatior (Jack) Horan',
 'Planta de tallos altos y erectos con flor característica en forma de cono de color rosado intenso. Muy vistosa como flor ornamental y de corte. Pertenece a la familia del jengibre y cuenta con sustancias aromáticas en sus raíces. Ubicada en el sector de vegetación densa y sombreada con suelo de hojarasca.',
 'Terrestre', 0, 0, 0,
 4.50, 'Época lluviosa',
 'https://images.unsplash.com/photo-1596724803730-8022b7a95610?auto=format&fit=crop&w=800&q=80', 'JBL-PLANT-002'),

-- Planta 3: Corazón chino
(3, 3, 3, 3, 2,
 'Corazón Chino (Anturio)', 'andraeanum', 'Anthurium andraeanum Linden',
 'Planta ornamental de sotobosque con hojas brillantes en forma de corazón y una llamativa espata cerosa de color rojo brillante o rosado con espádice amarillo. Ubicada en la Zona de Hierbas según el rótulo del jardín.',
 'Terrestre', 0, 0, 0,
 0.60, 'Todo el año (humedad constante)',
 'https://images.unsplash.com/photo-1605807646983-377bc5a76493?auto=format&fit=crop&w=800&q=80', 'JBL-PLANT-003'),

-- Planta 4: Bruja
(4, 2, 3, 4, 2,
 'Bruja (Resurrección)', 'rotunda', 'Kaempferia rotunda L.',
 'Hierba perenne y rizomatosa de hojas alargadas verdes y flores delicadas en tonos blancos y morados que brotan cerca del suelo. Usada como ornamental y medicina tradicional en Asia. Prefiere sombra parcial y suelo húmedo. Ubicada en la Zona de Hierbas.',
 'Terrestre', 0, 0, 0,
 0.40, 'Inicio de época lluviosa',
 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=800&q=80', 'JBL-PLANT-004'),

-- Planta 5: Flor de Izote (Flor Nacional de El Salvador 🇸🇻)
(5, 4, 3, 5, 1,
 'Flor de Izote', 'guatemalensis', 'Yucca guatemalensis Baker',
 'Arbusto o árbol pequeño de tronco robusto con hojas largas rígidas en forma de espada y flores campanuladas comestibles. Emblemática de la cultura salvadoreña y declarada Flor Nacional de El Salvador. Ubicada en la Zona de Hierbas y Medicinales.',
 'Terrestre', 0, 1, 1,
 8.00, 'Diciembre - Febrero',
 'https://images.unsplash.com/photo-1533038590840-1cde6e668a91?auto=format&fit=crop&w=800&q=80', 'JBL-PLANT-005');
GO

-- ============================================================
--  VISTAS (VIEWS)
-- ============================================================
CREATE VIEW vista_inventario_completo AS
SELECT
    p.id_planta,
    p.codigo_qr,
    p.nombre_comun,
    g.nombre_genero + ' ' + p.nombre_especie   AS nombre_cientifico,
    p.nombre_cientifico_completo,
    f.nombre_familia,
    f.orden_botanico,
    z.nombre_zona,
    z.latitud_centro,
    z.longitud_centro,
    o.pais_region                               AS region_origen,
    e.codigo_estado,
    e.nombre_estado                             AS conservacion,
    e.nivel_riesgo,
    p.habito,
    p.es_endemica,
    p.es_nativa,
    p.es_flor_nacional,
    p.altura_max_metros,
    p.epoca_floracion,
    p.foto_url,
    p.descripcion,
    p.activo
FROM       Plantas             p
INNER JOIN Generos             g ON p.id_genero             = g.id_genero
INNER JOIN Familias            f ON p.id_familia            = f.id_familia
INNER JOIN Zonas_Parque        z ON p.id_zona               = z.id_zona
INNER JOIN Origenes            o ON p.id_origen             = o.id_origen
INNER JOIN Estado_Conservacion e ON p.id_estado_conservacion= e.id_estado;
GO
