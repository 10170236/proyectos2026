/**
 * JARDÍN BOTÁNICO LA LAGUNA · APLICACIÓN INTERACTIVA
 * Antiguo Cuscatlán, El Salvador
 * 
 * Lógica Frontend SPA, Gamificación de Descubrimientos (5 plantas de campo), Recompensas Cafetería & Google Maps
 */

class JardinBotanicoApp {
    constructor() {
        this.currentScreen = 'screenHome';
        this.previousScreen = 'screenHome';
        this.plantasData = [];
        this.zonasData = [];
        this.favorites = JSON.parse(localStorage.getItem('jbl_favorites') || '[]');
        this.discovered = JSON.parse(localStorage.getItem('jbl_discovered') || '[]');
        this.currentPlantDetail = null;
        this.activeSubTab = 'discovered';
        this.map = null;
        this.markers = [];
        this.userLocationMarker = null;
        this.targetGoal = 5; // Meta de 5 especies descubiertas para premio en cafetería

        this.init();
    }

    async init() {
        this.bindEvents();
        await this.loadData();
        this.initGoogleMap();
        this.renderSearchResults(this.plantasData);
        this.updateUserProgressUI();
    }

    bindEvents() {
        const searchInput = document.getElementById('searchInput');
        const btnClear = document.getElementById('btnClearSearch');

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const term = e.target.value.trim();
                if (term.length > 0) {
                    btnClear?.classList.remove('hidden');
                    this.performSearch(term);
                } else {
                    btnClear?.classList.add('hidden');
                    this.resetSearch();
                }
            });
        }

        if (btnClear) {
            btnClear.addEventListener('click', () => {
                if (searchInput) searchInput.value = '';
                btnClear.classList.add('hidden');
                this.resetSearch();
            });
        }

        const btnToggleDevice = document.getElementById('btnToggleDevice');
        const appContainer = document.getElementById('appContainer');
        const toggleText = document.getElementById('toggleText');

        if (btnToggleDevice) {
            btnToggleDevice.addEventListener('click', () => {
                if (appContainer.classList.contains('device-mobile')) {
                    appContainer.classList.remove('device-mobile');
                    appContainer.classList.add('device-full');
                    if (toggleText) toggleText.textContent = 'Modo Marco Celular';
                } else {
                    appContainer.classList.remove('device-full');
                    appContainer.classList.add('device-mobile');
                    if (toggleText) toggleText.textContent = 'Modo Celular';
                }
                if (this.map) {
                    setTimeout(() => this.map.invalidateSize(), 300);
                }
            });
        }
    }

    async loadData() {
        try {
            const [resPlantas, resZonas] = await Promise.all([
                fetch('/api/plantas').then(r => r.json()).catch(() => null),
                fetch('/api/zonas').then(r => r.json()).catch(() => null)
            ]);

            if (resPlantas && resPlantas.data && resPlantas.data.length > 0) {
                this.plantasData = resPlantas.data;
            } else {
                this.plantasData = this.getStaticPlantasFallback();
            }

            if (resZonas && resZonas.data && resZonas.data.length > 0) {
                this.zonasData = resZonas.data;
            } else {
                this.zonasData = this.getStaticZonasFallback();
            }
        } catch (e) {
            this.plantasData = this.getStaticPlantasFallback();
            this.zonasData = this.getStaticZonasFallback();
        }
    }

    navigateTo(screenId) {
        if (this.currentScreen === screenId) return;

        this.previousScreen = this.currentScreen;
        this.currentScreen = screenId;

        document.querySelectorAll('.app-screen').forEach(screen => {
            screen.classList.remove('active-screen');
        });
        const targetScreen = document.getElementById(screenId);
        if (targetScreen) targetScreen.classList.add('active-screen');

        document.querySelectorAll('.nav-tab').forEach(tab => tab.classList.remove('active'));
        if (screenId === 'screenHome') document.getElementById('tabHome')?.classList.add('active');
        if (screenId === 'screenRewards') {
            document.getElementById('tabRewards')?.classList.add('active');
            this.renderRewardsScreen();
        }
        if (screenId === 'screenFavorites') {
            document.getElementById('tabFavorites')?.classList.add('active');
            this.renderFavorites();
        }
        if (screenId === 'screenMap') {
            document.getElementById('tabMap')?.classList.add('active');
            if (this.map) setTimeout(() => this.map.invalidateSize(), 200);
        }
    }

    goBack() {
        this.navigateTo(this.previousScreen || 'screenHome');
    }

    // Progreso del Usuario y Recompensas
    updateUserProgressUI() {
        const count = this.discovered.length;
        const percentage = Math.min(Math.round((count / this.targetGoal) * 100), 100);

        const barFill = document.getElementById('progressBarFill');
        const textCount = document.getElementById('progressTextCount');
        const badgeStatus = document.getElementById('rewardBadgeStatus');

        if (barFill) barFill.style.width = `${percentage}%`;
        if (textCount) textCount.textContent = `${count} de ${this.targetGoal} Descubiertas (${percentage}%)`;

        if (badgeStatus) {
            if (count >= this.targetGoal) {
                badgeStatus.innerHTML = '<i class="fa-solid fa-gift"></i> ¡Premio Desbloqueado!';
                badgeStatus.style.backgroundColor = '#c8e6c9';
                badgeStatus.style.color = '#2e7d32';
            } else {
                badgeStatus.innerHTML = '<i class="fa-solid fa-cookie-bite"></i> Ver Premio';
            }
        }
    }

    toggleDiscoveredCurrent() {
        if (!this.currentPlantDetail) return;
        const id = this.currentPlantDetail.id_planta;
        const index = this.discovered.indexOf(id);

        if (index > -1) {
            this.discovered.splice(index, 1);
        } else {
            this.discovered.push(id);
        }

        localStorage.setItem('jbl_discovered', JSON.stringify(this.discovered));
        this.updateUserProgressUI();
        this.updateDiscoveredButtonUI(id);
    }

    updateDiscoveredButtonUI(id) {
        const btnMark = document.getElementById('btnMarkDiscovered');
        const badgeWatermark = document.getElementById('detailDiscoveredBadge');
        const isDiscovered = this.discovered.includes(id);

        if (btnMark) {
            if (isDiscovered) {
                btnMark.classList.add('is-discovered');
                btnMark.innerHTML = '<i class="fa-solid fa-circle-check"></i> Especie Registrada en tu Diario';
            } else {
                btnMark.classList.remove('is-discovered');
                btnMark.innerHTML = '<i class="fa-solid fa-compass"></i> Registrar en mi Diario de Exploración';
            }
        }

        if (badgeWatermark) {
            if (isDiscovered) badgeWatermark.classList.remove('hidden');
            else badgeWatermark.classList.add('hidden');
        }
    }

    renderRewardsScreen() {
        const count = this.discovered.length;
        const codeBox = document.getElementById('voucherCodeBox');
        const progressSummary = document.getElementById('rewardProgressSummary');

        if (progressSummary) {
            progressSummary.textContent = `Progreso actual: ${count}/${this.targetGoal} Especies encontradas`;
        }

        if (codeBox) {
            if (count >= this.targetGoal) {
                let storedCode = localStorage.getItem('jbl_reward_code');
                if (!storedCode) {
                    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
                    storedCode = `SNACK-JBL-${randomSuffix}`;
                    localStorage.setItem('jbl_reward_code', storedCode);
                }
                codeBox.innerHTML = `
                    <div style="color:#2e7d32; font-size:0.8rem; margin-bottom:4px;"><i class="fa-solid fa-circle-check"></i> ¡Premio Listo para Reclamar!</div>
                    <span class="voucher-code">${storedCode}</span>
                    <p style="font-size:0.72rem; color:#d4a373; margin-top:4px;">Presenta este código en la Cafetería del parque para recibir tu snack gratis.</p>
                `;
            } else {
                const missing = this.targetGoal - count;
                codeBox.innerHTML = `
                    <span class="voucher-locked">
                        <i class="fa-solid fa-lock"></i> Bloqueado (Te faltan ${missing} especie${missing > 1 ? 's' : ''} por descubrir)
                    </span>
                `;
            }
        }
    }

    openScannerModal() {
        const modal = document.getElementById('qrModal');
        const list = document.getElementById('quickScanList');

        if (list) {
            list.innerHTML = this.plantasData.map(p => {
                const isDiscovered = this.discovered.includes(p.id_planta);
                return `
                    <div class="plant-card-item" onclick="app.registerPlantFromScan(${p.id_planta})">
                        <img src="${p.foto_url}" class="plant-thumb">
                        <div class="plant-item-info">
                            <h4>${p.nombre_comun}</h4>
                            <p>${p.nombre_cientifico_completo || p.nombre_cientifico}</p>
                        </div>
                        <div style="margin-left:auto;">
                            ${isDiscovered ? '<span style="color:#2e7d32; font-size:1.2rem;"><i class="fa-solid fa-circle-check"></i></span>' : '<span style="color:#1565c0; font-size:0.8rem; font-weight:700;">+ Agregar</span>'}
                        </div>
                    </div>
                `;
            }).join('');
        }

        modal?.classList.remove('hidden');
    }

    closeScannerModal() {
        document.getElementById('qrModal')?.classList.add('hidden');
    }

    registerPlantFromScan(idPlanta) {
        if (!this.discovered.includes(idPlanta)) {
            this.discovered.push(idPlanta);
            localStorage.setItem('jbl_discovered', JSON.stringify(this.discovered));
            this.updateUserProgressUI();
        }
        this.closeScannerModal();
        this.showPlantDetail(idPlanta);
    }

    performSearch(query) {
        const resultsSection = document.getElementById('searchResultsSection');
        const titleResults = document.getElementById('searchTitleResults');
        resultsSection?.classList.remove('hidden');

        const term = query.toLowerCase();
        const filtered = this.plantasData.filter(p =>
            p.nombre_comun.toLowerCase().includes(term) ||
            p.nombre_cientifico_completo.toLowerCase().includes(term) ||
            p.nombre_familia.toLowerCase().includes(term) ||
            p.nombre_zona.toLowerCase().includes(term)
        );

        if (titleResults) titleResults.textContent = `Resultados para "${query}" (${filtered.length})`;
        this.renderSearchResults(filtered);
    }

    filterByCategory(categoryKey) {
        const resultsSection = document.getElementById('searchResultsSection');
        const titleResults = document.getElementById('searchTitleResults');
        resultsSection?.classList.remove('hidden');

        let filtered = [];
        let catName = 'Especies';

        if (categoryKey === 'orquideas') {
            catName = 'Orquídeas y Anturios';
            filtered = this.plantasData.filter(p => p.nombre_familia === 'Araceae' || p.nombre_familia === 'Orchidaceae');
        } else if (categoryKey === 'helechos') {
            catName = 'Bastón del Emperador y Zingiberáceas';
            filtered = this.plantasData.filter(p => p.nombre_familia === 'Zingiberaceae');
        } else if (categoryKey === 'arboles') {
            catName = 'Árboles y Flor Nacional';
            filtered = this.plantasData.filter(p => p.altura_max_metros >= 1.0);
        } else if (categoryKey === 'cactus') {
            catName = 'Bruja y Suculentas';
            filtered = this.plantasData.filter(p => p.nombre_comun.includes('Bruja') || p.nombre_familia === 'Asteraceae');
        }

        if (titleResults) titleResults.textContent = `Categoría: ${catName} (${filtered.length})`;
        this.renderSearchResults(filtered);
        resultsSection?.scrollIntoView({ behavior: 'smooth' });
    }

    resetSearch() {
        const resultsSection = document.getElementById('searchResultsSection');
        const searchInput = document.getElementById('searchInput');
        if (searchInput) searchInput.value = '';
        resultsSection?.classList.add('hidden');
    }

    renderSearchResults(plantArray) {
        const container = document.getElementById('plantListGrid');
        if (!container) return;

        if (plantArray.length === 0) {
            container.innerHTML = `
                <div style="text-align:center; padding: 20px; color: #5c6b61;">
                    <i class="fa-solid fa-leaf" style="font-size:2rem; color:#4a7c59; margin-bottom:8px;"></i>
                    <p>No se encontraron especies con ese criterio.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = plantArray.map(p => `
            <div class="plant-card-item" onclick="app.showPlantDetail(${p.id_planta})">
                <img src="${p.foto_url}" alt="${p.nombre_comun}" class="plant-thumb">
                <div class="plant-item-info">
                    <h4>${p.nombre_comun}</h4>
                    <p>${p.nombre_cientifico_completo || p.nombre_cientifico}</p>
                    <span class="plant-item-tag"><i class="fa-solid fa-location-dot"></i> ${p.nombre_zona}</span>
                </div>
            </div>
        `).join('');
    }

    showPlantDetail(plantId) {
        const plant = this.plantasData.find(p => p.id_planta === plantId) || this.plantasData[0];
        this.currentPlantDetail = plant;

        document.getElementById('detailImage').src = plant.foto_url;
        document.getElementById('detailCommonName').textContent = plant.nombre_comun;
        document.getElementById('detailScientificName').textContent = plant.nombre_cientifico_completo || plant.nombre_cientifico;
        document.getElementById('detailFamily').textContent = plant.nombre_familia || 'No especificada';
        document.getElementById('detailOrigin').textContent = plant.region_origen || 'El Salvador';
        document.getElementById('detailZone').textContent = plant.nombre_zona || 'Jardín Principal';
        document.getElementById('detailConservation').textContent = `${plant.conservacion || 'Preocupación Menor'} (${plant.codigo_estado || 'LC'})`;
        document.getElementById('detailDescription').textContent = plant.descripcion;
        document.getElementById('detailBadgeHabito').textContent = plant.habito || 'Terrestre';

        const btnFav = document.getElementById('btnFavorite');
        if (btnFav) {
            if (this.favorites.includes(plant.id_planta)) {
                btnFav.classList.add('is-favorite');
                btnFav.innerHTML = '<i class="fa-solid fa-heart"></i>';
            } else {
                btnFav.classList.remove('is-favorite');
                btnFav.innerHTML = '<i class="fa-regular fa-heart"></i>';
            }
        }

        this.updateDiscoveredButtonUI(plant.id_planta);
        this.navigateTo('screenDetail');
    }

    toggleFavoriteCurrent() {
        if (!this.currentPlantDetail) return;
        const id = this.currentPlantDetail.id_planta;
        const index = this.favorites.indexOf(id);

        if (index > -1) {
            this.favorites.splice(index, 1);
        } else {
            this.favorites.push(id);
        }

        localStorage.setItem('jbl_favorites', JSON.stringify(this.favorites));

        const btnFav = document.getElementById('btnFavorite');
        if (btnFav) {
            if (this.favorites.includes(id)) {
                btnFav.classList.add('is-favorite');
                btnFav.innerHTML = '<i class="fa-solid fa-heart"></i>';
            } else {
                btnFav.classList.remove('is-favorite');
                btnFav.innerHTML = '<i class="fa-regular fa-heart"></i>';
            }
        }
    }

    switchSubTab(tabType) {
        this.activeSubTab = tabType;
        document.getElementById('btnSubDiscovered')?.classList.toggle('active', tabType === 'discovered');
        document.getElementById('btnSubFavs')?.classList.toggle('active', tabType === 'favs');
        this.renderFavorites();
    }

    renderFavorites() {
        const container = document.getElementById('favoritesListGrid');
        const countDiscovered = document.getElementById('countDiscoveredNum');
        const countFavs = document.getElementById('countFavsNum');

        if (countDiscovered) countDiscovered.textContent = this.discovered.length;
        if (countFavs) countFavs.textContent = this.favorites.length;

        if (!container) return;

        const isDiscoveredTab = this.activeSubTab === 'discovered';
        const targetIds = isDiscoveredTab ? this.discovered : this.favorites;
        const list = this.plantasData.filter(p => targetIds.includes(p.id_planta));

        if (list.length === 0) {
            container.innerHTML = `
                <div style="text-align:center; padding: 40px 20px; color: #5c6b61;">
                    <i class="${isDiscoveredTab ? 'fa-solid fa-compass' : 'fa-regular fa-heart'}" style="font-size:2.5rem; color:#4a7c59; margin-bottom:12px;"></i>
                    <h3>${isDiscoveredTab ? 'Aún no has registrado descubrimientos' : 'Sin plantas favoritas'}</h3>
                    <p style="font-size:0.85rem; margin-top:6px;">${isDiscoveredTab ? 'Usa el botón de escanear o registrar en la ficha de cada especie.' : 'Toca el corazón en cualquier planta para guardarla.'}</p>
                </div>
            `;
            return;
        }

        container.innerHTML = list.map(p => `
            <div class="plant-card-item" onclick="app.showPlantDetail(${p.id_planta})">
                <img src="${p.foto_url}" alt="${p.nombre_comun}" class="plant-thumb">
                <div class="plant-item-info">
                    <h4>${p.nombre_comun}</h4>
                    <p>${p.nombre_cientifico_completo || p.nombre_cientifico}</p>
                    <span class="plant-item-tag">📍 ${p.nombre_zona}</span>
                </div>
            </div>
        `).join('');
    }

    // MAPA
    initGoogleMap() {
        const centerLat = 13.6742;
        const centerLng = -89.2487;

        const mapElement = document.getElementById('googleMap');
        if (!mapElement) return;

        this.map = L.map('googleMap', {
            center: [centerLat, centerLng],
            zoom: 17,
            zoomControl: false
        });

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© Jardín Botánico La Laguna | Google Maps',
            maxZoom: 19
        }).addTo(this.map);

        const createZoneIcon = (emoji) => L.divIcon({
            html: `<div style="background:#1b382b; color:#fff; width:34px; height:34px; border-radius:50%; border:2px solid #fff; display:flex; align-items:center; justify-content:center; font-size:16px; box-shadow:0 3px 10px rgba(0,0,0,0.3);">${emoji}</div>`,
            className: 'custom-map-icon',
            iconSize: [34, 34],
            iconAnchor: [17, 17]
        });

        this.zonasData.forEach(zona => {
            let emoji = '🌱';
            if (zona.id_zona === 1) emoji = '🌻';
            if (zona.id_zona === 2) emoji = '🌿';
            if (zona.id_zona === 3) emoji = '🪴';

            const marker = L.marker([zona.latitud_centro, zona.longitud_centro], {
                icon: createZoneIcon(emoji)
            }).addTo(this.map);

            marker.bindPopup(`
                <div style="font-family:sans-serif; text-align:center; padding:4px;">
                    <strong style="color:#1b382b; font-size:14px;">${zona.nombre_zona}</strong>
                    <p style="font-size:11px; color:#666; margin:4px 0 8px 0;">${zona.tipo_ecosistema || 'Zona temática'}</p>
                    <button onclick="app.openZoneDrawer(${zona.id_zona})" style="background:#1b382b; color:#fff; border:none; padding:5px 12px; border-radius:12px; font-size:11px; cursor:pointer;">Ver Especies (${zona.total_especies || 0})</button>
                </div>
            `);

            this.markers.push(marker);
        });

        const userIcon = L.divIcon({
            html: `<div style="background:#0288d1; color:#fff; width:38px; height:38px; border-radius:50%; border:3px solid #fff; display:flex; align-items:center; justify-content:center; font-size:18px; box-shadow:0 0 15px rgba(2,136,209,0.7);"><i class="fa-solid fa-person-walking"></i></div>`,
            className: 'user-map-icon',
            iconSize: [38, 38],
            iconAnchor: [19, 19]
        });

        this.userLocationMarker = L.marker([13.6741, -89.2489], { icon: userIcon })
            .addTo(this.map)
            .bindPopup("<b>📍 Tu Ubicación Actual</b><br>Entrada Jardín Botánico La Laguna");
    }

    mapZoomIn() { if (this.map) this.map.zoomIn(); }
    mapZoomOut() { if (this.map) this.map.zoomOut(); }

    locateUserOnMap() {
        if (this.map && this.userLocationMarker) {
            this.map.setView(this.userLocationMarker.getLatLng(), 18);
            this.userLocationMarker.openPopup();
        }
    }

    focusZone(zonaId) {
        const zona = this.zonasData.find(z => z.id_zona === zonaId);
        if (zona && this.map) {
            this.map.setView([zona.latitud_centro, zona.longitud_centro], 18);
            this.openZoneDrawer(zonaId);
        }
    }

    openZoneDrawer(zonaId) {
        const zona = this.zonasData.find(z => z.id_zona === zonaId);
        if (!zona) return;

        const drawer = document.getElementById('zoneDrawer');
        const title = document.getElementById('drawerZoneTitle');
        const desc = document.getElementById('drawerZoneDesc');
        const list = document.getElementById('drawerPlantList');

        if (title) title.textContent = zona.nombre_zona;
        if (desc) desc.textContent = zona.descripcion;

        const plantsInZone = this.plantasData.filter(p => p.id_zona === zonaId);

        if (list) {
            if (plantsInZone.length === 0) {
                list.innerHTML = `<p style="font-size:0.8rem; color:#777;">No hay plantas registradas en esta zona aún.</p>`;
            } else {
                list.innerHTML = plantsInZone.map(p => `
                    <div class="plant-card-item" onclick="app.showPlantDetail(${p.id_planta})">
                        <img src="${p.foto_url}" class="plant-thumb" style="width:45px; height:45px;">
                        <div class="plant-item-info">
                            <h4 style="font-size:0.85rem;">${p.nombre_comun}</h4>
                            <p style="font-size:0.75rem;">${p.nombre_cientifico_completo || p.nombre_cientifico}</p>
                        </div>
                    </div>
                `).join('');
            }
        }

        drawer?.classList.remove('hidden');
    }

    closeZoneDrawer() {
        document.getElementById('zoneDrawer')?.classList.add('hidden');
    }

    getStaticZonasFallback() {
        return [
            { id_zona: 1, nombre_zona: "Zona de Vegetación Ornamental y Estanque", descripcion: "Borde junto al estanque de agua, sector con buena iluminación solar.", latitud_centro: 13.6738, longitud_centro: -89.2482, total_especies: 80 },
            { id_zona: 2, nombre_zona: "Sector de Vegetación Densa y Sombra", descripcion: "Bosque sombreado con suelo rico en hojarasca.", latitud_centro: 13.6740, longitud_centro: -89.2493, total_especies: 110 },
            { id_zona: 3, nombre_zona: "Zona de Hierbas y Medicinales", descripcion: "Colección temática de hierbas perennes, ornamentales y medicinales.", latitud_centro: 13.6744, longitud_centro: -89.2489, total_especies: 150 }
        ];
    }

    getStaticPlantasFallback() {
        return [
            {
                id_planta: 1,
                nombre_comun: "Cambray (Zinia)",
                nombre_cientifico: "Zinnia elegans",
                nombre_cientifico_completo: "Zinnia elegans L.",
                nombre_familia: "Asteraceae",
                nombre_zona: "Zona de Vegetación Ornamental y Estanque",
                id_zona: 1,
                region_origen: "México y Sudamérica (Cultivada en El Salvador)",
                codigo_estado: "LC",
                conservacion: "Preocupación Menor",
                habito: "Terrestre",
                foto_url: "https://images.unsplash.com/photo-1597848212624-a19eb35e2651?auto=format&fit=crop&w=800&q=80",
                descripcion: "Planta anual de crecimiento rápido que florece abundantemente en colores variados durante la mayor parte del año. Resiste bien el sol directo y los climas cálidos de El Salvador; es muy visitada por mariposas y polinizadores. Ubicada en la zona de vegetación ornamental junto al estanque."
            },
            {
                id_planta: 2,
                nombre_comun: "Bastón del Emperador",
                nombre_cientifico: "Nicolaia elatior",
                nombre_cientifico_completo: "Nicolaia elatior (Jack) Horan",
                nombre_familia: "Zingiberaceae",
                nombre_zona: "Sector de Vegetación Densa y Sombra",
                id_zona: 2,
                region_origen: "Indonesia, Malasia y Filipinas",
                codigo_estado: "NE",
                conservacion: "No Evaluado",
                habito: "Terrestre",
                foto_url: "https://images.unsplash.com/photo-1596724803730-8022b7a95610?auto=format&fit=crop&w=800&q=80",
                descripcion: "Planta de tallos altos y erectos con flor característica en forma de cono de color rosado intenso. Muy vistosa como flor ornamental y de corte. Pertenece a la familia del jengibre y cuenta con sustancias aromáticas en sus raíces. Ubicada en el sector de vegetación densa y sombreada."
            },
            {
                id_planta: 3,
                nombre_comun: "Corazón Chino (Anturio)",
                nombre_cientifico: "Anthurium andraeanum",
                nombre_cientifico_completo: "Anthurium andraeanum Linden",
                nombre_familia: "Araceae",
                nombre_zona: "Zona de Hierbas y Medicinales",
                id_zona: 3,
                region_origen: "Colombia y Ecuador",
                codigo_estado: "NE",
                conservacion: "No Evaluado",
                habito: "Terrestre",
                foto_url: "https://images.unsplash.com/photo-1605807646983-377bc5a76493?auto=format&fit=crop&w=800&q=80",
                descripcion: "Planta ornamental de sotobosque con hojas brillantes en forma de corazón y una llamativa espata cerosa de color rojo brillante con espádice. Ubicada en la Zona de Hierbas del jardín."
            },
            {
                id_planta: 4,
                nombre_comun: "Bruja (Resurrección)",
                nombre_cientifico: "Kaempferia rotunda",
                nombre_cientifico_completo: "Kaempferia rotunda L.",
                nombre_familia: "Zingiberaceae",
                nombre_zona: "Zona de Hierbas y Medicinales",
                id_zona: 3,
                region_origen: "Asia Tropical",
                codigo_estado: "NE",
                conservacion: "No Evaluado",
                habito: "Terrestre",
                foto_url: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=800&q=80",
                descripcion: "Hierba perenne y rizomatosa de hojas alargadas verdes con flores delicadas en tonos blancos y morados que brotan cerca del suelo. Usada como ornamental y medicinal en Asia. Prefiere sombra parcial y suelo húmedo."
            },
            {
                id_planta: 5,
                nombre_comun: "Flor de Izote",
                nombre_cientifico: "Yucca guatemalensis",
                nombre_cientifico_completo: "Yucca guatemalensis Baker",
                nombre_familia: "Asparagaceae",
                nombre_zona: "Zona de Hierbas y Medicinales",
                id_zona: 3,
                region_origen: "El Salvador y Mesoamérica",
                codigo_estado: "LC",
                conservacion: "Preocupación Menor",
                habito: "Terrestre",
                foto_url: "https://images.unsplash.com/photo-1533038590840-1cde6e668a91?auto=format&fit=crop&w=800&q=80",
                descripcion: "Arbusto o árbol pequeño de tronco robusto con hojas largas en forma de espada y flores comestibles. Declarada Flor Nacional de El Salvador."
            }
        ];
    }
}

const app = new JardinBotanicoApp();
