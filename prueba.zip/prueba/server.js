const express = require('express');
const cors = require('cors');
const path = require('path');
const { getPool, fallbackData } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// Endpoint: Obtener todas las zonas del jardín
app.get('/api/zonas', async (req, res) => {
    try {
        const pool = await getPool();
        if (pool) {
            const result = await pool.request().query('SELECT * FROM Zonas_Parque WHERE accesible_publico = 1');
            return res.json({ success: true, source: 'sqlserver', data: result.recordset });
        }
        res.json({ success: true, source: 'fallback', data: fallbackData.zonas });
    } catch (err) {
        console.error('Error /api/zonas:', err);
        res.json({ success: true, source: 'fallback', data: fallbackData.zonas });
    }
});

// Endpoint: Obtener lista de plantas (con búsqueda y filtros)
app.get('/api/plantas', async (req, res) => {
    const { busqueda, categoria, zona } = req.query;

    try {
        const pool = await getPool();
        if (pool) {
            let query = `SELECT * FROM vista_inventario_completo WHERE activo = 1`;
            const request = pool.request();

            if (busqueda) {
                request.input('busqueda', `%${busqueda}%`);
                query += ` AND (nombre_comun LIKE @busqueda OR nombre_cientifico_completo LIKE @busqueda OR nombre_familia LIKE @busqueda)`;
            }

            if (zona) {
                request.input('zona', parseInt(zona, 10));
                query += ` AND id_zona = @zona`;
            }

            const result = await request.query(query);
            return res.json({ success: true, source: 'sqlserver', data: result.recordset });
        }

        // Fallback local
        let plantas = [...fallbackData.plantas];

        if (busqueda) {
            const term = busqueda.toLowerCase();
            plantas = plantas.filter(p =>
                p.nombre_comun.toLowerCase().includes(term) ||
                p.nombre_cientifico.toLowerCase().includes(term) ||
                p.nombre_familia.toLowerCase().includes(term) ||
                p.descripcion.toLowerCase().includes(term)
            );
        }

        if (categoria) {
            const cat = categoria.toLowerCase();
            if (cat === 'orquideas') {
                plantas = plantas.filter(p => p.nombre_familia.toLowerCase() === 'orchidaceae' || p.habito === 'Epífita');
            } else if (cat === 'helechos') {
                plantas = plantas.filter(p => p.nombre_familia.toLowerCase() === 'cyatheaceae' || p.habito === 'Terrestre' && p.nombre_comun.includes('Helecho'));
            } else if (cat === 'arboles') {
                plantas = plantas.filter(p => p.altura_max_metros >= 5);
            } else if (cat === 'cactus') {
                plantas = plantas.filter(p => p.nombre_familia.toLowerCase() === 'asparagaceae' || p.nombre_familia.toLowerCase() === 'bromeliaceae');
            }
        }

        if (zona) {
            const zonaId = parseInt(zona, 10);
            plantas = plantas.filter(p => p.id_zona === zonaId);
        }

        res.json({ success: true, source: 'fallback', data: plantas });
    } catch (err) {
        console.error('Error /api/plantas:', err);
        res.json({ success: true, source: 'fallback', data: fallbackData.plantas });
    }
});

// Endpoint: Obtener detalle de una planta por ID
app.get('/api/plantas/:id', async (req, res) => {
    const idPlanta = parseInt(req.params.id, 10);

    try {
        const pool = await getPool();
        if (pool) {
            const request = pool.request();
            request.input('id', idPlanta);
            const result = await request.query('SELECT * FROM vista_inventario_completo WHERE id_planta = @id');

            if (result.recordset.length > 0) {
                return res.json({ success: true, source: 'sqlserver', data: result.recordset[0] });
            }
        }

        const planta = fallbackData.plantas.find(p => p.id_planta === idPlanta) || fallbackData.plantas[0];
        res.json({ success: true, source: 'fallback', data: planta });
    } catch (err) {
        console.error('Error /api/plantas/:id:', err);
        const planta = fallbackData.plantas.find(p => p.id_planta === idPlanta) || fallbackData.plantas[0];
        res.json({ success: true, source: 'fallback', data: planta });
    }
});

// Iniciar servidor express
app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(`🌱 Servidor Jardín Botánico La Laguna activo en:`);
    console.log(`   http://localhost:${PORT}`);
    console.log(`====================================================`);
});
