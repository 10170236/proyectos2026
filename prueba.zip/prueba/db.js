const sql = require('mssql');
require('dotenv').config();

const config = {
    user: process.env.DB_USER || 'sa',
    password: process.env.DB_PASSWORD || '',
    server: process.env.DB_SERVER || 'localhost',
    database: process.env.DB_NAME || 'jardin_botanico_la_laguna',
    port: parseInt(process.env.DB_PORT, 10) || 1433,
    options: {
        encrypt: process.env.DB_ENCRYPT === 'true',
        trustServerCertificate: true
    }
};

// Datos oficiales de las 5 plantas investigadas en el Jardín Botánico La Laguna, El Salvador
const fallbackData = {
    zonas: [
        { id_zona: 1, nombre_zona: "Zona de Vegetación Ornamental y Estanque", descripcion: "Borde junto al estanque de agua, sector con alta iluminación solar.", latitud_centro: 13.6738, longitud_centro: -89.2482, tipo_ecosistema: "Jardín acuático y ornamental", accesible_publico: 1, total_especies: 80 },
        { id_zona: 2, nombre_zona: "Sector de Vegetación Densa y Sombra", descripcion: "Bosque sombreado con suelo rico en hojarasca y alta humedad.", latitud_centro: 13.6740, longitud_centro: -89.2493, tipo_ecosistema: "Sotobosque denso", accesible_publico: 1, total_especies: 110 },
        { id_zona: 3, nombre_zona: "Zona de Hierbas y Medicinales", descripcion: "Colección temática de hierbas perennes, ornamentales y medicinales.", latitud_centro: 13.6744, longitud_centro: -89.2489, tipo_ecosistema: "Jardín de hierbas", accesible_publico: 1, total_especies: 150 }
    ],
    plantas: [
        {
            id_planta: 1,
            codigo_qr: "JBL-PLANT-001",
            nombre_comun: "Cambray (Zinia)",
            nombre_cientifico: "Zinnia elegans",
            nombre_cientifico_completo: "Zinnia elegans L.",
            nombre_familia: "Asteraceae",
            orden_botanico: "Asterales",
            nombre_zona: "Zona de Vegetación Ornamental y Estanque",
            id_zona: 1,
            latitud_centro: 13.6738,
            longitud_centro: -89.2482,
            region_origen: "México y Sudamérica (Cultivada en El Salvador)",
            codigo_estado: "LC",
            conservacion: "Preocupación Menor",
            nivel_riesgo: "Bajo",
            habito: "Terrestre",
            categoria_slug: "arboles",
            es_endemica: 0,
            es_nativa: 0,
            es_flor_nacional: 0,
            altura_max_metros: 0.80,
            epoca_floracion: "Todo el año",
            foto_url: "https://images.unsplash.com/photo-1597848212624-a19eb35e2651?auto=format&fit=crop&w=800&q=80",
            descripcion: "Planta anual de crecimiento rápido que florece abundantemente en colores variados durante la mayor parte del año. Resiste bien el sol directo y los climas cálidos de El Salvador; es muy visitada por mariposas y polinizadores. Ubicada en la zona de vegetación ornamental junto al estanque."
        },
        {
            id_planta: 2,
            codigo_qr: "JBL-PLANT-002",
            nombre_comun: "Bastón del Emperador",
            nombre_cientifico: "Nicolaia elatior",
            nombre_cientifico_completo: "Nicolaia elatior (Jack) Horan",
            nombre_familia: "Zingiberaceae",
            orden_botanico: "Zingiberales",
            nombre_zona: "Sector de Vegetación Densa y Sombra",
            id_zona: 2,
            latitud_centro: 13.6740,
            longitud_centro: -89.2493,
            region_origen: "Indonesia, Malasia y Filipinas",
            codigo_estado: "NE",
            conservacion: "No Evaluado",
            nivel_riesgo: "Bajo",
            habito: "Terrestre",
            categoria_slug: "helechos",
            es_endemica: 0,
            es_nativa: 0,
            es_flor_nacional: 0,
            altura_max_metros: 4.50,
            epoca_floracion: "Época lluviosa",
            foto_url: "https://images.unsplash.com/photo-1596724803730-8022b7a95610?auto=format&fit=crop&w=800&q=80",
            descripcion: "Planta de tallos altos y erectos con flor característica en forma de cono de color rosado intenso. Muy vistosa como flor ornamental y de corte. Pertenece a la familia del jengibre y cuenta con sustancias aromáticas en sus raíces. Ubicada en el sector de vegetación densa y sombreada."
        },
        {
            id_planta: 3,
            codigo_qr: "JBL-PLANT-003",
            nombre_comun: "Corazón Chino (Anturio)",
            nombre_cientifico: "Anthurium andraeanum",
            nombre_cientifico_completo: "Anthurium andraeanum Linden",
            nombre_familia: "Araceae",
            orden_botanico: "Alismatales",
            nombre_zona: "Zona de Hierbas y Medicinales",
            id_zona: 3,
            latitud_centro: 13.6744,
            longitud_centro: -89.2489,
            region_origen: "Colombia y Ecuador",
            codigo_estado: "NE",
            conservacion: "No Evaluado",
            nivel_riesgo: "Bajo",
            habito: "Terrestre",
            categoria_slug: "orquideas",
            es_endemica: 0,
            es_nativa: 0,
            es_flor_nacional: 0,
            altura_max_metros: 0.60,
            epoca_floracion: "Todo el año (humedad constante)",
            foto_url: "https://images.unsplash.com/photo-1605807646983-377bc5a76493?auto=format&fit=crop&w=800&q=80",
            descripcion: "Planta ornamental de sotobosque con hojas brillantes en forma de corazón y una llamativa espata cerosa de color rojo brillante con espádice. Ubicada en la Zona de Hierbas del jardín."
        },
        {
            id_planta: 4,
            codigo_qr: "JBL-PLANT-004",
            nombre_comun: "Bruja (Resurrección)",
            nombre_cientifico: "Kaempferia rotunda",
            nombre_cientifico_completo: "Kaempferia rotunda L.",
            nombre_familia: "Zingiberaceae",
            orden_botanico: "Zingiberales",
            nombre_zona: "Zona de Hierbas y Medicinales",
            id_zona: 3,
            latitud_centro: 13.6744,
            longitud_centro: -89.2489,
            region_origen: "Asia Tropical",
            codigo_estado: "NE",
            conservacion: "No Evaluado",
            nivel_riesgo: "Bajo",
            habito: "Terrestre",
            categoria_slug: "cactus",
            es_endemica: 0,
            es_nativa: 0,
            es_flor_nacional: 0,
            altura_max_metros: 0.40,
            epoca_floracion: "Inicio de época lluviosa",
            foto_url: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=800&q=80",
            descripcion: "Hierba perenne y rizomatosa de hojas alargadas verdes con flores delicadas en tonos blancos y morados que brotan cerca del suelo. Usada como ornamental y medicinal en Asia. Prefiere sombra parcial y suelo húmedo."
        },
        {
            id_planta: 5,
            codigo_qr: "JBL-PLANT-005",
            nombre_comun: "Flor de Izote",
            nombre_cientifico: "Yucca guatemalensis",
            nombre_cientifico_completo: "Yucca guatemalensis Baker",
            nombre_familia: "Asparagaceae",
            orden_botanico: "Asparagales",
            nombre_zona: "Zona de Hierbas y Medicinales",
            id_zona: 3,
            latitud_centro: 13.6744,
            longitud_centro: -89.2489,
            region_origen: "El Salvador y Mesoamérica",
            codigo_estado: "LC",
            conservacion: "Preocupación Menor",
            nivel_riesgo: "Bajo",
            habito: "Terrestre",
            categoria_slug: "arboles",
            es_endemica: 0,
            es_nativa: 1,
            es_flor_nacional: 1,
            altura_max_metros: 8.00,
            epoca_floracion: "Diciembre - Febrero",
            foto_url: "https://images.unsplash.com/photo-1533038590840-1cde6e668a91?auto=format&fit=crop&w=800&q=80",
            descripcion: "Arbusto o árbol pequeño de tronco robusto con hojas largas en forma de espada y flores comestibles. Declarada Flor Nacional de El Salvador."
        }
    ]
};

let poolPromise = null;
let isSqlConnected = false;

async function getPool() {
    if (!poolPromise) {
        poolPromise = new sql.ConnectionPool(config)
            .connect()
            .then(pool => {
                console.log('✅ Conectado a SQL Server DB:', config.database);
                isSqlConnected = true;
                return pool;
            })
            .catch(err => {
                console.warn('⚠️ Funcionando en modo local con las 5 plantas investigadas.');
                isSqlConnected = false;
                return null;
            });
    }
    return poolPromise;
}

module.exports = {
    sql,
    getPool,
    fallbackData,
    isSqlConnected: () => isSqlConnected
};
