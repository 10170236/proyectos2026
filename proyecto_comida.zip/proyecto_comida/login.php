<?php
include("conexion.php");

$email    = $_POST['email'];
$password = $_POST['password'];

// REFINAMIENTO 1: Evitar Inyección SQL básica. 
// Limpiamos el texto ingresado para que nadie pueda "hackear" la consulta.
$email_seguro = $conn->real_escape_string($email);

// REFINAMIENTO 2: Arreglamos el error de AES_ENCRYPT agregando ', 'llave123''
$sql = "SELECT * FROM Usuarios WHERE correo = HEX(AES_ENCRYPT('$email_seguro', 'llave123'))";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // REFINAMIENTO 3: Convertimos la contraseña ingresada a SHA256 (como está en la BD)
    $password_hasheada = hash('sha256', $password);

    // Comparamos el hash generado en PHP con el que está guardado en la columna 'contrasena'
    if ($password_hasheada === $row['contrasena']) {
        session_start();

        $_SESSION['usuario'] = $row['nombre']; 
        $_SESSION['id_usuario'] = $row['id_usuario']; // 🔥 CLAVE

        header("Location: menu-principal.html");
        exit(); // REFINAMIENTO 4: Siempre pon exit() después de un header para detener el script.
    } else {
        echo "Contraseña incorrecta";
    }
} else {
    echo "Usuario no encontrado";
}

$conn->close();
?>