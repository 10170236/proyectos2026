// ------------------- VARIABLES GLOBALES -------------------
let carrito = JSON.parse(localStorage.getItem('carrito')) || [];
const tarifaEnvio = 2.50;

// ------------------- INICIALIZACIÓN CUANDO CARGA LA PÁGINA -------------------
document.addEventListener('DOMContentLoaded', () => {
    // Actualizar badge del carrito en todas las páginas
    actualizarBadgeCarrito();

    // Validar formularios según la página
    if (window.location.pathname.includes('index.html') || window.location.pathname === '/') {
        inicializarFormularioLogin();
    }

    if (window.location.pathname.includes('registro.html')) {
        inicializarFormularioRegistro();
    }

    if (document.getElementById('lista-carrito')) {
    mostrarCarrito();
    inicializarFormularioDireccion();
}

    if (window.location.pathname.includes('pago.html')) {
        mostrarResumenPago();
        inicializarFormularioPago();
    }
});

// ------------------- FUNCIONES DEL CARRITO -------------------
function agregarAlCarrito(id, nombre, precio, imagen) {
    const productoExistente = carrito.find(item => item.id_producto === id);

    if (productoExistente) {
        productoExistente.cantidad += 1;
    } else {
        carrito.push({
            id_producto: id, // 🔥 CLAVE
            nombre: nombre,
            precio: precio,
            imagen: imagen,
            cantidad: 1
        });
    }

    localStorage.setItem('carrito', JSON.stringify(carrito));
    actualizarBadgeCarrito();
    mostrarNotificacion(`${nombre} agregado al carrito!`, 'success');
}

function eliminarDelCarrito(nombre) {
    carrito = carrito.filter(item => item.nombre !== nombre);
    localStorage.setItem('carrito', JSON.stringify(carrito));
    mostrarCarrito();
    actualizarBadgeCarrito();
    mostrarNotificacion('Producto eliminado del carrito', 'info');
}

function calcularTotalCarrito() {
    const subtotal = carrito.reduce((total, item) => total + (item.precio * item.cantidad), 0);
    return {
        subtotal: subtotal.toFixed(2),
        total: (subtotal + tarifaEnvio).toFixed(2)
    };
}

function actualizarBadgeCarrito() {
    const badge = document.getElementById('carrito-badge');
    if (badge) {
        const cantidadTotal = carrito.reduce((total, item) => total + item.cantidad, 0);
        badge.textContent = cantidadTotal;
    }
}

function mostrarCarrito() {
    const listaCarrito = document.getElementById('lista-carrito');
    const subtotalElement = document.getElementById('subtotal');
    const envioElement = document.getElementById('envio');
    const totalElement = document.getElementById('total');

    if (!listaCarrito) return;

    // Limpiar lista anterior
    listaCarrito.innerHTML = '';

    if (carrito.length === 0) {
        listaCarrito.innerHTML = '<li class="item-carrito"><p>Tu carrito está vacío</p></li>';
        subtotalElement.textContent = '0.00';
        envioElement.textContent = '0.00';
        totalElement.textContent = '0.00';
        return;
    }

    // Agregar cada producto al carrito
    carrito.forEach(item => {
        const li = document.createElement('li');
        li.className = 'item-carrito';

        li.innerHTML = `
            <img src="${item.imagen}" alt="${item.nombre}" class="item-carrito-img">
            <div class="item-carrito-info">
                <h4>${item.nombre}</h4>
                <p>Cantidad: ${item.cantidad}</p>
            </div>
            <span class="item-carrito-precio">$${(item.precio * item.cantidad).toFixed(2)}</span>
            <span class="item-carrito-accion" onclick="eliminarDelCarrito('${item.nombre}')">
                <i class="fas fa-trash-alt"></i>
            </span>
        `;

        listaCarrito.appendChild(li);
    });

    // Calcular y mostrar totales
    const totales = calcularTotalCarrito();
    subtotalElement.textContent = totales.subtotal;
    envioElement.textContent = tarifaEnvio.toFixed(2);
    totalElement.textContent = totales.total;
}

// ------------------- FUNCIONES DE FORMULARIOS -------------------
function inicializarFormularioLogin() {
    const formLogin = document.getElementById('login-form');
    if (formLogin) {
        formLogin.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            // Simulación de login exitoso
            if (email && password) {
                mostrarNotificacion('Inicio de sesión exitoso!', 'success');
                setTimeout(() => {
                    window.location.href = 'menu-principal.html';
                }, 1500);
            } else {
                mostrarNotificacion('Completa todos los campos', 'error');
            }
        });
    }
}

function inicializarFormularioRegistro() {
    const formRegistro = document.getElementById('registro-form');
    if (formRegistro) {
        formRegistro.addEventListener('submit', (e) => {
            e.preventDefault();
            const nombre = document.getElementById('nombre').value;
            const email = document.getElementById('email-registro').value;
            const telefono = document.getElementById('telefono').value;
            const password = document.getElementById('password-registro').value;
            const passwordConfirm = document.getElementById('password-confirm').value;

            // Validaciones básicas
            if (!nombre || !email || !telefono || !password || !passwordConfirm) {
                mostrarNotificacion('Completa todos los campos', 'error');
                return;
            }

            if (password !== passwordConfirm) {
                mostrarNotificacion('Las contraseñas no coinciden', 'error');
                return;
            }

            if (password.length < 6) {
                mostrarNotificacion('La contraseña debe tener al menos 6 caracteres', 'error');
                return;
            }

            // Simulación de registro exitoso
            mostrarNotificacion('Registro exitoso! Redirigiendo al menú', 'success');
            setTimeout(() => {
                window.location.href = 'menu-principal.html';
            }, 1500);
        });
    }
}

function inicializarFormularioDireccion() {
    const formDireccion = document.getElementById('form-direccion');
    const mensajeError = document.getElementById('mensaje-error');
    const btnContinuar = document.getElementById('btn-continuar-pago');

    if (formDireccion) {
        formDireccion.addEventListener('submit', (e) => {
            e.preventDefault();
        });

        btnContinuar.addEventListener('click', () => {
            const calle = document.getElementById('calle').value.trim();
            const ciudad = document.getElementById('ciudad').value.trim();
            const referencia = document.getElementById('referencia').value.trim();
            const codigoPostal = document.getElementById('codigo-postal').value.trim();

            // Validar campos requeridos
            if (!calle || !ciudad || !referencia) {
                mensajeError.textContent = 'Los campos calle, ciudad y referencia son obligatorios';
                mensajeError.classList.add('activo');
                return;
            }

            // Guardar dirección en localStorage
            const direccion = { calle, ciudad, referencia, codigoPostal };
            localStorage.setItem('direccion', JSON.stringify(direccion));
            
            mensajeError.classList.remove('activo');
            mostrarNotificacion('Dirección guardada!', 'success');
            setTimeout(() => {
                window.location.href = 'pago.html';
            }, 1500);
        });
    }
}

function inicializarFormularioPago() {
    const opcionesMetodo = document.querySelectorAll('.metodo-pago-opcion');
    const btnCompletarPago = document.getElementById('btn-completar-pago');

    // ✅ SELECCIÓN DE MÉTODO + MOSTRAR CAMPOS
    opcionesMetodo.forEach(opcion => {
        opcion.addEventListener('click', () => {

            opcionesMetodo.forEach(o => o.classList.remove('activo'));
            opcion.classList.add('activo');

            // ocultar todos
            document.getElementById('campos-tarjeta').style.display = 'none';
            document.getElementById('campos-paypal').style.display = 'none';
            document.getElementById('campos-efectivo').style.display = 'none';

            // mostrar según selección
            if (opcion.id === 'opcion-tarjeta') {
                document.getElementById('campos-tarjeta').style.display = 'grid';
            } else if (opcion.id === 'opcion-paypal') {
                document.getElementById('campos-paypal').style.display = 'block';
            } else if (opcion.id === 'opcion-efectivo') {
                document.getElementById('campos-efectivo').style.display = 'block';
            }
        });
    });

    // ✅ BOTÓN PAGAR
    if (btnCompletarPago) {
        btnCompletarPago.addEventListener('click', (e) => {
            e.preventDefault();

            const metodoSeleccionado = document.querySelector('.metodo-pago-opcion.activo');

            if (!metodoSeleccionado) {
                mostrarNotificacion('Selecciona un método de pago', 'error');
                return;
            }

            // 🔥 SOLO VALIDAR TARJETA
            if (metodoSeleccionado.id === 'opcion-tarjeta') {
                const numeroTarjeta = document.getElementById('numero-tarjeta')?.value.trim();
                const fechaVencimiento = document.getElementById('fecha-vencimiento')?.value.trim();
                const cvv = document.getElementById('cvv')?.value.trim();

                if (!numeroTarjeta || !fechaVencimiento || !cvv) {
                    mostrarNotificacion('Completa los datos de la tarjeta', 'error');
                    return;
                }
            }

            // mensajes opcionales
            if (metodoSeleccionado.id === 'opcion-paypal') {
                mostrarNotificacion('Redirigiendo a PayPal...', 'info');
            }

            if (metodoSeleccionado.id === 'opcion-efectivo') {
                mostrarNotificacion('Pago en efectivo seleccionado', 'info');
            }

            // ✅ FINALIZAR PEDIDO
           // 🔥 OBTENER DATOS
const carritoData = JSON.parse(localStorage.getItem('carrito')) || [];
const direccion = JSON.parse(localStorage.getItem('direccion')) || {};

const total = carritoData.reduce((sum, p) => sum + (p.precio * p.cantidad), 0) + 2.50;

// 🔥 ENVIAR A PHP
fetch("guardar_pedido.php", {
    method: "POST",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify({
        carrito: carritoData,
        total: total,
        direccion: direccion
    })
})
.then(res => res.text())
.then(data => {
    console.log(data);

    // ✅ CONFIRMAR
    mostrarNotificacion('¡Pedido guardado en la base de datos!', 'success');

    localStorage.removeItem('carrito');
    localStorage.removeItem('direccion');
    carrito = [];

    setTimeout(() => {
        window.location.href = 'menu-principal.html';
    }, 2000);
})
.catch(error => {
    console.error(error);
    mostrarNotificacion('Error al guardar pedido', 'error');
});

            localStorage.removeItem('carrito');
            localStorage.removeItem('direccion');
            carrito = [];

            setTimeout(() => {
                window.location.href = 'menu-principal.html';
            }, 2000);
        });
    }
}
// ------------------- FUNCIONES AUXILIARES -------------------
function mostrarNotificacion(mensaje, tipo) {
    // Crear elemento de notificación
    const notificacion = document.createElement('div');
    notificacion.style.position = 'fixed';
    notificacion.style.bottom = '20px';
    notificacion.style.right = '20px';
    notificacion.style.padding = '15px 25px';
    notificacion.style.borderRadius = '8px';
    notificacion.style.color = 'white';
    notificacion.style.fontWeight = '500';
    notificacion.style.zIndex = '200';
    notificacion.style.boxShadow = '0 4px 20px rgba(0,0,0,0.2)';
    notificacion.style.transition = 'all 0.3s ease';
    notificacion.style.opacity = '0';
    notificacion.style.transform = 'translateY(20px)';

    // Asignar colores según tipo
    switch(tipo) {
        case 'success':
            notificacion.style.backgroundColor = '#00B42A';
            notificacion.innerHTML = `<i class="fas fa-check-circle"></i> ${mensaje}`;
            break;
        case 'error':
            notificacion.style.backgroundColor = '#F53F3F';
            notificacion.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${mensaje}`;
            break;
        case 'info':
            notificacion.style.backgroundColor = '#165DFF';
            notificacion.innerHTML = `<i class="fas fa-info-circle"></i> ${mensaje}`;
            break;
    }

    // Agregar al DOM y animar
    document.body.appendChild(notificacion);
    setTimeout(() => {
        notificacion.style.opacity = '1';
        notificacion.style.transform = 'translateY(0)';
    }, 100);

    // Eliminar después de 3 segundos
    setTimeout(() => {
        notificacion.style.opacity = '0';
        notificacion.style.transform = 'translateY(20px)';
        setTimeout(() => {
            document.body.removeChild(notificacion);
        }, 300);
    }, 3000);
}

function mostrarResumenPago() {
    const totalPagoElement = document.getElementById('total-pago');
    const direccionGuardada = JSON.parse(localStorage.getItem('direccion'));
    const direccionElement = document.getElementById('direccion-entrega');

    if (direccionElement && direccionGuardada) {
        direccionElement.innerHTML = `
            <p><strong>Calle:</strong> ${direccionGuardada.calle}</p>
            <p><strong>Ciudad:</strong> ${direccionGuardada.ciudad}</p>
            <p><strong>Referencia:</strong> ${direccionGuardada.referencia}</p>
            <p><strong>Código Postal:</strong> ${direccionGuardada.codigoPostal || 'No especificado'}</p>
        `;
    }

    if (totalPagoElement) {
        const totales = calcularTotalCarrito();
        totalPagoElement.textContent = totales.total;
    }
}

// ------------------- FUNCIÓN PARA VACIAR CARRITO (OPCIONAL) -------------------
function vaciarCarrito() {
    carrito = [];
    localStorage.removeItem('carrito');
    mostrarCarrito();
    actualizarBadgeCarrito();
    mostrarNotificacion('Carrito vaciado', 'info');
}

// 🔥 HACER GLOBAL LA FUNCIÓN
window.agregarYIrAlCarrito = function(id, nombre, precio, imagen) {
    agregarAlCarrito(id, nombre, precio, imagen);
    window.location.href = "carrito.html";

};

