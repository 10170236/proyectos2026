<?php
$servername = "localhost";
$username = "root";   // o el usuario que uses
$password = "";       // tu contraseña de MySQL
$dbname = "appdepedidos";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>