<?php
include('conexion.php');

$nombre   = $_POST['nombre'];
$email    = $_POST['email-registro'];
$telefono = $_POST['telefono'];
$password = $_POST['password-registro'];


// NOTA: El campo 'telefono' fue omitido porque la tabla Usuarios no tiene esa columna.
// $telefono = $_POST['telefono']; 

// 1. Limpiamos los datos para proteger la base de datos (Inyección SQL)
$nombre_seguro = $conn->real_escape_string($nombre);
$telefono_seguro = $conn->real_escape_string($telefono);
$email_seguro  = $conn->real_escape_string($email);

// 2. Hasheamos la contraseña con SHA256 para que coincida con la lógica del login
$passwordHash = hash('sha256', $password);

// 3. Insertamos usando los nombres EXACTOS de las columnas (correo, contrasena)
// y aplicamos la misma encriptación AES_ENCRYPT para el correo con 'llave123'
$sql = "INSERT INTO Usuarios (nombre, correo, telefono, contrasena) 
        VALUES ('$nombre_seguro', HEX(AES_ENCRYPT('$email_seguro', 'llave123')), '$telefono_seguro', '$passwordHash')";

if ($conn->query($sql) === TRUE) {
    // Registro exitoso, redirigimos al menú
    header("Location: menu-principal.html");
    exit();
} else {
    echo "Error en SQL: " . $conn->error;
}

$conn->close();
?>