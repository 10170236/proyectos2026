<?php
include("conexion.php");


session_start();

if (!isset($_SESSION['id_usuario'])) {
    echo "Usuario no logueado";
    exit;
}

$id_usuario = $_SESSION['id_usuario'];

// 🔥 VER ERRORES (IMPORTANTE PARA DEBUG)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 🔥 RECIBIR JSON
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo "No llegaron datos";
    exit;
}

$carrito = $data['carrito'];

$total = $data['total'];
$direccionData = $data['direccion'];

// ⚠️ USUARIO FIJO (CAMBIA ESTO CUANDO TENGAS LOGIN REAL)


// 🔥 VALIDAR
if (!$carrito || !$direccionData) {
    echo "Datos incompletos";
    exit;
}

// ------------------- 1. GUARDAR DIRECCIÓN -------------------
$stmt = $conn->prepare("INSERT INTO direcciones (id_usuario, calle, ciudad, referencia) VALUES (?, ?, ?, ?)");

$stmt->bind_param(
    "isss",
    $id_usuario,
    $direccionData['calle'],
    $direccionData['ciudad'],
    $direccionData['referencia']
);

if (!$stmt->execute()) {
    echo "Error al guardar dirección: " . $stmt->error;
    exit;
}

$id_direccion = $stmt->insert_id;

// ------------------- 2. GUARDAR PEDIDO -------------------
$stmt = $conn->prepare("INSERT INTO pedidos (id_usuario, id_direccion, fecha, total) VALUES (?, ?, NOW(), ?)");

$stmt->bind_param("iid", $id_usuario, $id_direccion, $total);

if (!$stmt->execute()) {
    echo "Error al guardar pedido: " . $stmt->error;
    exit;
}

$id_pedido = $stmt->insert_id;

// ------------------- 3. GUARDAR DETALLES -------------------
foreach ($carrito as $item) {

    if (!isset($item['id_producto'])) {
        echo "ERROR: id_producto no viene";
        exit;
    }

    $id_producto = intval($item['id_producto']);
    $cantidad = intval($item['cantidad']);
    $precio = floatval($item['precio']);

    $sql = "INSERT INTO detallesdpedidos 
            (id_pedido, id_producto, cantidad, precio_unitario)
            VALUES 
            ($id_pedido, $id_producto, $cantidad, $precio)";

    if (!mysqli_query($conn, $sql)) {
        echo "ERROR SQL: " . mysqli_error($conn);
        exit;
    }
}

echo "OK";