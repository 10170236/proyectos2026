﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Hotel
{
    public class habitacion
    {
        public string Numero { get; set; }
        public int Dias { get; set; }

        public virtual double CalcularCosto()
        {
            return 0;
        }

        public virtual string Tipo()
        {
            return "Habitación genérica";
        }
    }

    public class HabitacionEstandar : habitacion
    {
        public override double CalcularCosto()
        {
            return Dias * 50;
        }

        public override string Tipo()
        {
            return "Estandar";
        }
    }

    public class HabitacionSuite : habitacion
    {
        public override double CalcularCosto()
        {
            return Dias * 100;
        }

        public override string Tipo()
        {
            return "Suite";
        }
    }

    public class HabitacionLujo : habitacion
    {
        public override double CalcularCosto()
        {
            return Dias * 200;
        }

        public override string Tipo()
        {
            return "Lujo";
        }
    }

    public class Registro
    {
        public string Cliente { get; set; }
        public habitacion habitacionAsignada { get; set; }
    }
}
