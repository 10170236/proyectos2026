﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Hotel
{
    public partial class Form1: Form
    {
        private List<Registro> registros = new List<Registro>();
        public Form1()
        {
            InitializeComponent();

            List<Registro> registros = new List<Registro>();

            cmbtiphabitacion.Items.Add("Estandar");
            cmbtiphabitacion.Items.Add("Suite");
            cmbtiphabitacion.Items.Add("Lujo");

            dgvregistros.Columns.Add("Cliente", "Cliente");
            dgvregistros.Columns.Add("TipoHabitacion", "Tipo de Habitación");
            dgvregistros.Columns.Add("NumeroHabitacion", "Número de Habitación");
            dgvregistros.Columns.Add("Dias", "Días de Estancia");
            dgvregistros.Columns.Add("Costo", "Costo Total ($)");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string cliente = txtcliente.Text;
            string tipo = cmbtiphabitacion.SelectedItem?.ToString();
            string numero = txtnumero.Text;
            int dias = (int)numdias.Value;

            if (string.IsNullOrEmpty(cliente) ||
                string.IsNullOrEmpty(tipo) ||
                string.IsNullOrEmpty(numero) ||
                dias <= 0)
            {
                MessageBox.Show("Por favor complete todos los campos correctamente.");
                return;
            }

            habitacion habitacion;

            switch (tipo)
            {
                case "Estandar":
                    habitacion = new HabitacionEstandar();
                    break;
                case "Suite":
                    habitacion = new HabitacionSuite();
                    break;
                case "Lujo":
                    habitacion = new HabitacionLujo();
                    break;
                default:
                    habitacion = new habitacion();
                    break;
            }

            habitacion.Numero = numero;
            habitacion.Dias = dias;


            Registro reg = new Registro
            {
                Cliente = cliente,
                habitacionAsignada = habitacion
            };



            registros.Add(reg);

            dgvregistros.Rows.Add(
                    reg.Cliente,
                    habitacion.Tipo(),
                    habitacion.Numero,
                    habitacion.Dias,
                    habitacion.CalcularCosto()
                );

            LimpiarCampos();
        }

        private void LimpiarCampos()
        {
            txtcliente.Text = "";
            cmbtiphabitacion.SelectedIndex = -1;
            txtnumero.Text = "";
            numdias.Value = 1;
        }
    }
}
