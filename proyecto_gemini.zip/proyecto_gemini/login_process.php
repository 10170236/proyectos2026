<?php
session_start();
require_once 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conexion->prepare("SELECT id, nombre, password, rol FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if (password_verify($password, $user['password'])) {
            $_SESSION['usuario_id'] = $user['id'];
            $_SESSION['nombre'] = $user['nombre'];
            $_SESSION['rol'] = $user['rol'];

            // --- BLOQUE DE REDIRECCIÓN CORREGIDO ---
            if ($user['rol'] == 'admin') {
                // El admin va directo a la gestión de usuarios
                header("Location: registro.php");
            } else if ($user['rol'] == 'docente') {
                // El docente va a su panel de grupos/proyectos
                header("Location: dashboard_docente.php");
            } else if ($user['rol'] == 'estudiante') {
                // El estudiante va a sus tareas
                header("Location: dashboard_estudiante.php");
            }
            // ---------------------------------------
            exit();
        } else {
            echo "<script>alert('Contraseña incorrecta'); window.location='index.php';</script>";
        }
    } else {
        echo "<script>alert('El usuario no existe'); window.location='index.php';</script>";
    }
}
?>