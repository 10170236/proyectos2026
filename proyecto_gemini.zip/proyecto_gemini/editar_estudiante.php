<?php
require_once 'conexion.php';
session_start();

// 1. Seguridad: Solo Docentes o Administradores
if (!isset($_SESSION['usuario_id']) || ($_SESSION['rol'] != 'docente' && $_SESSION['rol'] != 'admin')) {
    header("Location: index.php");
    exit();
}

// 2. Verificar que recibimos el ID del estudiante por la URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: dashboard_docente.php");
    exit();
}

$id_estudiante = $_GET['id'];

// 3. Consultar los datos actuales del estudiante
$stmt = $conexion->prepare("SELECT * FROM usuarios WHERE id = ? AND rol = 'estudiante'");
$stmt->bind_param("i", $id_estudiante);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    die("Error: El estudiante no existe o no tienes permiso para editarlo.");
}

$est = $resultado->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Estudiante | SGP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Editar Datos de Estudiante</h5>
                    <small>ID: <?php echo $est['id']; ?></small>
                </div>
                <div class="card-body">
                    <form action="acciones.php" method="POST">
                        <input type="hidden" name="id_usuario" value="<?php echo $est['id']; ?>">

                        <div class="mb-3">
                            <label class="form-label">Nombre</label>
                            <input type="text" name="nombre" class="form-control" value="<?php echo $est['nombre']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Apellido</label>
                            <input type="text" name="apellido" class="form-control" value="<?php echo $est['apellido']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">NIE (Número de Identificación)</label>
                            <input type="text" name="nie" class="form-control" value="<?php echo $est['nie']; ?>" required maxlength="12">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Correo Electrónico</label>
                            <input type="email" name="email" class="form-control" value="<?php echo $est['email']; ?>" required>
                        </div>

                        <div class="mb-3 border p-2 rounded bg-white text-muted">
                            <label class="form-label fw-bold">Seguridad</label>
                            <input type="password" name="password" class="form-control" placeholder="Nueva contraseña (dejar vacío para no cambiar)">
                            <small class="form-text">Si el estudiante olvidó su clave, puedes escribir una nueva aquí.</small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Comentario Interno</label>
                            <textarea name="comentario" class="form-control" rows="3"><?php echo $est['comentario']; ?></textarea>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="dashboard_docente.php" class="btn btn-secondary me-md-2">Cancelar</a>
                            <button type="submit" name="actualizar_estudiante" class="btn btn-primary">Guardar Cambios</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>