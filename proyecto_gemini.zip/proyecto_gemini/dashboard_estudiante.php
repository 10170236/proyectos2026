<?php
require_once 'conexion.php';
session_start();

// Seguridad nivel Pro
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'estudiante') {
    header("Location: index.php");
    exit();
}

$estudiante_id = $_SESSION['usuario_id'];

// 1. Obtener ID del proyecto y datos del estudiante usando Prepared Statements
$query_proy = "SELECT p.id as proyecto_id, p.nombre_proyecto FROM proyectos p 
               JOIN grupos g ON p.grupo_id = g.id 
               JOIN estudiantes_grupos eg ON g.id = eg.grupo_id 
               WHERE eg.usuario_id = ?";
$stmt_p = $conexion->prepare($query_proy);
$stmt_p->bind_param("i", $estudiante_id);
$stmt_p->execute();
$res_p = $stmt_p->get_result()->fetch_assoc();
$proyecto_id = $res_p['proyecto_id'] ?? 0;

// 2. Lógica de Cálculos (Solo si existe el proyecto)
$porcentaje = 0;
if ($proyecto_id > 0) {
    // Optimizamos en una sola pasada si es posible, pero mantenemos tu lógica clara:
    $total_res = $conexion->query("SELECT COUNT(*) as total FROM tareas WHERE proyecto_id = $proyecto_id");
    $total = $total_res->fetch_assoc()['total'] ?? 0;

    $fin_res = $conexion->query("SELECT COUNT(*) as fin FROM tareas WHERE proyecto_id = $proyecto_id AND estado = 'Finalizada'");
    $finalizadas = $fin_res->fetch_assoc()['fin'] ?? 0;

    $porcentaje = ($total > 0) ? round(($finalizadas / $total) * 100) : 0;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Panel | Estudiante</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .progress { border-radius: 10px; background-color: #e9ecef; }
        .card { border: none; transition: transform 0.2s; }
        .card:hover { transform: translateY(-2px); }
    </style>
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center">
        <h2>Bienvenido, <span class="text-primary"><?php echo htmlspecialchars($_SESSION['nombre']); ?></span></h2>
        <a href="logout.php" class="btn btn-outline-danger btn-sm">Cerrar Sesión</a>
    </div>
    <hr>

    <?php if ($proyecto_id > 0): ?>
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <label class="form-label fw-bold text-muted mb-0">
                        <i class="bi bi-journal-check me-2"></i>Proyecto: <?php echo htmlspecialchars($res_p['nombre_proyecto']); ?>
                    </label>
                    <span class="fw-bold text-success"><?php echo $porcentaje; ?>%</span>
                </div>
                <div class="progress" style="height: 20px;">
                    <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" 
                         role="progressbar" 
                         style="width: <?php echo $porcentaje; ?>%" 
                         aria-valuenow="<?php echo $porcentaje; ?>" aria-valuemin="0" aria-valuemax="100">
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8">
                <h4 class="mb-3 text-secondary">Mis Tareas</h4>
                <?php
                // Consulta de tareas (Uso de Prepared Statement recomendado para mayor seguridad)
                $stmt_t = $conexion->prepare("SELECT * FROM tareas WHERE proyecto_id = ? ORDER BY id DESC");
                $stmt_t->bind_param("i", $proyecto_id);
                $stmt_t->execute();
                $tareas = $stmt_t->get_result();
                
                if ($tareas->num_rows > 0):
                    while($t = $tareas->fetch_assoc()): 
                ?>
                    <div class="card mb-3 shadow-sm">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($t['titulo']); ?></h6>
                                <span class="badge <?php 
                                    echo ($t['estado'] == 'Finalizada') ? 'bg-success' : 
                                         (($t['estado'] == 'En proceso') ? 'bg-warning text-dark' : 'bg-secondary'); 
                                ?>">
                                    <?php echo $t['estado']; ?>
                                </span>
                            </div>

                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-dark dropdown-toggle" data-bs-toggle="dropdown">
                                    Cambiar Estado
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                    <li>
                                        <a class="dropdown-item" href="acciones_estudiante.php?accion=cambiar_estado&id=<?php echo $t['id']; ?>&estado=En proceso">
                                            <i class="bi bi-play-fill text-warning me-2"></i>Marcar "En proceso"
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="acciones_estudiante.php?accion=cambiar_estado&id=<?php echo $t['id']; ?>&estado=Finalizada">
                                            <i class="bi bi-check-circle-fill text-success me-2"></i>Marcar "Finalizada"
                                        </a>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item" href="acciones_estudiante.php?accion=cambiar_estado&id=<?php echo $t['id']; ?>&estado=Asignada">
                                            <i class="bi bi-arrow-counterclockwise me-2"></i>Reiniciar
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php 
                    endwhile; 
                else:
                    echo '<div class="alert alert-info">Aún no tienes tareas asignadas.</div>';
                endif; 
                ?>
            </div>
            
            <div class="col-md-4">
                <div class="card shadow-sm border-0 bg-white p-3 text-center">
                    <h6 class="text-muted">Estado del Sistema</h6>
                    <p class="small text-success mb-0"><i class="bi bi-circle-fill me-1"></i> Conectado</p>
                </div>
            </div>
        </div>

    <?php else: ?>
        <div class="alert alert-warning shadow-sm">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            No estás asignado a ningún proyecto actualmente. Contacta a tu docente.
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>