<?php
// 1. Iniciar el manejo de sesiones para poder acceder a la sesión actual
session_start();

// 2. Limpiar todas las variables de sesión
$_SESSION = array();

// 3. Si se desea destruir la sesión completamente, borre también la cookie de sesión.
// Nota: Esto destruye la sesión, no solo los datos de la sesión.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 4. Finalmente, destruir la sesión en el servidor
session_destroy();

// 5. Redirigir al formulario de login con un mensaje (opcional)
header("Location: index.php?msg=sesion_cerrada");
exit();
?>