<?php
session_start();
require_once 'conexion.php';
if (!isset($_SESSION['usuario_id']) || ($_SESSION['rol'] != 'docente' && $_SESSION['rol'] != 'admin')) {
    header("Location: index.php"); exit();
}

// Lógica simple para listar datos
$estudiantes = $conexion->query("SELECT * FROM usuarios WHERE rol = 'estudiante'");
$grupos = $conexion->query("SELECT g.*, u.nombre as docente FROM grupos g JOIN usuarios u ON g.docente_id = u.id");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Control Docente</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
        <div class="container">
            <a class="navbar-brand" href="#">SGP - Docente</a>
            <span class="navbar-text text-white">Hola, <?php echo $_SESSION['nombre']; ?></span>
            <a href="logout.php" class="btn btn-outline-danger btn-sm ms-3">Cerrar Sesión</a>
        </div>
    </nav>

    <div class="container mt-4">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#estudiantes">Estudiantes</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#grupos">Grupos</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#proyectos">Proyectos</button></li>
        </ul>

        <div class="tab-content bg-white p-4 border border-top-0 shadow-sm">
            <div class="tab-pane fade show active" id="estudiantes">
                <div class="d-flex justify-content-between mb-3">
                    <h4>Gestión de Alumnos</h4>
                    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalEstudiante">Nuevo Estudiante</button>
                </div>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>NIE</th>
                            <th>Nombre Completo</th>
                            <th>Email</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($est = $estudiantes->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $est['nie']; ?></td>
                            <td><?php echo $est['nombre'] . " " . $est['apellido']; ?></td>
                            <td><?php echo $est['email']; ?></td>
                            <td>
                                <a href="editar_estudiante.php?id=<?php echo $est['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                                <a href="acciones.php?eliminar_est=<?php echo $est['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar estudiante?')">Eliminar</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <div class="tab-pane fade" id="grupos">
                <h4>Grupos Existentes</h4>
                <form action="acciones.php" method="POST" class="row g-3 mb-4">
                    <div class="col-auto"><input type="text" name="nombre_grupo" class="form-control" placeholder="Nombre del Grupo" required></div>
                    <div class="col-auto"><button type="submit" name="crear_grupo" class="btn btn-success">Crear Grupo</button></div>
                </form>
                <div class="row">
                    <?php while($g = $grupos->fetch_assoc()): ?>
                        <div class="col-md-4 mb-3">
                            <div class="card shadow-sm">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $g['nombre_grupo']; ?></h5>
                                    <p class="small text-muted">ID: <?php echo $g['id']; ?></p>
                                    <a href="gestionar_grupo.php?id=<?php echo $g['id']; ?>" class="btn btn-outline-primary btn-sm w-100">Administrar Alumnos</a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>

            <div class="tab-pane fade" id="proyectos">
                <h4>Proyectos y Asignación</h4>
                <form action="acciones.php" method="POST" class="mb-4">
                    <div class="row g-2">
                        <div class="col-md-4"><input type="text" name="nom_proy" class="form-control" placeholder="Nombre Proyecto" required></div>
                        <div class="col-md-4">
                            <select name="grupo_id" class="form-select">
                                <option value="">Asignar a Grupo...</option>
                                <?php 
                                $grupos->data_seek(0); // Reiniciar puntero
                                while($g = $grupos->fetch_assoc()) echo "<option value='".$g['id']."'>".$g['nombre_grupo']."</option>"; 
                                ?>
                            </select>
                        </div>
                        <div class="col-md-2"><button type="submit" name="crear_proy" class="btn btn-info w-100">Crear</button></div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalEstudiante" tabindex="-1">
        <div class="modal-dialog">
            <form class="modal-content" action="acciones.php" method="POST">
                <div class="modal-header"><h5>Nuevo Estudiante</h5></div>
                <div class="modal-body">
                    <input type="text" name="nombre" class="form-control mb-2" placeholder="Nombre" required>
                    <input type="text" name="apellido" class="form-control mb-2" placeholder="Apellido" required>
                    <input type="number" name="nie" class="form-control mb-2" placeholder="NIE (12 dígitos)" required oninput="javascript: if (this.value.length > 12) this.value = this.value.slice(0, 12);">
                    <input type="email" name="email" class="form-control mb-2" placeholder="Correo electrónico" required>
                    <input type="password" name="password" class="form-control mb-2" placeholder="Contraseña Temporal" required>
                    <textarea name="comentario" class="form-control" placeholder="Comentario opcional"></textarea>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="guardar_estudiante" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>