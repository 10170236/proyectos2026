<?php
require_once 'conexion.php';
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'admin') exit("Acceso denegado");

// ELIMINAR
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $stmt = $conexion->prepare("DELETE FROM usuarios WHERE id = ? AND rol != 'admin'");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: registro.php?msg=eliminado");
}

// GUARDAR / ACTUALIZAR
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['usuario_id'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];
    $rol = $_POST['rol'];
    $nie = ($rol == 'estudiante') ? $_POST['nie'] : null;

    if (empty($id)) {
        // INSERTAR NUEVO
        $pass = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $stmt = $conexion->prepare("INSERT INTO usuarios (nombre, apellido, email, password, rol, nie) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $nombre, $apellido, $email, $pass, $rol, $nie);
    } else {
        // ACTUALIZAR EXISTENTE
        if (!empty($_POST['password'])) {
            $pass = password_hash($_POST['password'], PASSWORD_BCRYPT);
            $stmt = $conexion->prepare("UPDATE usuarios SET nombre=?, apellido=?, email=?, rol=?, nie=?, password=? WHERE id=?");
            $stmt->bind_param("ssssssi", $nombre, $apellido, $email, $rol, $nie, $pass, $id);
        } else {
            $stmt = $conexion->prepare("UPDATE usuarios SET nombre=?, apellido=?, email=?, rol=?, nie=? WHERE id=?");
            $stmt->bind_param("sssssi", $nombre, $apellido, $email, $rol, $nie, $id);
        }
    }
    
    $stmt->execute();
    header("Location: registro.php?msg=exito");
}