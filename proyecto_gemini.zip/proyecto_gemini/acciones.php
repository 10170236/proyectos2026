<?php
session_start();
require_once 'conexion.php';

// Verificación de Seguridad: Solo Docentes o Administradores
if (!isset($_SESSION['usuario_id']) || ($_SESSION['rol'] != 'docente' && $_SESSION['rol'] != 'admin')) {
    header("Location: index.php");
    exit();
}

/**
 * 1. GUARDAR NUEVO ESTUDIANTE (Desde Modal)
 */
if (isset($_POST['guardar_estudiante'])) {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $nie = $_POST['nie'];
    $email = $_POST['email'];
    $rol = 'estudiante';
    $comentario = $_POST['comentario'];
    $pass = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $stmt = $conexion->prepare("INSERT INTO usuarios (nombre, apellido, nie, email, password, rol, comentario) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $nombre, $apellido, $nie, $email, $pass, $rol, $comentario);
    
    if ($stmt->execute()) {
        header("Location: dashboard_docente.php?msg=estudiante_creado");
    } else {
        header("Location: dashboard_docente.php?err=error_guardar");
    }
    exit();
}

/**
 * 2. ACTUALIZAR ESTUDIANTE (Desde editar_estudiante.php)
 */
if (isset($_POST['actualizar_estudiante'])) {
    $id = $_POST['id_usuario'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $nie = $_POST['nie'];
    $email = $_POST['email'];
    $comentario = $_POST['comentario'];
    $password = $_POST['password'];

    if (!empty($password)) {
        // Si el docente escribió una nueva clave
        $pass_hashed = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conexion->prepare("UPDATE usuarios SET nombre=?, apellido=?, nie=?, email=?, password=?, comentario=? WHERE id=?");
        $stmt->bind_param("ssssssi", $nombre, $apellido, $nie, $email, $pass_hashed, $comentario, $id);
    } else {
        // Si no se tocó la clave, se mantienen los demás datos
        $stmt = $conexion->prepare("UPDATE usuarios SET nombre=?, apellido=?, nie=?, email=?, comentario=? WHERE id=?");
        $stmt->bind_param("sssssi", $nombre, $apellido, $nie, $email, $comentario, $id);
    }

    if ($stmt->execute()) {
        header("Location: dashboard_docente.php?msg=estudiante_actualizado");
    } else {
        header("Location: dashboard_docente.php?err=error_actualizar");
    }
    exit();
}

/**
 * 3. ELIMINAR ESTUDIANTE
 */
if (isset($_GET['eliminar_est'])) {
    $id = $_GET['eliminar_est'];

    // Verificar si el estudiante está en algún grupo antes de borrarlo
    $check = $conexion->prepare("SELECT usuario_id FROM estudiantes_grupos WHERE usuario_id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    
    if ($check->get_result()->num_rows > 0) {
        header("Location: dashboard_docente.php?err=estudiante_con_grupo");
    } else {
        $stmt = $conexion->prepare("DELETE FROM usuarios WHERE id = ? AND rol = 'estudiante'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        header("Location: dashboard_docente.php?msg=estudiante_eliminado");
    }
    exit();
}

/**
 * 4. CREAR GRUPO
 */
if (isset($_POST['crear_grupo'])) {
    $nombre_grupo = $_POST['nombre_grupo'];
    $docente_id = $_SESSION['usuario_id'];

    $stmt = $conexion->prepare("INSERT INTO grupos (nombre_grupo, docente_id) VALUES (?, ?)");
    $stmt->bind_param("si", $nombre_grupo, $docente_id);
    $stmt->execute();
    header("Location: dashboard_docente.php?msg=grupo_creado");
    exit();
}

/**
 * 5. CREAR PROYECTO
 */
if (isset($_POST['crear_proy'])) {
    $nombre_proyecto = $_POST['nom_proy'];
    $grupo_id = $_POST['grupo_id'];
    $desc = "Proyecto académico asignado.";

    $stmt = $conexion->prepare("INSERT INTO proyectos (nombre_proyecto, descripcion, grupo_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $nombre_proyecto, $desc, $grupo_id);
    $stmt->execute();
    header("Location: dashboard_docente.php?msg=proyecto_creado");
    exit();
}