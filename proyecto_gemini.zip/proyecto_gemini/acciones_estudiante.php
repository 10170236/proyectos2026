<?php
require_once 'conexion.php';
session_start();

// Seguridad: Solo estudiantes autenticados
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'estudiante') {
    header("Location: index.php");
    exit();
}

$estudiante_id = $_SESSION['usuario_id'];

// --- ACCIÓN 1: CAMBIAR ESTADO DE LA TAREA ---
if (isset($_GET['accion']) && $_GET['accion'] === 'cambiar_estado') {
    $tarea_id = $_GET['id'];
    $nuevo_estado = $_GET['estado'];

    // Validamos que el estado sea uno de los permitidos
    $estados_validos = ['Asignada', 'En proceso', 'Finalizada'];
    
    if (in_array($nuevo_estado, $estados_validos)) {
        $stmt = $conexion->prepare("UPDATE tareas SET estado = ? WHERE id = ?");
        $stmt->bind_param("si", $nuevo_estado, $tarea_id);
        
        if ($stmt->execute()) {
            header("Location: dashboard_estudiante.php?msg=estado_actualizado");
        }
    }
}

// --- ACCIÓN 2: AGREGAR COMENTARIO ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar_comentario'])) {
    $tarea_id = $_POST['tarea_id'];
    // htmlspecialchars evita inyección de scripts (XSS)
    $contenido = htmlspecialchars($_POST['contenido'], ENT_QUOTES, 'UTF-8');

    if (!empty($contenido)) {
        $stmt = $conexion->prepare("INSERT INTO comentarios (tarea_id, usuario_id, contenido) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $tarea_id, $estudiante_id, $contenido);
        
        if ($stmt->execute()) {
            header("Location: dashboard_estudiante.php?msg=comentario_enviado");
        }
    } else {
        header("Location: dashboard_estudiante.php?err=comentario_vacio");
    }
}

// --- ACCIÓN 3: ASIGNAR A UN COMPAÑERO ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['asignar_companero'])) {
    $tarea_id = $_POST['tarea_id'];
    $nuevo_responsable_id = $_POST['companero_id'];

    // Actualizamos el campo asignado_a
    $stmt = $conexion->prepare("UPDATE tareas SET asignado_a = ? WHERE id = ?");
    $stmt->bind_param("ii", $nuevo_responsable_id, $tarea_id);
    
    if ($stmt->execute()) {
        header("Location: dashboard_estudiante.php?msg=tarea_reasignada");
    }
}

// --- ACCIÓN 4: CÁLCULO DE PROGRESO (Para uso interno o API) ---
// Esta lógica ya está integrada en el Dashboard, pero aquí se asegura la integridad
if (isset($_GET['get_progreso'])) {
    $proyecto_id = $_GET['proyecto_id'];
    
    $res = $conexion->query("SELECT 
        COUNT(*) as total, 
        SUM(CASE WHEN estado = 'Finalizada' THEN 1 ELSE 0 END) as terminadas 
        FROM tareas WHERE proyecto_id = $proyecto_id");
    
    $data = $res->fetch_assoc();
    $progreso = ($data['total'] > 0) ? round(($data['terminadas'] / $data['total']) * 100) : 0;
    
    echo $progreso . "%";
    exit();
}