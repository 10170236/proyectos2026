<?php
require_once 'conexion.php';
session_start();

if (isset($_GET['id']) && isset($_GET['estado'])) {
    $id = $_GET['id'];
    $estado = $_GET['estado'];
    
    // Solo permitir estados válidos
    $estados_permitidos = ['Asignada', 'En proceso', 'Finalizada'];
    if (in_array($estado, $estados_permitidos)) {
        $stmt = $conexion->prepare("UPDATE tareas SET estado = ? WHERE id = ?");
        $stmt->bind_param("si", $estado, $id);
        $stmt->execute();
    }
}
header("Location: dashboard_estudiante.php");