<?php
require_once 'conexion.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['usuario_id'])) {
    $tarea_id = $_POST['tarea_id'];
    $usuario_id = $_SESSION['usuario_id'];
    $contenido = htmlspecialchars($_POST['comentario']); // Seguridad contra XSS

    $stmt = $conexion->prepare("INSERT INTO comentarios (tarea_id, usuario_id, contenido) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $tarea_id, $usuario_id, $contenido);
    
    if ($stmt->execute()) {
        header("Location: dashboard_estudiante.php?msg=comentario_enviado");
    }
}