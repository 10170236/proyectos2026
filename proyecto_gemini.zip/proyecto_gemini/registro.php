<?php
require_once 'conexion.php';
session_start();

// Seguridad: Solo el administrador puede entrar aquí
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Obtener todos los usuarios (Docentes y Estudiantes)
$query = "SELECT id, nombre, apellido, email, rol, nie FROM usuarios WHERE rol != 'admin' ORDER BY rol ASC";
$usuarios = $conexion->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Administración de Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
    <div class="container">
        <a class="navbar-brand" href="#">Panel Administrativo</a>
        <div class="d-flex">
            <a href="dashboard_docente.php" class="btn btn-outline-light btn-sm me-2">Volver</a>
            <a href="logout.php" class="btn btn-danger btn-sm">Cerrar Sesión</a>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Gestión de Usuarios</h4>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalUsuario">
                <i class="bi bi-person-plus"></i> Nuevo Usuario
            </button>
        </div>
        <div class="card-body">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Rol</th>
                        <th>Nombre Completo</th>
                        <th>Email</th>
                        <th>NIE (Estudiantes)</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($u = $usuarios->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <span class="badge <?php echo $u['rol'] == 'docente' ? 'bg-info' : 'bg-success'; ?>">
                                <?php echo ucfirst($u['rol']); ?>
                            </span>
                        </td>
                        <td><?php echo $u['nombre'] . " " . $u['apellido']; ?></td>
                        <td><?php echo $u['email']; ?></td>
                        <td><?php echo $u['nie'] ?? 'N/A'; ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick="editarUsuario(<?php echo htmlspecialchars(json_encode($u)); ?>)">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <a href="procesar_usuario.php?eliminar=<?php echo $u['id']; ?>" 
                               class="btn btn-sm btn-danger" 
                               onclick="return confirm('¿Está seguro de eliminar este usuario?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="modalUsuario" tabindex="-1">
    <div class="modal-dialog">
        <form action="procesar_usuario.php" method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tituloModal">Registrar Usuario</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="usuario_id" id="usuario_id">
                
                <div class="mb-3">
                    <label class="form-label">Rol</label>
                    <select name="rol" id="rol" class="form-select" required onchange="toggleNIE()">
                        <option value="estudiante">Estudiante</option>
                        <option value="docente">Docente</option>
                    </select>
                </div>
                <div class="row mb-3">
                    <div class="col"><input type="text" name="nombre" id="nombre" class="form-control" placeholder="Nombre" required></div>
                    <div class="col"><input type="text" name="apellido" id="apellido" class="form-control" placeholder="Apellido" required></div>
                </div>
                <div class="mb-3" id="campo_nie">
                    <label class="form-label">NIE (Solo estudiantes)</label>
                    <input type="text" name="nie" id="nie" class="form-control" maxlength="12">
                </div>
                <div class="mb-3">
                    <input type="email" name="email" id="email" class="form-control" placeholder="Correo Electrónico" required>
                </div>
                <div class="mb-3">
                    <input type="password" name="password" id="password" class="form-control" placeholder="Contraseña (Dejar vacío para no cambiar en edición)">
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="accion" value="guardar" class="btn btn-primary w-100">Guardar Cambios</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function toggleNIE() {
        const rol = document.getElementById('rol').value;
        document.getElementById('campo_nie').style.display = (rol === 'estudiante') ? 'block' : 'none';
    }

    function editarUsuario(data) {
        document.getElementById('tituloModal').innerText = "Editar Usuario";
        document.getElementById('usuario_id').value = data.id;
        document.getElementById('nombre').value = data.nombre;
        document.getElementById('apellido').value = data.apellido;
        document.getElementById('email').value = data.email;
        document.getElementById('rol').value = data.rol;
        document.getElementById('nie').value = data.nie || '';
        document.getElementById('password').placeholder = "Nueva contraseña (opcional)";
        toggleNIE();
        new bootstrap.Modal(document.getElementById('modalUsuario')).show();
    }
</script>
</body>
</html>