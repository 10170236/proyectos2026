<?php
require_once 'conexion.php';
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'docente' && $_SESSION['rol'] !== 'admin') {
    header("Location: index.php"); exit();
}

$grupo_id = $_GET['id'];

// 1. Obtener información del grupo
$stmt = $conexion->prepare("SELECT nombre_grupo FROM grupos WHERE id = ?");
$stmt->bind_param("i", $grupo_id);
$stmt->execute();
$grupo = $stmt->get_result()->fetch_assoc();

// 2. Obtener estudiantes que YA ESTÁN en este grupo
$query_miembros = "SELECT u.id, u.nombre, u.apellido, u.nie 
                   FROM usuarios u 
                   JOIN estudiantes_grupos eg ON u.id = eg.usuario_id 
                   WHERE eg.grupo_id = ?";
$stmt_m = $conexion->prepare($query_miembros);
$stmt_m->bind_param("i", $grupo_id);
$stmt_m->execute();
$miembros = $stmt_m->get_result();

// 3. Obtener estudiantes que NO ESTÁN en ningún grupo (para poder agregarlos)
$query_libres = "SELECT id, nombre, apellido FROM usuarios 
                 WHERE rol = 'estudiante' 
                 AND id NOT IN (SELECT usuario_id FROM estudiantes_grupos)";
$estudiantes_libres = $conexion->query($query_libres);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestionar Grupo: <?php echo $grupo['nombre_grupo']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Grupo: <?php echo $grupo['nombre_grupo']; ?></h2>
            <a href="dashboard_docente.php" class="btn btn-secondary">Volver al Panel</a>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-primary text-white">Agregar Estudiante</div>
                    <div class="card-body">
                        <form action="procesar_grupo.php" method="POST">
                            <input type="hidden" name="grupo_id" value="<?php echo $grupo_id; ?>">
                            <div class="mb-3">
                                <label class="form-label">Seleccionar Estudiante Libre</label>
                                <select name="usuario_id" class="form-select" required>
                                    <option value="">Seleccione...</option>
                                    <?php while($est = $estudiantes_libres->fetch_assoc()): ?>
                                        <option value="<?php echo $est['id']; ?>"><?php echo $est['nombre']." ".$est['apellido']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <button type="submit" name="accion" value="agregar" class="btn btn-success w-100">Inscribir al Grupo</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">Integrantes del Grupo</div>
                    <div class="card-body">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>NIE</th>
                                    <th>Nombre</th>
                                    <th>Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($m = $miembros->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $m['nie']; ?></td>
                                    <td><?php echo $m['nombre']." ".$m['apellido']; ?></td>
                                    <td>
                                        <a href="procesar_grupo.php?remover=<?php echo $m['id']; ?>&grupo_id=<?php echo $grupo_id; ?>" 
                                           class="btn btn-danger btn-sm" 
                                           onclick="return confirm('¿Remover del grupo?')">Remover</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>