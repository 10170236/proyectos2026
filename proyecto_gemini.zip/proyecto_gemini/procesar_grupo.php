<?php
require_once 'conexion.php';
session_start();

if (isset($_POST['accion']) && $_POST['accion'] == 'agregar') {
    $grupo_id = $_POST['grupo_id'];
    $usuario_id = $_POST['usuario_id'];

    $stmt = $conexion->prepare("INSERT INTO estudiantes_grupos (usuario_id, grupo_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $usuario_id, $grupo_id);
    $stmt->execute();
    
    header("Location: gestionar_grupo.php?id=" . $grupo_id);
}

if (isset($_GET['remover'])) {
    $usuario_id = $_GET['remover'];
    $grupo_id = $_GET['grupo_id'];

    $stmt = $conexion->prepare("DELETE FROM estudiantes_grupos WHERE usuario_id = ? AND grupo_id = ?");
    $stmt->bind_param("ii", $usuario_id, $grupo_id);
    $stmt->execute();

    header("Location: gestionar_grupo.php?id=" . $grupo_id);
}