﻿using System;
using Dominio;
using ObserverRestaurante.Datos;
namespace Aplicacion;

public class ServicioPedido
{
    private Pedido pedido;
    private PedidoDAL dal = new PedidoDAL();

    public void CrearPedido(string nombre, string producto)
    {
        pedido = new Pedido
        {
            NombreCliente = nombre,
            Producto = producto,
            Estado = "Pendiente"
        };

        pedido.AgregarObservador(new Cajero());
        pedido.AgregarObservador(new Cliente());
       

        dal.Insertar(pedido);

        Console.WriteLine("\nPedido registrado correctamente.");
    }

    public void CambiarEstado()
    {
        Console.WriteLine("\n1. En preparación");
        Console.WriteLine("2. Listo");
        string op = Console.ReadLine();

        if (op == "1")
            pedido.CambiarEstado("En preparación");
        else if (op == "2")
            pedido.CambiarEstado("Listo");
    }
}