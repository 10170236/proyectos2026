﻿using System;
using System;
using Dominio;

public class Cocina : IObservador
{
    public void Actualizar(Pedido pedido)
    {
        Console.WriteLine("[Cocina] Pedido actualizado a: " + pedido.Estado);
    }
}