﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Cajero : IObservador
    {
        public void Actualizar(Pedido pedido)
        {
            Console.WriteLine($"Pedido de {pedido.NombreCliente} ({pedido.Producto}) está {pedido.Estado}");
        }
    }
}
