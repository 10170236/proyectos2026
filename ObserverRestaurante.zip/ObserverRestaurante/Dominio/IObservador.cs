﻿namespace Dominio
{
    public interface IObservador
    {
        void Actualizar(Pedido pedido);
    }
}
