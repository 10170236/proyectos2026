﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections.Generic;

namespace Dominio
{
    public class Pedido
    {
        private List<IObservador> observadores = new List<IObservador>();

        public string NombreCliente { get; set; }

        public string Producto { get; set; }
        public string Estado { get; set; }


        public void AgregarObservador(IObservador obs)
        {
            observadores.Add(obs);
        }

        public void CambiarEstado(string nuevoEstado)
        {
            Estado = nuevoEstado;
            Notificar();
        }

        private void Notificar()
        {
            foreach (var obs in observadores)
            {
                obs.Actualizar(this);
            }
        }
    }
}