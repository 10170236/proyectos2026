﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Cliente : IObservador
    {
        public void Actualizar(Pedido pedido)
        {
            Console.WriteLine($"{pedido.NombreCliente}, tu pedido de {pedido.Producto} está {pedido.Estado}");
        }
    }
}
