﻿using System;
using Aplicacion;

class Program
{
    static void Main(string[] args)
    {
        ServicioPedido servicio = new ServicioPedido();

        Console.Write("Ingrese su nombre: ");
        string nombre = Console.ReadLine();

        Console.Write("¿Qué desea ordenar?: ");
        string producto = Console.ReadLine();

        servicio.CrearPedido(nombre, producto);

        bool continuar = true;

        while (continuar)
        {
            Console.WriteLine("\n=== COCINA ===");
            Console.WriteLine("1. Cambiar estado");
            Console.WriteLine("2. Salir");

            string op = Console.ReadLine();

            if (op == "1")
                servicio.CambiarEstado();
            else
                continuar = false;
        }
    }
}
