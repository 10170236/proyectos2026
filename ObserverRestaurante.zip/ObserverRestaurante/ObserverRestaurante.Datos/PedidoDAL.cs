﻿namespace ObserverRestaurante.Datos
{
    using System.Data.SqlClient;
    using Dominio;

    public class PedidoDAL
    {
        private string conexion = "Server=JPK;Database=RestauranteBD;Integrated Security=True;TrustServerCertificate=True;";

        public void Insertar(Pedido pedido)
        {
            using (SqlConnection con = new SqlConnection(conexion))
            {
                string query = "INSERT INTO Pedidos (NombreCliente, Producto, Estado) VALUES (@nombre, @producto, @estado)";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@nombre", pedido.NombreCliente);
                cmd.Parameters.AddWithValue("@producto", pedido.Producto);
                cmd.Parameters.AddWithValue("@estado", pedido.Estado);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
