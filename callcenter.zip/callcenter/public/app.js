/* ============================================================================
   CALLCENTER PRO - APLICACIÓN JAVASCRIPT PRINCIPAL
   ============================================================================ */

// Estado Global y Almacén en Memoria de Respaldo (Alineado a database.sql)
let currentUser = null;
let currentCliente = null;
let tipificacionesCache = [];

// Base de Datos Local en Memoria (Fallback si la API REST no está en ejecución)
const dbLocal = {
  usuarios: [
    { idUsuario: 1, nombre: 'Carlos Agente', email: 'agente1@callcenter.com', password: '123', idRol: 1, rolNombre: 'Agente' },
    { idUsuario: 2, nombre: 'Ana Agente', email: 'agente2@callcenter.com', password: '123', idRol: 1, rolNombre: 'Agente' },
    { idUsuario: 3, nombre: 'Roberto Supervisor', email: 'supervisor1@callcenter.com', password: '123', idRol: 2, rolNombre: 'Supervisor' }
  ],
  clientes: [
    { idCliente: 1, dni: '12345678', nombre: 'Juan Pérez Mendoza', telefono: '987654321', email: 'juan.perez@email.com', fechaRegistro: new Date(Date.now() - 30 * 86400000).toISOString() },
    { idCliente: 2, dni: '87654321', nombre: 'Maria Rodríguez Silva', telefono: '912345678', email: 'maria.rodriguez@email.com', fechaRegistro: new Date(Date.now() - 15 * 86400000).toISOString() },
    { idCliente: 3, dni: '45678912', nombre: 'Luis Gomez Flores', telefono: '955443322', email: 'luis.gomez@email.com', fechaRegistro: new Date(Date.now() - 5 * 86400000).toISOString() }
  ],
  tipificaciones: [
    { idTipificacion: 1, nombreCategoria: 'Soporte Técnico', descripcion: 'Inconvenientes con la señal, router o configuración', activo: true },
    { idTipificacion: 2, nombreCategoria: 'Facturación y Cobranzas', descripcion: 'Consultas sobre recibos, pagos y estados de cuenta', activo: true },
    { idTipificacion: 3, nombreCategoria: 'Reclamos y Quejas', descripcion: 'Insatisfacción por servicio o atención', activo: true },
    { idTipificacion: 4, nombreCategoria: 'Ventas y Promociones', descripcion: 'Solicitud de nuevos planes o migración', activo: true },
    { idTipificacion: 5, nombreCategoria: 'Información General', descripcion: 'Consultas de horarios, centros de atención y servicios', activo: true }
  ],
  interacciones: [
    { idInteraccion: 1, idCliente: 1, idUsuario: 1, agenteNombre: 'Carlos Agente', idTipificacion: 1, motivo: 'Soporte Técnico', notas: 'Cliente reporta intermitencia en el servicio de Internet. Se envió comando de reinicio remoto de router.', fechaHora: new Date(Date.now() - 5 * 3600000).toISOString() },
    { idInteraccion: 2, idCliente: 1, idUsuario: 2, agenteNombre: 'Ana Agente', idTipificacion: 2, motivo: 'Facturación y Cobranzas', notas: 'Consulta fecha de vencimiento del recibo del mes de julio.', fechaHora: new Date(Date.now() - 2 * 3600000).toISOString() },
    { idInteraccion: 3, idCliente: 2, idUsuario: 1, agenteNombre: 'Carlos Agente', idTipificacion: 4, motivo: 'Ventas y Promociones', notas: 'Cliente solicita cotización para contratar servicio de Fibra Óptica 300 Mbps.', fechaHora: new Date(Date.now() - 1 * 3600000).toISOString() },
    { idInteraccion: 4, idCliente: 3, idUsuario: 2, agenteNombre: 'Ana Agente', idTipificacion: 3, motivo: 'Reclamos y Quejas', notas: 'Reclamo por cobro no reconocido en último recibo. Se abre solicitud de aclaración.', fechaHora: new Date().toISOString() }
  ]
};

// API Base URL
const API_BASE = '/api';


// ============================================================================
// INICIALIZACIÓN Y EVENT LISTENERS GLOBALES (ATAJOS DE TECLADO US01, US02, US03)
// ============================================================================

document.addEventListener('DOMContentLoaded', () => {
  setupKeyboardShortcuts();
  setupLoginForm();
});

/**
 * Atajos de Teclado Globales:
 * - Enter en Login (US01): Manejado nativamente por form submit.
 * - Ctrl + B o F3 (US02): Mueve el cursor automáticamente al campo de búsqueda.
 * - Ctrl + G (US03): Guarda el nuevo cliente cuando el modal está abierto.
 */
function setupKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    // Ctrl + B o F3 -> Ir al campo de búsqueda de cliente (US02)
    if ((e.ctrlKey && e.key.toLowerCase() === 'b') || e.key === 'F3') {
      e.preventDefault();
      if (currentUser && currentUser.idRol === 1) { // Solo en modo Agente
        const inputBusqueda = document.getElementById('input-busqueda-rapida');
        if (inputBusqueda) {
          inputBusqueda.focus();
          inputBusqueda.select();
          showToast('🔍 Cursor en campo de búsqueda (Atajo Ctrl+B / F3)', 'info');
        }
      }
    }

    // Ctrl + G -> Guardar cliente rápido desde modal (US03)
    if (e.ctrlKey && e.key.toLowerCase() === 'g') {
      const modalCliente = document.getElementById('modal-nuevo-cliente');
      if (modalCliente && !modalCliente.classList.contains('hidden')) {
        e.preventDefault();
        document.getElementById('form-nuevo-cliente').requestSubmit();
      }
    }
  });
}

// ============================================================================
// ÉPICA 1: ACCESO Y SEGURIDAD (US01 - INICIO DE SESIÓN)
// ============================================================================

function setupLoginForm() {
  const loginForm = document.getElementById('form-login');
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;

    let user = null;

    try {
      const response = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        user = data.user;
      }
    } catch (err) {
      // Fallback local si el servidor HTTP no responde
      user = dbLocal.usuarios.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    }

    if (!user) {
      showToast('Credenciales inválidas. Verifique usuario y contraseña.', 'error');
      return;
    }

    currentUser = user;
    showToast(`¡Bienvenido(a), ${currentUser.nombre}!`, 'success');
    iniciarSesionUsuario(currentUser);
  });
}

function setQuickLogin(email, password) {
  document.getElementById('login-email').value = email;
  document.getElementById('login-password').value = password;
  
  document.querySelectorAll('.chip-btn').forEach(btn => btn.classList.remove('active'));
  event.currentTarget.classList.add('active');
}

function iniciarSesionUsuario(user) {
  document.getElementById('view-login').classList.remove('active');
  document.getElementById('main-app').classList.remove('hidden');

  document.getElementById('user-display-name').textContent = user.nombre;
  document.getElementById('user-avatar-initial').textContent = user.nombre.charAt(0).toUpperCase();
  document.getElementById('role-badge').textContent = user.rolNombre;

  if (user.idRol === 1) {
    // ROL AGENTE
    document.getElementById('view-agent').classList.remove('hidden');
    document.getElementById('view-supervisor').classList.add('hidden');
    cargarTipificacionesAgente();
    
    setTimeout(() => {
      document.getElementById('input-busqueda-rapida').focus();
    }, 100);

  } else if (user.idRol === 2) {
    // ROL SUPERVISOR
    document.getElementById('view-agent').classList.add('hidden');
    document.getElementById('view-supervisor').classList.remove('hidden');
    cargarDashboardSupervisor();
  }
}

function logout() {
  currentUser = null;
  currentCliente = null;
  document.getElementById('main-app').classList.add('hidden');
  document.getElementById('view-login').classList.add('active');
  showToast('Sesión cerrada correctamente.', 'info');
}

// ============================================================================
// ÉPICA 2: OPERACIÓN DEL AGENTE (US02, US03, US04)
// ============================================================================

/**
 * US02: Búsqueda Rápida de Clientes por Teléfono o DNI
 */
async function ejecutarBusquedaCliente() {
  const query = document.getElementById('input-busqueda-rapida').value.trim();
  if (!query) {
    showToast('Ingrese un número de Teléfono o DNI para buscar.', 'error');
    return;
  }

  let cliente = null;
  let historial = [];

  try {
    const res = await fetch(`${API_BASE}/clientes/buscar?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    if (data.success && data.encontrado) {
      cliente = data.cliente;
      historial = data.historial;
    }
  } catch (err) {
    // Respaldo local
    cliente = dbLocal.clientes.find(c => c.telefono === query || c.dni === query);
    if (cliente) {
      historial = dbLocal.interacciones
        .filter(i => i.idCliente === cliente.idCliente)
        .sort((a, b) => new Date(b.fechaHora) - new Date(a.fechaHora));
    }
  }

  if (cliente) {
    seleccionarCliente(cliente, historial);
    showToast(`Cliente '${cliente.nombre}' encontrado.`, 'success');
  } else {
    limpiarSeleccionCliente();
    showToast('No se encontró ningún cliente con esos datos.', 'error');
    if (confirm('Cliente no registrado. ¿Desea abrir el formulario para crear un nuevo cliente?')) {
      abrirModalNuevoCliente(query);
    }
  }
}

document.getElementById('input-busqueda-rapida')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    ejecutarBusquedaCliente();
  }
});

function seleccionarCliente(cliente, historial = []) {
  currentCliente = cliente;

  document.getElementById('cliente-empty-state').classList.add('hidden');
  const detailsPanel = document.getElementById('cliente-details-panel');
  detailsPanel.classList.remove('hidden');

  document.getElementById('c-avatar').textContent = cliente.nombre.substring(0, 2).toUpperCase();
  document.getElementById('c-nombre').textContent = cliente.nombre;
  document.getElementById('c-dni').textContent = `DNI: ${cliente.dni}`;
  document.getElementById('c-telefono').textContent = `📱 ${cliente.telefono}`;
  document.getElementById('c-email').textContent = cliente.email || 'No registrado';
  document.getElementById('c-fecha-registro').textContent = new Date(cliente.fechaRegistro).toLocaleDateString('es-ES');
  document.getElementById('c-id-cliente').textContent = `#${cliente.idCliente}`;

  document.getElementById('select-tipificacion').disabled = false;
  document.getElementById('ticket-notas').disabled = false;
  document.getElementById('btn-guardar-ticket').disabled = false;
  document.getElementById('ticket-timestamp').value = new Date().toLocaleString('es-ES');

  renderHistorialLlamadas(historial);
}

function limpiarSeleccionCliente() {
  currentCliente = null;
  document.getElementById('cliente-empty-state').classList.remove('hidden');
  document.getElementById('cliente-details-panel').classList.add('hidden');

  document.getElementById('select-tipificacion').disabled = true;
  document.getElementById('ticket-notas').disabled = true;
  document.getElementById('btn-guardar-ticket').disabled = true;
  document.getElementById('select-tipificacion').value = '';
  document.getElementById('ticket-notas').value = '';

  renderHistorialLlamadas([]);
}

function renderHistorialLlamadas(historial) {
  const container = document.getElementById('historial-list-container');
  const countBadge = document.getElementById('historial-count');
  countBadge.textContent = historial.length;

  if (historial.length === 0) {
    container.innerHTML = `
      <div class="empty-state sm">
        <p>No se registran llamadas pasadas para este cliente.</p>
      </div>`;
    return;
  }

  container.innerHTML = historial.map(item => `
    <div class="history-item">
      <div class="history-item-header">
        <span class="history-motivo">${escapeHtml(item.motivo)}</span>
        <span class="history-date">${new Date(item.fechaHora).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' })}</span>
      </div>
      <div class="history-agent">Atendido por: <strong>${escapeHtml(item.agenteNombre || item.agente || 'Agente')}</strong></div>
      <div class="history-notes">${escapeHtml(item.notas)}</div>
    </div>
  `).join('');
}

/**
 * US03: Creación Ágil de Clientes & Validaciones en Tiempo Real
 */
function abrirModalNuevoCliente(prefijo = '') {
  const modal = document.getElementById('modal-nuevo-cliente');
  modal.classList.remove('hidden');

  const inputTelefono = document.getElementById('nuevo-telefono');
  const inputDni = document.getElementById('nuevo-dni');

  if (/^\d+$/.test(prefijo)) {
    if (prefijo.length === 8) inputDni.value = prefijo;
    else inputTelefono.value = prefijo;
  }

  setTimeout(() => inputDni.focus(), 100);
}

function cerrarModalNuevoCliente() {
  document.getElementById('modal-nuevo-cliente').classList.add('hidden');
  document.getElementById('form-nuevo-cliente').reset();
  document.getElementById('telefono-err').classList.add('hidden');
}

/**
 * US03 Criterio: El campo de "Teléfono" no debe aceptar letras en tiempo real.
 */
function validarInputNumerico(inputElement) {
  const valorOriginal = inputElement.value;
  const valorLimpio = valorOriginal.replace(/\D/g, '');
  
  if (valorOriginal !== valorLimpio) {
    inputElement.value = valorLimpio;
    document.getElementById('telefono-err').classList.remove('hidden');
    setTimeout(() => {
      document.getElementById('telefono-err').classList.add('hidden');
    }, 2000);
  }
}

async function guardarNuevoCliente(e) {
  e.preventDefault();

  const dni = document.getElementById('nuevo-dni').value.trim();
  const nombre = document.getElementById('nuevo-nombre').value.trim();
  const telefono = document.getElementById('nuevo-telefono').value.trim();
  const email = document.getElementById('nuevo-email').value.trim();

  let nuevoCliente = null;

  try {
    const response = await fetch(`${API_BASE}/clientes/crear`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dni, nombre, telefono, email })
    });
    const data = await response.json();
    if (response.ok && data.success) {
      nuevoCliente = data.cliente;
    } else {
      showToast(data.message || 'Error al guardar el cliente.', 'error');
      return;
    }
  } catch (err) {
    // Respaldo local
    const existente = dbLocal.clientes.find(c => c.dni === dni || c.telefono === telefono);
    if (existente) {
      showToast('Ya existe un cliente registrado con ese DNI o Teléfono.', 'error');
      return;
    }

    nuevoCliente = {
      idCliente: dbLocal.clientes.length + 1,
      dni,
      nombre,
      telefono,
      email: email || '',
      fechaRegistro: new Date().toISOString()
    };
    dbLocal.clientes.push(nuevoCliente);
  }

  showToast('✅ Cliente registrado con éxito (Atajo Ctrl+G).', 'success');
  cerrarModalNuevoCliente();

  seleccionarCliente(nuevoCliente, []);
  document.getElementById('input-busqueda-rapida').value = nuevoCliente.telefono;
}

/**
 * US04: Registro de Interacción (Ticket)
 * Criterio de Rendimiento: Tras guardar, la pantalla debe limpiarse en menos de 1 segundo.
 */
async function guardarInteraccionTicket(e) {
  e.preventDefault();

  if (!currentCliente) {
    showToast('Seleccione un cliente antes de guardar la interacción.', 'error');
    return;
  }

  const idTipificacion = document.getElementById('select-tipificacion').value;
  const notas = document.getElementById('ticket-notas').value.trim();

  if (!idTipificacion || !notas) {
    showToast('Complete el motivo y las notas de atención.', 'error');
    return;
  }

  const startTime = performance.now();

  try {
    const response = await fetch(`${API_BASE}/interacciones/guardar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        idCliente: currentCliente.idCliente,
        idUsuario: currentUser.idUsuario,
        idTipificacion,
        notas
      })
    });
    const data = await response.json();
  } catch (err) {
    // Respaldo local
    const tip = dbLocal.tipificaciones.find(t => t.idTipificacion === parseInt(idTipificacion));
    dbLocal.interacciones.push({
      idInteraccion: dbLocal.interacciones.length + 1,
      idCliente: currentCliente.idCliente,
      idUsuario: currentUser.idUsuario,
      agenteNombre: currentUser.nombre,
      idTipificacion: parseInt(idTipificacion),
      motivo: tip ? tip.nombreCategoria : 'Consulta',
      notas,
      fechaHora: new Date().toISOString()
    });
  }

  // Limpieza de pantalla inmediata (< 1 segundo)
  limpiarSeleccionCliente();
  document.getElementById('input-busqueda-rapida').value = '';
  document.getElementById('input-busqueda-rapida').focus();

  const endTime = performance.now();
  const durationMs = Math.round(endTime - startTime);

  const badge = document.getElementById('speed-performance-badge');
  document.getElementById('cleared-ms').textContent = durationMs;
  badge.classList.remove('hidden');

  showToast(`⚡ Ticket guardado y pantalla restablecida en ${durationMs} ms.`, 'success');
  setTimeout(() => badge.classList.add('hidden'), 4000);
}

async function cargarTipificacionesAgente() {
  let list = [];
  try {
    const res = await fetch(`${API_BASE}/tipificaciones?soloActivas=true`);
    const data = await res.json();
    if (data.success) list = data.tipificaciones;
    else throw new Error();
  } catch (err) {
    list = dbLocal.tipificaciones.filter(t => t.activo);
  }

  tipificacionesCache = list;
  const select = document.getElementById('select-tipificacion');
  select.innerHTML = '<option value="">-- Seleccione Motivo --</option>' +
    list.map(t => `<option value="${t.idTipificacion}">${escapeHtml(t.nombreCategoria)}</option>`).join('');
}

// ============================================================================
// ÉPICA 3: ADMINISTRACIÓN Y SUPERVISIÓN (US05, US06)
// ============================================================================

/**
 * US05: Dashboard de Productividad para Supervisor
 */
async function cargarDashboardSupervisor() {
  let resData = null;

  try {
    const res = await fetch(`${API_BASE}/supervisor/dashboard`);
    const data = await res.json();
    if (data.success) resData = data;
  } catch (err) {
    // Respaldo local
    const agentes = dbLocal.usuarios.filter(u => u.idRol === 1);
    const hoy = new Date().toISOString().slice(0, 10);

    const productividad = agentes.map(agente => {
      const llamadasHoy = dbLocal.interacciones.filter(i => {
        const fechaI = new Date(i.fechaHora).toISOString().slice(0, 10);
        return i.idUsuario === agente.idUsuario && fechaI === hoy;
      });

      const ultima = llamadasHoy.length > 0
        ? llamadasHoy.sort((a, b) => new Date(b.fechaHora) - new Date(a.fechaHora))[0].fechaHora
        : null;

      return {
        idUsuario: agente.idUsuario,
        agenteNombre: agente.nombre,
        email: agente.email,
        totalLlamadas: llamadasHoy.length,
        ultimaLlamada: ultima
      };
    });

    const totalLlamadasHoy = dbLocal.interacciones.filter(i => new Date(i.fechaHora).toISOString().slice(0, 10) === hoy).length;
    resData = {
      resumen: {
        totalLlamadasHoy,
        agentesActivos: agentes.length,
        totalClientes: dbLocal.clientes.length
      },
      productividad
    };
  }

  if (!resData) return;

  document.getElementById('kpi-llamadas-hoy').textContent = resData.resumen.totalLlamadasHoy;
  document.getElementById('kpi-agentes-activos').textContent = resData.resumen.agentesActivos;
  document.getElementById('kpi-total-clientes').textContent = resData.resumen.totalClientes;

  const maxLlamadas = Math.max(...resData.productividad.map(p => p.totalLlamadas), 1);
  const tbody = document.getElementById('tbody-productividad');

  tbody.innerHTML = resData.productividad.map(p => {
    const porcentaje = Math.round((p.totalLlamadas / maxLlamadas) * 100);
    const ultimaStr = p.ultimaLlamada ? new Date(p.ultimaLlamada).toLocaleTimeString('es-ES') : 'Sin atenciones hoy';

    return `
      <tr>
        <td><strong>${escapeHtml(p.agenteNombre)}</strong></td>
        <td>${escapeHtml(p.email)}</td>
        <td><span class="status-tag active">${p.totalLlamadas} llamadas</span></td>
        <td>${ultimaStr}</td>
        <td>
          <div class="progress-bar-bg">
            <div class="progress-bar-fill" style="width: ${porcentaje}%"></div>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  cargarTipificacionesSupervisor();
  showToast('Dashboard de supervisión actualizado.', 'info');
}

/**
 * US06: Gestión del Catálogo de Tipificaciones
 */
async function cargarTipificacionesSupervisor() {
  let list = [];
  try {
    const res = await fetch(`${API_BASE}/tipificaciones`);
    const data = await res.json();
    if (data.success) list = data.tipificaciones;
  } catch (err) {
    list = dbLocal.tipificaciones;
  }

  const tbody = document.getElementById('tbody-tipificaciones');
  tbody.innerHTML = list.map(t => `
    <tr>
      <td><strong>${escapeHtml(t.nombreCategoria)}</strong></td>
      <td>${escapeHtml(t.descripcion || '-')}</td>
      <td>
        <span class="status-tag ${t.activo ? 'active' : 'inactive'}">
          ${t.activo ? 'Activo' : 'Inactivo'}
        </span>
      </td>
      <td>
        <button class="btn-secondary sm" onclick="toggleEstadoTipificacion(${t.idTipificacion})">
          ${t.activo ? 'Desactivar' : 'Activar'}
        </button>
      </td>
    </tr>
  `).join('');
}

function abrirModalNuevaTipificacion() {
  document.getElementById('modal-nueva-tipificacion').classList.remove('hidden');
}

function cerrarModalNuevaTipificacion() {
  document.getElementById('modal-nueva-tipificacion').classList.add('hidden');
  document.getElementById('form-nueva-tipificacion').reset();
}

async function guardarNuevaTipificacion(e) {
  e.preventDefault();

  const nombreCategoria = document.getElementById('nueva-cat-nombre').value.trim();
  const descripcion = document.getElementById('nueva-cat-desc').value.trim();

  try {
    const res = await fetch(`${API_BASE}/tipificaciones`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombreCategoria, descripcion })
    });
    const data = await res.json();
    if (!data.success) throw new Error(data.message);
  } catch (err) {
    // Respaldo local
    dbLocal.tipificaciones.push({
      idTipificacion: dbLocal.tipificaciones.length + 1,
      nombreCategoria,
      descripcion: descripcion || '',
      activo: true
    });
  }

  showToast('Categoría agregada exitosamente.', 'success');
  cerrarModalNuevaTipificacion();
  cargarTipificacionesSupervisor();
  cargarTipificacionesAgente();
}

async function toggleEstadoTipificacion(id) {
  try {
    const res = await fetch(`${API_BASE}/tipificaciones/${id}/estado`, {
      method: 'PUT'
    });
    const data = await res.json();
  } catch (err) {
    // Respaldo local
    const tip = dbLocal.tipificaciones.find(t => t.idTipificacion === id);
    if (tip) tip.activo = !tip.activo;
  }

  showToast('Estado de categoría actualizado.', 'success');
  cargarTipificacionesSupervisor();
  cargarTipificacionesAgente();
}

// ============================================================================
// UTILIDADES UI
// ============================================================================

function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  
  const iconMap = {
    success: '✅',
    error: '❌',
    info: 'ℹ️'
  };

  toast.innerHTML = `<span>${iconMap[type] || 'ℹ️'}</span> <span>${escapeHtml(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}


// ============================================================================
// UTILIDADES UI
// ============================================================================

function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  
  const iconMap = {
    success: '✅',
    error: '❌',
    info: 'ℹ️'
  };

  toast.innerHTML = `<span>${iconMap[type] || 'ℹ️'}</span> <span>${escapeHtml(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
