-- ============================================================================
-- SCRIPT DE BASE DE DATOS PARA SISTEMA DE CALL CENTER (SQL SERVER)
-- ============================================================================
-- Épicas cubiertas:
--   - Épica 1: Acceso y Seguridad (Roles, Usuarios, Autenticación)
--   - Épica 2: Operación del Agente (Clientes, Búsqueda Rápida, Interacciones/Tickets)
--   - Épica 3: Administración y Supervisión (Dashboard de Productividad, Tipificaciones)
-- ============================================================================

-- 1. CREACIÓN DE LA BASE DE DATOS
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'CallCenterDB')
BEGIN
    CREATE DATABASE CallCenterDB;
END
GO

USE CallCenterDB;
GO

-- 2. ELIMINACIÓN DE TABLAS SI YA EXISTEN (para recreación limpia)
IF OBJECT_ID('dbo.Interacciones', 'U') IS NOT NULL DROP TABLE dbo.Interacciones;
IF OBJECT_ID('dbo.Tipificaciones', 'U') IS NOT NULL DROP TABLE dbo.Tipificaciones;
IF OBJECT_ID('dbo.Clientes', 'U') IS NOT NULL DROP TABLE dbo.Clientes;
IF OBJECT_ID('dbo.Usuarios', 'U') IS NOT NULL DROP TABLE dbo.Usuarios;
IF OBJECT_ID('dbo.Roles', 'U') IS NOT NULL DROP TABLE dbo.Roles;
GO

-- 3. TABLA DE ROLES
CREATE TABLE dbo.Roles (
    IdRol INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL UNIQUE
);

-- 4. TABLA DE USUARIOS
CREATE TABLE dbo.Usuarios (
    IdUsuario INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL, -- En producción usar Hash
    IdRol INT NOT NULL,
    Activo BIT DEFAULT 1,
    CONSTRAINT FK_Usuarios_Roles FOREIGN KEY (IdRol) REFERENCES dbo.Roles(IdRol)
);

-- 5. TABLA DE CLIENTES (Optimizada con índices para DNI y Teléfono - US02)
CREATE TABLE dbo.Clientes (
    IdCliente INT IDENTITY(1,1) PRIMARY KEY,
    DNI VARCHAR(15) NOT NULL UNIQUE,
    Nombre VARCHAR(120) NOT NULL,
    Telefono VARCHAR(20) NOT NULL,
    Email VARCHAR(100) NULL,
    FechaRegistro DATETIME DEFAULT GETDATE()
);

-- Índices no agrupados para búsquedas súper rápidas por Teléfono y DNI (US02)
CREATE NONCLUSTERED INDEX IX_Clientes_Telefono ON dbo.Clientes(Telefono);
CREATE NONCLUSTERED INDEX IX_Clientes_DNI ON dbo.Clientes(DNI);

-- 6. TABLA DE TIPIFICACIONES (MOTIVOS DE LLAMADA - US06)
CREATE TABLE dbo.Tipificaciones (
    IdTipificacion INT IDENTITY(1,1) PRIMARY KEY,
    NombreCategoria VARCHAR(100) NOT NULL,
    Descripcion VARCHAR(255) NULL,
    Activo BIT DEFAULT 1
);

-- 7. TABLA DE INTERACCIONES / TICKETS (US04)
CREATE TABLE dbo.Interacciones (
    IdInteraccion INT IDENTITY(1,1) PRIMARY KEY,
    IdCliente INT NOT NULL,
    IdUsuario INT NOT NULL, -- ID del Agente que atendió
    IdTipificacion INT NOT NULL,
    Notas VARCHAR(MAX) NOT NULL,
    FechaHora DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_Interacciones_Clientes FOREIGN KEY (IdCliente) REFERENCES dbo.Clientes(IdCliente),
    CONSTRAINT FK_Interacciones_Usuarios FOREIGN KEY (IdUsuario) REFERENCES dbo.Usuarios(IdUsuario),
    CONSTRAINT FK_Interacciones_Tipificaciones FOREIGN KEY (IdTipificacion) REFERENCES dbo.Tipificaciones(IdTipificacion)
);

-- Índice para acelerar los reportes del Dashboard de Supervisión (US05)
CREATE NONCLUSTERED INDEX IX_Interacciones_Fecha_Usuario ON dbo.Interacciones(FechaHora, IdUsuario);
GO

-- ============================================================================
-- DATOS DE PRUEBA INICIALES
-- ============================================================================

-- Roles
INSERT INTO dbo.Roles (Nombre) VALUES ('Agente'), ('Supervisor');

-- Usuarios (Password '123456' para pruebas)
INSERT INTO dbo.Usuarios (Nombre, Email, Password, IdRol) VALUES 
('Carlos Agente', 'agente1@callcenter.com', '123456', 1),
('Ana Agente', 'agente2@callcenter.com', '123456', 1),
('Roberto Supervisor', 'supervisor1@callcenter.com', '123456', 2);

-- Tipificaciones precargadas (US04 / US06)
INSERT INTO dbo.Tipificaciones (NombreCategoria, Descripcion, Activo) VALUES
('Soporte Técnico', 'Inconvenientes con la señal, router o configuración', 1),
('Facturación y Cobranzas', 'Consultas sobre recibos, pagos y estados de cuenta', 1),
('Reclamos y Quejas', 'Insatisfacción por servicio o atención', 1),
('Ventas y Promociones', 'Solicitud de nuevos planes o migración', 1),
('Información General', 'Consultas de horarios, centros de atención y servicios', 1);

-- Clientes iniciales de prueba (US02)
INSERT INTO dbo.Clientes (DNI, Nombre, Telefono, Email, FechaRegistro) VALUES
('12345678', 'Juan Pérez Mendoza', '987654321', 'juan.perez@email.com', DATEADD(day, -30, GETDATE())),
('87654321', 'Maria Rodríguez Silva', '912345678', 'maria.rodriguez@email.com', DATEADD(day, -15, GETDATE())),
('45678912', 'Luis Gomez Flores', '955443322', 'luis.gomez@email.com', DATEADD(day, -5, GETDATE()));

-- Historial de interacciones previas (US02 e Historia de Supervisor US05)
INSERT INTO dbo.Interacciones (IdCliente, IdUsuario, IdTipificacion, Notas, FechaHora) VALUES
(1, 1, 1, 'Cliente reporta intermitencia en el servicio de Internet. Se envió comando de reinicio remoto de router.', DATEADD(hour, -5, GETDATE())),
(1, 2, 2, 'Consulta fecha de vencimiento del recibo del mes de julio.', DATEADD(hour, -2, GETDATE())),
(2, 1, 4, 'Cliente solicita cotización para contratar servicio de Fibra Óptica 300 Mbps.', DATEADD(hour, -1, GETDATE())),
(3, 2, 3, 'Reclamo por cobro no reconocido en último recibo. Se abre solicitud de aclaración.', GETDATE());
GO

-- ============================================================================
-- PROCEDIMIENTOS ALMACENADOS / CONSULTAS ÚTILES
-- ============================================================================

-- SP 1: Autenticación de Usuario (US01)
CREATE PROCEDURE dbo.sp_ValidarUsuario
    @Email VARCHAR(100),
    @Password VARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT u.IdUsuario, u.Nombre, u.Email, u.IdRol, r.Nombre AS RolNombre
    FROM dbo.Usuarios u
    INNER JOIN dbo.Roles r ON u.IdRol = r.IdRol
    WHERE u.Email = @Email AND u.Password = @Password AND u.Activo = 1;
END;
GO

-- SP 2: Búsqueda rápida de cliente por DNI o Teléfono con Historial (US02)
CREATE PROCEDURE dbo.sp_BuscarClienteRapido
    @Criterio VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    -- Datos del Cliente
    SELECT TOP 1 IdCliente, DNI, Nombre, Telefono, Email, FechaRegistro
    FROM dbo.Clientes
    WHERE Telefono = @Criterio OR DNI = @Criterio;

    -- Historial del Cliente si existe
    SELECT i.IdInteraccion, i.FechaHora, u.Nombre AS Agente, t.NombreCategoria AS Motivo, i.Notas
    FROM dbo.Interacciones i
    INNER JOIN dbo.Usuarios u ON i.IdUsuario = u.IdUsuario
    INNER JOIN dbo.Tipificaciones t ON i.IdTipificacion = t.IdTipificacion
    INNER JOIN dbo.Clientes c ON i.IdCliente = c.IdCliente
    WHERE c.Telefono = @Criterio OR c.DNI = @Criterio
    ORDER BY i.FechaHora DESC;
END;
GO

-- SP 3: Reporte para Dashboard de Supervisor (US05)
CREATE PROCEDURE dbo.sp_ObtenerDashboardProductividad
AS
BEGIN
    SET NOCOUNT ON;
    SELECT 
        u.IdUsuario,
        u.Nombre AS AgenteNombre,
        COUNT(i.IdInteraccion) AS TotalLlamadas,
        MAX(i.FechaHora) AS UltimaLlamada
    FROM dbo.Usuarios u
    INNER JOIN dbo.Roles r ON u.IdRol = r.IdRol
    LEFT JOIN dbo.Interacciones i ON u.IdUsuario = i.IdUsuario AND CAST(i.FechaHora AS DATE) = CAST(GETDATE() AS DATE)
    WHERE r.Nombre = 'Agente' AND u.Activo = 1
    GROUP BY u.IdUsuario, u.Nombre
    ORDER BY TotalLlamadas DESC;
END;
GO
