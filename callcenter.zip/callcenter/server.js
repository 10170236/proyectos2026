const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================================
// BASE DE DATOS EN MEMORIA (ALINEADA AL SCRIPT database.sql)
// Permite que la aplicación web funcione de inmediato para la prueba de concepto.
// ============================================================================

let roles = [
  { idRol: 1, nombre: 'Agente' },
  { idRol: 2, nombre: 'Supervisor' }
];

let usuarios = [
  { idUsuario: 1, nombre: 'Carlos Agente', email: 'agente1@callcenter.com', password: '123', idRol: 1, rolNombre: 'Agente' },
  { idUsuario: 2, nombre: 'Ana Agente', email: 'agente2@callcenter.com', password: '123', idRol: 1, rolNombre: 'Agente' },
  { idUsuario: 3, nombre: 'Roberto Supervisor', email: 'supervisor1@callcenter.com', password: '123', idRol: 2, rolNombre: 'Supervisor' }
];

let tipificaciones = [
  { idTipificacion: 1, nombreCategoria: 'Soporte Técnico', descripcion: 'Inconvenientes con la señal, router o configuración', activo: true },
  { idTipificacion: 2, nombreCategoria: 'Facturación y Cobranzas', descripcion: 'Consultas sobre recibos, pagos y estados de cuenta', activo: true },
  { idTipificacion: 3, nombreCategoria: 'Reclamos y Quejas', descripcion: 'Insatisfacción por servicio o atención', activo: true },
  { idTipificacion: 4, nombreCategoria: 'Ventas y Promociones', descripcion: 'Solicitud de nuevos planes o migración', activo: true },
  { idTipificacion: 5, nombreCategoria: 'Información General', descripcion: 'Consultas de horarios, centros de atención y servicios', activo: true }
];

let clientes = [
  { idCliente: 1, dni: '12345678', nombre: 'Juan Pérez Mendoza', telefono: '987654321', email: 'juan.perez@email.com', fechaRegistro: new Date(Date.now() - 30 * 86400000).toISOString() },
  { idCliente: 2, dni: '87654321', nombre: 'Maria Rodríguez Silva', telefono: '912345678', email: 'maria.rodriguez@email.com', fechaRegistro: new Date(Date.now() - 15 * 86400000).toISOString() },
  { idCliente: 3, dni: '45678912', nombre: 'Luis Gomez Flores', telefono: '955443322', email: 'luis.gomez@email.com', fechaRegistro: new Date(Date.now() - 5 * 86400000).toISOString() }
];

let interacciones = [
  { idInteraccion: 1, idCliente: 1, idUsuario: 1, agenteNombre: 'Carlos Agente', idTipificacion: 1, motivo: 'Soporte Técnico', notas: 'Cliente reporta intermitencia en el servicio de Internet. Se envió comando de reinicio remoto de router.', fechaHora: new Date(Date.now() - 5 * 3600000).toISOString() },
  { idInteraccion: 2, idCliente: 1, idUsuario: 2, agenteNombre: 'Ana Agente', idTipificacion: 2, motivo: 'Facturación y Cobranzas', notas: 'Consulta fecha de vencimiento del recibo del mes de julio.', fechaHora: new Date(Date.now() - 2 * 3600000).toISOString() },
  { idInteraccion: 3, idCliente: 2, idUsuario: 1, agenteNombre: 'Carlos Agente', idTipificacion: 4, motivo: 'Ventas y Promociones', notas: 'Cliente solicita cotización para contratar servicio de Fibra Óptica 300 Mbps.', fechaHora: new Date(Date.now() - 1 * 3600000).toISOString() },
  { idInteraccion: 4, idCliente: 3, idUsuario: 2, agenteNombre: 'Ana Agente', idTipificacion: 3, motivo: 'Reclamos y Quejas', notas: 'Reclamo por cobro no reconocido en último recibo. Se abre solicitud de aclaración.', fechaHora: new Date().toISOString() }
];

// ============================================================================
// ENDPOINTS API REST (CUBREN US01 a US06)
// ============================================================================

// ÉPICA 1: US01 - Inicio de Sesión según Rol
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = usuarios.find(u => u.email.toLowerCase() === (email || '').toLowerCase() && u.password === password);
  
  if (!user) {
    return res.status(401).json({ success: false, message: 'Credenciales inválidas. Verifique usuario y contraseña.' });
  }
  
  return res.json({
    success: true,
    user: {
      idUsuario: user.idUsuario,
      nombre: user.nombre,
      email: user.email,
      idRol: user.idRol,
      rolNombre: user.rolNombre
    }
  });
});

// ÉPICA 2: US02 - Búsqueda Rápida de Clientes e Historial
app.get('/api/clientes/buscar', (req, res) => {
  const query = (req.query.q || '').trim();
  if (!query) {
    return res.status(400).json({ success: false, message: 'Se requiere un criterio de búsqueda (Teléfono o DNI).' });
  }

  const cliente = clientes.find(c => c.telefono === query || c.dni === query);
  
  if (!cliente) {
    return res.json({ success: true, enencontrado: false, cliente: null, historial: [] });
  }

  const historial = interacciones
    .filter(i => i.idCliente === cliente.idCliente)
    .sort((a, b) => new Date(b.fechaHora) - new Date(a.fechaHora));

  return res.json({
    success: true,
    encontrado: true,
    cliente,
    historial
  });
});

// ÉPICA 2: US03 - Creación Ágil de Clientes
app.post('/api/clientes/crear', (req, res) => {
  const { dni, nombre, telefono, email } = req.body;

  if (!dni || !nombre || !telefono) {
    return res.status(400).json({ success: false, message: 'DNI, Nombre y Teléfono son requeridos.' });
  }

  // Validación numérica estricta para teléfono
  if (!/^\d+$/.test(telefono)) {
    return res.status(400).json({ success: false, message: 'El teléfono solo debe contener números.' });
  }

  const existente = clientes.find(c => c.dni === dni || c.telefono === telefono);
  if (existente) {
    return res.status(400).json({ success: false, message: 'Ya existe un cliente registrado con ese DNI o Teléfono.' });
  }

  const nuevoCliente = {
    idCliente: clientes.length + 1,
    dni,
    nombre,
    telefono,
    email: email || '',
    fechaRegistro: new Date().toISOString()
  };

  clientes.push(nuevoCliente);

  return res.status(201).json({
    success: true,
    message: 'Cliente registrado exitosamente.',
    cliente: nuevoCliente
  });
});

// ÉPICA 2: US04 - Registro de Interacción (Ticket)
app.post('/api/interacciones/guardar', (req, res) => {
  const { idCliente, idUsuario, idTipificacion, notas } = req.body;

  if (!idCliente || !idUsuario || !idTipificacion || !notas) {
    return res.status(400).json({ success: false, message: 'Faltan campos obligatorios para registrar la interacción.' });
  }

  const tip = tipificaciones.find(t => t.idTipificacion === parseInt(idTipificacion));
  const usuario = usuarios.find(u => u.idUsuario === parseInt(idUsuario));

  const nuevaInteraccion = {
    idInteraccion: interacciones.length + 1,
    idCliente: parseInt(idCliente),
    idUsuario: parseInt(idUsuario),
    agenteNombre: usuario ? usuario.nombre : 'Agente',
    idTipificacion: parseInt(idTipificacion),
    motivo: tip ? tip.nombreCategoria : 'Consulta',
    notas,
    fechaHora: new Date().toISOString()
  };

  interacciones.push(nuevaInteraccion);

  return res.status(201).json({
    success: true,
    message: 'Ticket registrado correctamente.',
    interaccion: nuevaInteraccion
  });
});

// ÉPICA 2 & ÉPICA 3: US04 & US06 - Menú y Catálogo de Tipificaciones
app.get('/api/tipificaciones', (req, res) => {
  const soloActivas = req.query.soloActivas === 'true';
  const resultado = soloActivas ? tipificaciones.filter(t => t.activo) : tipificaciones;
  return res.json({ success: true, tipificaciones: resultado });
});

app.post('/api/tipificaciones', (req, res) => {
  const { nombreCategoria, descripcion } = req.body;
  if (!nombreCategoria) {
    return res.status(400).json({ success: false, message: 'El nombre de la categoría es obligatorio.' });
  }

  const nuevaCat = {
    idTipificacion: tipificaciones.length + 1,
    nombreCategoria,
    descripcion: descripcion || '',
    activo: true
  };

  tipificaciones.push(nuevaCat);
  return res.status(201).json({ success: true, message: 'Categoría agregada correctamente.', tipificacion: nuevaCat });
});

app.put('/api/tipificaciones/:id/estado', (req, res) => {
  const id = parseInt(req.params.id);
  const tip = tipificaciones.find(t => t.idTipificacion === id);

  if (!tip) {
    return res.status(404).json({ success: false, message: 'Categoría no encontrada.' });
  }

  tip.activo = !tip.activo;
  return res.json({ success: true, message: `Categoría ${tip.activo ? 'activada' : 'desactivada'} con éxito.`, tipificacion: tip });
});

// ÉPICA 3: US05 - Dashboard de Productividad para Supervisor
app.get('/api/supervisor/dashboard', (req, res) => {
  const agentes = usuarios.filter(u => u.idRol === 1);
  const hoy = new Date().toISOString().slice(0, 10);

  const productividad = agentes.map(agente => {
    const llamadasHoy = interacciones.filter(i => {
      const fechaI = new Date(i.fechaHora).toISOString().slice(0, 10);
      return i.idUsuario === agente.idUsuario && fechaI === hoy;
    });

    const ultima = llamadasHoy.length > 0
      ? llamadasHoy.sort((a, b) => new Date(b.fechaHora) - new Date(a.fechaHora))[0].fechaHora
      : null;

    return {
      idUsuario: agente.idUsuario,
      agenteNombre: agente.nombre,
      email: agente.email,
      totalLlamadas: llamadasHoy.length,
      ultimaLlamada: ultima
    };
  });

  const totalInteraccionesHoy = interacciones.filter(i => new Date(i.fechaHora).toISOString().slice(0, 10) === hoy).length;
  const totalClientes = clientes.length;

  return res.json({
    success: true,
    fecha: hoy,
    resumen: {
      totalLlamadasHoy: totalInteraccionesHoy,
      totalClientes,
      agentesActivos: agentes.length
    },
    productividad
  });
});

// Fallback a index.html para SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`  CallCenter Pro API + Web App iniciada con éxito`);
  console.log(`  URL: http://localhost:${PORT}`);
  console.log(`=======================================================`);
});
